# Changelog

All notable changes to BudgetPlanner Pro are documented here.
Format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/).
Versioning follows [Semantic Versioning](https://semver.org/).

---

## [6.0.0] – 2025-05-19

### Changed – Architecture
- Refactored into a proper Python package (`budgetplanner/core`, `ui`, `utils`, `tests`).
- `BudgetModel` now lives in `budgetplanner/core/models.py` – zero Tkinter dependency.
- `SavingsGoal` converted to a dataclass with `progress_pct` and `months_remaining` properties.
- `UndoRedoManager` extracted to its own class with `can_undo`/`can_redo` properties.
- `ThemeManager` encapsulates palette lookup; palettes are frozen dataclasses.
- All UI helpers centralised in `budgetplanner/ui/widgets.py`.
- `main.py` entry point uses `argparse`; `--test` runs pytest, `--log` sets log path.

### Changed – Code quality
- All emojis removed from source code and variable names.
- `from __future__ import annotations` added to every module (PEP 563).
- Type annotations on all public functions and methods.
- `pyproject.toml` replaces `setup.py` / `requirements.txt` (PEP 517/621).
- `ruff` configured for lint + format (replaces flake8 + isort + black).
- `mypy` configured for the core layer.
- Bare `except:` clauses replaced with specific exception types throughout.
- Atomic file writes via `tmp` + `os.replace()` prevent data corruption.

### Added
- `budgetplanner/tests/test_models.py` – 30 pytest unit tests.
- `.github/workflows/ci.yml` – CI matrix: lint + test on Win/Mac/Linux × Py 3.10-3.12,
  automatic EXE build + GitHub Release on version tags.
- `CHANGELOG.md` (this file).
- `pyproject.toml` with optional `[dev]` extra.

### Removed
- Legacy `run_tests()` function replaced by pytest.

---

## [5.0.0] – 2025-05-10

### Added
- Unsaved-changes indicator (`*` in window title).
- Autosave every 2 minutes with toggle in status bar.
- Status bar with save state feedback.
- Bulk actions: multi-select, bulk delete, bulk move, bulk re-categorise.
- Inline editing: double-click an item name to rename in place.
- Keyboard shortcuts: `Ctrl+S`, `Ctrl+Z`, `Ctrl+Y`, `Ctrl+F`, `Ctrl+N`, `Ctrl+D`, `F5`, `Del`.
- Hover highlight on every item row.
- `logging` module – writes to `budgetplanner.log`.
- Atomic writes via `os.replace()`.

---

## [4.0.0] – 2025-05-05

### Added
- Delete mode for main categories and subcategories (not just items).
- Enhanced forecast system: moving average, seasonal patterns, best/worst-case scenarios.
- Banking-style Dashboard tab with KPI cards and finance score.
- AI analysis tab: month-over-month comparison, spending tips, outlier detection.
- Rule-based automation tab: keyword → category rules, persistent storage.

---

## [3.0.0] – 2025-04-28

### Added
- Multi-savings-goals with progress bars, deposit function and monthly-rate estimation.
- Intelligent budget warnings: four colour-coded levels (ok / warn / over / critical).
- Live search / filter across all categories and items.
- Improved charts: percentage comparison, saving-rate trend, top-categories history.
- Drag-and-drop reordering of items within and across subcategories.

---

## [2.0.0] – 2025-04-20

### Added
- Auto-categorisation for CSV import with 60+ built-in keywords.
- Learning system: manually corrected assignments are stored and reused.
- `BudgetModel` class (MVC model layer, separated from UI).
- Undo / Redo system (50-step history stack).
- Multi-profile system: create, switch, and delete profiles.

---

## [1.0.0] – 2025-04-10

### Added
- Initial release: category tree, monthly saving, CSV export, PDF export.
- Dark / light theme toggle.
- Month navigation with auto-fill from previous month.
- Budget limit warnings per category.
- Monthly comparison charts and year overview.
- Trend & forecast tab.
