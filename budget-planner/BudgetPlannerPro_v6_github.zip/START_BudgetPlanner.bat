@echo off
setlocal EnableDelayedExpansion

:: ================================================================
:: BudgetPlanner Pro - Setup und Start
:: Einfach doppelklicken!
:: ================================================================

title BudgetPlanner Pro - Setup und Start
color 0A
cls

echo.
echo  ============================================
echo   BudgetPlanner Pro v5.0 - Setup und Start
echo  ============================================
echo.

:: Arbeitsverzeichnis auf den Ordner des Scripts setzen
cd /d "%~dp0"

:: ================================================================
:: SCHRITT 1: Python suchen
:: ================================================================
echo  [1/4] Pruefe Python...

set "PYTHON_CMD="

:: py.exe (Python Launcher) - zuverlaessigste Methode
py --version >nul 2>&1
if %errorlevel% equ 0 (
    set "PYTHON_CMD=py"
    goto :python_found
)

:: python3
python3 --version >nul 2>&1
if %errorlevel% equ 0 (
    set "PYTHON_CMD=python3"
    goto :python_found
)

:: python - aber Store-Stub ausschliessen
python --version >nul 2>&1
if %errorlevel% equ 0 (
    python --version 2>&1 | findstr /i "python" >nul
    if !errorlevel! equ 0 (
        set "PYTHON_CMD=python"
        goto :python_found
    )
)

:: Direkte Pfade pruefen
for /d %%D in ("%LOCALAPPDATA%\Programs\Python\Python3*") do (
    if exist "%%D\python.exe" (
        set "PYTHON_CMD=%%D\python.exe"
        goto :python_found
    )
)

for /d %%D in ("C:\Python3*") do (
    if exist "%%D\python.exe" (
        set "PYTHON_CMD=%%D\python.exe"
        goto :python_found
    )
)

if exist "C:\Program Files\Python312\python.exe" (
    set "PYTHON_CMD=C:\Program Files\Python312\python.exe"
    goto :python_found
)

:: Python nicht gefunden -> installieren
goto :install_python

:python_found
echo       OK: Python gefunden
goto :check_version

:: ================================================================
:: Python installieren
:: ================================================================
:install_python
echo.
echo  Python nicht gefunden. Installation wird gestartet...
echo.

:: Internetverbindung pruefen
ping -n 1 -w 3000 8.8.8.8 >nul 2>&1
if %errorlevel% neq 0 (
    echo  FEHLER: Keine Internetverbindung!
    echo.
    echo  Bitte Python manuell installieren:
    echo  1. https://python.org/downloads aufrufen
    echo  2. "Download Python 3.12.x" klicken
    echo  3. Installer starten - WICHTIG: "Add Python to PATH" aktivieren!
    echo  4. Dieses Script erneut starten
    echo.
    pause
    exit /b 1
)

:: winget versuchen
winget --version >nul 2>&1
if %errorlevel% equ 0 (
    echo  Installiere Python 3.12 via winget...
    echo  (Bitte warten, ca. 1-2 Minuten)
    winget install --id Python.Python.3.12 --silent --accept-package-agreements --accept-source-agreements
    set "PATH=%PATH%;%LOCALAPPDATA%\Programs\Python\Python312;%LOCALAPPDATA%\Programs\Python\Python312\Scripts"
    if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" (
        set "PYTHON_CMD=%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
        echo  OK: Python installiert!
        goto :check_version
    )
    py --version >nul 2>&1
    if %errorlevel% equ 0 (
        set "PYTHON_CMD=py"
        echo  OK: Python installiert!
        goto :check_version
    )
)

:: PowerShell Download als Fallback
echo  Lade Python-Installer herunter (ca. 25 MB)...
powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -Uri 'https://www.python.org/ftp/python/3.12.7/python-3.12.7-amd64.exe' -OutFile '%TEMP%\python_setup.exe' -UseBasicParsing"

if not exist "%TEMP%\python_setup.exe" (
    echo.
    echo  FEHLER: Download fehlgeschlagen.
    echo  Bitte Python manuell installieren: https://python.org/downloads
    echo.
    pause
    exit /b 1
)

echo  Installiere Python (bitte warten)...
"%TEMP%\python_setup.exe" /quiet InstallAllUsers=0 PrependPath=1 Include_test=0 Include_pip=1
del /f /q "%TEMP%\python_setup.exe" >nul 2>&1

set "PATH=%PATH%;%LOCALAPPDATA%\Programs\Python\Python312;%LOCALAPPDATA%\Programs\Python\Python312\Scripts"

if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" (
    set "PYTHON_CMD=%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
    echo  OK: Python installiert!
    goto :check_version
)

echo.
echo  FEHLER: Python-Installation fehlgeschlagen!
echo.
echo  Bitte Python manuell installieren:
echo  1. https://python.org/downloads aufrufen
echo  2. "Download Python 3.12.x" klicken
echo  3. Installer starten - WICHTIG: "Add Python to PATH" aktivieren!
echo  4. Dieses Script erneut starten
echo.
pause
exit /b 1

:: ================================================================
:: SCHRITT 2: Python-Version pruefen
:: ================================================================
:check_version
echo  [2/4] Pruefe Python-Version...

for /f "tokens=2 delims= " %%V in ('"%PYTHON_CMD%" --version 2^>^&1') do set "PY_VERSION=%%V"
echo       Version: %PY_VERSION%

for /f "tokens=1,2 delims=." %%A in ("%PY_VERSION%") do (
    set "PY_MAJOR=%%A"
    set "PY_MINOR=%%B"
)

if !PY_MAJOR! lss 3 goto :version_too_old
if !PY_MAJOR! equ 3 (
    if !PY_MINOR! lss 9 goto :version_too_old
)
echo       OK: Version ausreichend
goto :install_packages

:version_too_old
echo.
echo  FEHLER: Python 3.9 oder neuer benoetigt (gefunden: %PY_VERSION%)
echo  Bitte Python aktualisieren: https://python.org/downloads
echo.
pause
exit /b 1

:: ================================================================
:: SCHRITT 3: Pakete installieren
:: ================================================================
:install_packages
echo  [3/4] Pruefe und installiere Pakete...
echo.

"%PYTHON_CMD%" -m pip --version >nul 2>&1
if %errorlevel% neq 0 (
    echo       pip nicht gefunden, wird eingerichtet...
    "%PYTHON_CMD%" -m ensurepip --upgrade >nul 2>&1
)

"%PYTHON_CMD%" -m pip install --upgrade pip --quiet >nul 2>&1

call :check_and_install matplotlib matplotlib
call :check_and_install numpy numpy
call :check_and_install reportlab reportlab
call :check_and_install PIL Pillow

echo.
echo       Alle Pakete bereit!
goto :start_app

:check_and_install
set "MOD=%~1"
set "PKG=%~2"
"%PYTHON_CMD%" -c "import %MOD%" >nul 2>&1
if %errorlevel% neq 0 (
    echo       Installiere %PKG%...
    "%PYTHON_CMD%" -m pip install %PKG% --quiet
    if %errorlevel% neq 0 (
        echo       2. Versuch ohne --quiet...
        "%PYTHON_CMD%" -m pip install %PKG%
    )
    "%PYTHON_CMD%" -c "import %MOD%" >nul 2>&1
    if %errorlevel% neq 0 (
        echo.
        echo  FEHLER: %PKG% konnte nicht installiert werden!
        echo  Bitte manuell ausfuehren:
        echo    "%PYTHON_CMD%" -m pip install %PKG%
        echo.
        pause
        exit /b 1
    )
    echo       OK: %PKG% installiert
) else (
    echo       OK: %MOD%
)
goto :eof

:: ================================================================
:: SCHRITT 4: App starten
:: ================================================================
:start_app
echo  [4/4] Starte BudgetPlanner Pro...
echo.

set "APP_FILE=%~dp0BudgetPlanner_v5.py"

if not exist "%APP_FILE%" (
    echo  FEHLER: BudgetPlanner_v5.py nicht gefunden!
    echo.
    echo  Gesucht in: %~dp0
    echo.
    echo  Vorhandene Python-Dateien in diesem Ordner:
    dir /b "%~dp0*.py" 2>nul
    echo.
    echo  Bitte sicherstellen dass START_BudgetPlanner.bat
    echo  und BudgetPlanner_v5.py im gleichen Ordner liegen.
    echo.
    pause
    exit /b 1
)

echo  ============================================
echo   App startet jetzt. Bitte warten...
echo  ============================================
echo.

"%PYTHON_CMD%" "%APP_FILE%"

if %errorlevel% neq 0 (
    echo.
    echo  ============================================
    echo   App mit Fehler beendet (Code: %errorlevel%)
    echo  ============================================
    echo.
    echo  Versuche das:
    echo    "%PYTHON_CMD%" -m pip install --upgrade matplotlib numpy reportlab Pillow
    echo.
    pause
)

endlocal
