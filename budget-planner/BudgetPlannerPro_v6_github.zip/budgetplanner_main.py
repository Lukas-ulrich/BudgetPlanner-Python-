"""
BudgetPlanner Pro – application entry point.

Usage:
    python main.py              # start the GUI
    python main.py --test       # run the legacy integration checks
"""
from __future__ import annotations

import argparse
import logging
import sys
from pathlib import Path


def _configure_logging(log_file: Path) -> None:
    logging.basicConfig(
        level=logging.WARNING,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        handlers=[
            logging.FileHandler(log_file, encoding="utf-8"),
            logging.StreamHandler(sys.stdout),
        ],
    )


def _run_tests() -> None:
    """Thin wrapper that invokes pytest programmatically."""
    try:
        import pytest
    except ImportError:
        print("pytest not installed.  Run:  pip install pytest")
        sys.exit(1)

    exit_code = pytest.main([
        "budgetplanner/tests/",
        "-v",
        "--tb=short",
    ])
    sys.exit(exit_code)


def _start_gui() -> None:
    import tkinter as tk
    from budgetplanner.ui.app import BudgetApp

    root = tk.Tk()
    _app = BudgetApp(root)
    root.mainloop()


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="BudgetPlanner Pro",
        description="Personal budget tracker with charts and forecasting.",
    )
    parser.add_argument(
        "--test",
        action="store_true",
        help="Run the test suite instead of launching the GUI.",
    )
    parser.add_argument(
        "--log",
        default="budgetplanner.log",
        metavar="FILE",
        help="Path for the log file (default: budgetplanner.log).",
    )
    args = parser.parse_args()

    _configure_logging(Path(args.log))

    if args.test:
        _run_tests()
    else:
        _start_gui()


if __name__ == "__main__":
    main()
