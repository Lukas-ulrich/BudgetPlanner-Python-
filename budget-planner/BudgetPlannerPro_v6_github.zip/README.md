# BudgetPlanner Pro

[![CI](https://github.com/your-username/budgetplanner/actions/workflows/ci.yml/badge.svg)](https://github.com/your-username/budgetplanner/actions)
[![Python](https://img.shields.io/badge/python-3.10%20%7C%203.11%20%7C%203.12-blue)](https://www.python.org)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)
[![Code style: ruff](https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/astral-sh/ruff/main/assets/badge/v2.json)](https://github.com/astral-sh/ruff)

Personal budget tracker built with Python and Tkinter.
Charts, multi-month forecasts, AI-based spending analysis and CSV bank import
with automatic categorisation – packaged as a standalone desktop app.

---

## Screenshots

> Add screenshots to `docs/screenshots/` and reference them here.

---

## Features

| Feature | Description |
|---|---|
| Budget entry | Category tree with subcategories and line items |
| Auto-categorisation | CSV bank import with 60+ built-in keywords + learned rules |
| Rule editor | Persistent keyword-to-category rules |
| Charts | Monthly trend, % comparison, saving rate, top-category history, pie |
| Forecasting | Linear trend, moving average, seasonal patterns, best/worst-case |
| Savings goals | Multiple goals with progress bars and monthly rate estimation |
| Dashboard | KPI cards, budget-limit gauges, finance score |
| AI analysis | Month-over-month comparison, outlier detection, personalised tips |
| Undo / Redo | 50-step history |
| Autosave | Every 2 minutes, configurable |
| Bulk actions | Multi-select, bulk delete, bulk move, bulk re-categorise |
| Inline editing | Double-click to rename any item |
| Keyboard shortcuts | `Ctrl+S`, `Ctrl+Z/Y`, `Ctrl+F`, `F5`, `Del`, … |
| Multi-profile | Separate data per user / household member |
| Dark / light theme | Toggle at any time |

---

## Quick start

### Option A – one-click (Windows)

```
Double-click  START_BudgetPlanner.bat
```

The script detects and installs Python automatically if needed,
then installs all dependencies and launches the app.

### Option B – manual

```bash
git clone https://github.com/your-username/budgetplanner.git
cd budgetplanner
pip install -e .
python budgetplanner_main.py
```

### Option C – standalone EXE (no Python required)

Download the latest release from the
[Releases](https://github.com/your-username/budgetplanner/releases) page
and run `BudgetPlannerPro.exe`.

---

## Development

### Set up

```bash
git clone https://github.com/your-username/budgetplanner.git
cd budgetplanner
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -e ".[dev]"
```

### Run tests

```bash
pytest                          # all tests
pytest -v                       # verbose
pytest --cov=budgetplanner      # with coverage report
```

### Lint and format

```bash
ruff check budgetplanner/       # lint
ruff format budgetplanner/      # auto-format
mypy budgetplanner/core/        # type-check
```

### Build Windows EXE

```bash
pip install pyinstaller
python build_windows.py
# -> dist/BudgetPlannerPro/BudgetPlannerPro.exe
```

### Release workflow

```bash
git tag v6.1.0
git push origin v6.1.0
# CI builds the EXE and creates a GitHub Release automatically
```

---

## Project structure

```
budgetplanner/
├── core/
│   ├── constants.py       # app-wide constants, keyword map
│   └── models.py          # BudgetModel, UndoRedoManager, SavingsGoal
├── ui/
│   ├── app.py             # BudgetApp (main window)
│   ├── theme.py           # ThemeManager, Palette dataclass
│   └── widgets.py         # reusable widget factories
├── utils/
│   └── io.py              # CSV / PDF helpers
└── tests/
    └── test_models.py     # pytest unit tests

budgetplanner_main.py      # entry point  (python budgetplanner_main.py)
pyproject.toml             # packaging + tool config
build_windows.py           # PyInstaller build script
START_BudgetPlanner.bat    # one-click Windows launcher
START_BudgetPlanner.sh     # one-click macOS / Linux launcher
CHANGELOG.md
```

---

## Requirements

| | Minimum | Recommended |
|---|---|---|
| Python | 3.10 | 3.12 |
| OS | Windows 10 / macOS 11 / Ubuntu 20.04 | Latest |
| RAM | 256 MB | 512 MB |
| Display | 1280 x 720 | 1920 x 1080 |

Python packages: `matplotlib`, `numpy`, `reportlab`, `Pillow`
(all installed automatically via `pip install -e .`)

---

## Data storage

All data is stored locally in the `profiles/` directory next to the executable.
No data is ever sent to a server.

```
profiles/
└── default/
    ├── budget_2025-01.json
    ├── budget_2025-02.json
    └── settings.json
```

To back up your data, copy the entire `profiles/` folder.

---

## Contributing

1. Fork the repository
2. Create a feature branch: `git checkout -b feature/my-feature`
3. Write tests for your change
4. Run `pytest` and `ruff check` – both must pass
5. Open a pull request against `main`

---

## License

MIT – see [LICENSE](LICENSE) for details.
