"""
BudgetPlanner Pro – Windows EXE Build Script
=============================================
Erstellt eine standalone .exe mit PyInstaller.

Voraussetzungen (einmalig):
    pip install pyinstaller pillow matplotlib numpy reportlab

Ausführen:
    python build_windows.py

Ergebnis:
    dist/BudgetPlannerPro/BudgetPlannerPro.exe   (Ordner-Modus)
    dist/BudgetPlannerPro_portable.exe            (Single-File, langsamer Start)
"""

import subprocess
import sys
import os
import shutil
from pathlib import Path

# ── Konfiguration ──────────────────────────────────────────────────────────────
APP_NAME        = "BudgetPlannerPro"
MAIN_SCRIPT     = "BudgetPlanner_v5.py"   # ← ggf. anpassen
ICON_FILE       = "icon.ico"              # ← liegt im selben Ordner
VERSION         = "5.0.0"
AUTHOR          = "BudgetPlanner"
BUILD_DIR       = "build"
DIST_DIR        = "dist"
# ──────────────────────────────────────────────────────────────────────────────


def check_requirements():
    """Prüft ob alle nötigen Pakete installiert sind."""
    required = ["PyInstaller", "PIL", "matplotlib", "numpy", "reportlab"]
    missing = []
    for pkg in required:
        try:
            __import__(pkg if pkg != "PIL" else "PIL.Image")
        except ImportError:
            missing.append(pkg.lower() if pkg != "PIL" else "pillow")

    if missing:
        print("❌ Fehlende Pakete:", ", ".join(missing))
        print(f"   Installiere mit:  pip install {' '.join(missing)}")
        return False
    print("✅ Alle Pakete vorhanden")
    return True


def build_directory_mode():
    """
    Ordner-Modus: Schneller Start, alle Dateien in einem Ordner.
    Ideal zum Testen und für USB-Sticks.
    """
    print("\n📦 Baue Ordner-Version (schneller Start)…")

    cmd = [
        sys.executable, "-m", "PyInstaller",
        "--noconfirm",
        "--clean",
        f"--name={APP_NAME}",
        f"--distpath={DIST_DIR}",
        f"--workpath={BUILD_DIR}",
        "--windowed",                    # kein Konsolfenster
        f"--icon={ICON_FILE}",
        "--add-data=profiles;profiles",  # Profil-Ordner mitpacken (Windows: ;)
        # Matplotlib Backend
        "--hidden-import=matplotlib.backends.backend_tkagg",
        "--hidden-import=matplotlib.backends._backend_tk",
        # Pillow
        "--hidden-import=PIL._tkinter_finder",
        # Reportlab (optional, für PDF)
        "--hidden-import=reportlab.lib.pagesizes",
        "--hidden-import=reportlab.pdfgen.canvas",
        "--collect-all=matplotlib",
        "--collect-all=numpy",
        MAIN_SCRIPT,
    ]

    result = subprocess.run(cmd, capture_output=False)
    if result.returncode == 0:
        exe_path = Path(DIST_DIR) / APP_NAME / f"{APP_NAME}.exe"
        print(f"\n✅ Fertig! EXE: {exe_path.absolute()}")
        return exe_path
    else:
        print("❌ Build fehlgeschlagen.")
        return None


def build_single_file():
    """
    Single-File Modus: Eine einzige .exe (langsamerer Start, weil entpackt wird).
    Ideal für einfache Weitergabe per E-Mail/Download.
    """
    print("\n📦 Baue Single-File-Version (eine .exe)…")

    cmd = [
        sys.executable, "-m", "PyInstaller",
        "--noconfirm",
        "--clean",
        f"--name={APP_NAME}_portable",
        f"--distpath={DIST_DIR}",
        f"--workpath={BUILD_DIR}",
        "--onefile",                     # ← Single File
        "--windowed",
        f"--icon={ICON_FILE}",
        "--hidden-import=matplotlib.backends.backend_tkagg",
        "--hidden-import=matplotlib.backends._backend_tk",
        "--hidden-import=PIL._tkinter_finder",
        "--hidden-import=reportlab.lib.pagesizes",
        "--hidden-import=reportlab.pdfgen.canvas",
        "--collect-all=matplotlib",
        "--collect-all=numpy",
        MAIN_SCRIPT,
    ]

    result = subprocess.run(cmd, capture_output=False)
    if result.returncode == 0:
        exe_path = Path(DIST_DIR) / f"{APP_NAME}_portable.exe"
        print(f"\n✅ Fertig! Portable EXE: {exe_path.absolute()}")
        return exe_path
    else:
        print("❌ Build fehlgeschlagen.")
        return None


def create_zip_package(exe_folder: Path):
    """Packt den Ordner als .zip für einfache Weitergabe."""
    if not exe_folder or not exe_folder.exists():
        return
    zip_name = Path(DIST_DIR) / f"{APP_NAME}_v{VERSION}_Windows"
    shutil.make_archive(str(zip_name), "zip", str(exe_folder.parent), exe_folder.name)
    print(f"📁 ZIP erstellt: {zip_name}.zip")


def print_usage_instructions(exe_path):
    """Druckt Nutzungshinweise nach dem Build."""
    if not exe_path:
        return
    print("\n" + "═"*60)
    print("🚀 BUILD ABGESCHLOSSEN")
    print("═"*60)
    print(f"\n  App:     {exe_path}")
    print(f"  Version: {VERSION}")
    print("\n📋 WEITERGABE:")
    print("  1. Ordner-Modus: Ganzen dist/BudgetPlannerPro/ Ordner zippen")
    print("  2. Portable:     Nur BudgetPlannerPro_portable.exe teilen")
    print("\n⚠️  HINWEIS:")
    print("  Windows Defender kann die .exe beim ersten Start scannen.")
    print("  Das ist normal bei unsigned Apps. Einfach 'Trotzdem ausführen'.")
    print("  → Für Produktions-Apps: Code-Signing-Zertifikat empfohlen (~100€/Jahr)")
    print("\n💡 TIPP: profiles/ Ordner liegt neben der .exe")
    print("   → Daten bleiben beim Update erhalten!")
    print("═"*60)


if __name__ == "__main__":
    print("=" * 60)
    print("   BudgetPlanner Pro – Build-Script")
    print("=" * 60)

    if not os.path.exists(MAIN_SCRIPT):
        print(f"❌ Hauptdatei nicht gefunden: {MAIN_SCRIPT}")
        sys.exit(1)

    if not check_requirements():
        sys.exit(1)

    # Ordner-Modus (empfohlen)
    exe_folder = build_directory_mode()

    if exe_folder and exe_folder.exists():
        create_zip_package(exe_folder.parent)
        print_usage_instructions(exe_folder)
    else:
        # Fallback: Single-File
        single = build_single_file()
        print_usage_instructions(single)
