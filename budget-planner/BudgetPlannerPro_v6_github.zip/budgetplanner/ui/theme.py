"""
Theme manager – provides colour palettes for dark and light mode.
"""
from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Palette:
    bg:           str
    bg_secondary: str
    bg_tertiary:  str
    bg_input:     str
    fg:           str
    fg_secondary: str
    fg_muted:     str
    accent:       str
    success:      str
    danger:       str
    warning:      str


DARK = Palette(
    bg           = "#1a1a1a",
    bg_secondary = "#252526",
    bg_tertiary  = "#2d2d30",
    bg_input     = "#3e3e42",
    fg           = "#ffffff",
    fg_secondary = "#e0e0e0",
    fg_muted     = "#b0b0b0",
    accent       = "#0078d4",
    success      = "#107c10",
    danger       = "#d13438",
    warning      = "#ffd700",
)

LIGHT = Palette(
    bg           = "#f5f5f5",
    bg_secondary = "#ffffff",
    bg_tertiary  = "#e8e8e8",
    bg_input     = "#ffffff",
    fg           = "#000000",
    fg_secondary = "#333333",
    fg_muted     = "#666666",
    accent       = "#0078d4",
    success      = "#107c10",
    danger       = "#d13438",
    warning      = "#ff8c00",
)


class ThemeManager:
    def __init__(self, dark: bool = True) -> None:
        self._dark = dark

    @property
    def palette(self) -> Palette:
        return DARK if self._dark else LIGHT

    @property
    def is_dark(self) -> bool:
        return self._dark

    def toggle(self) -> None:
        self._dark = not self._dark

    def set_dark(self, value: bool) -> None:
        self._dark = value

    def lighten(self, hex_colour: str, amount: int = 20) -> str:
        """Return a slightly lighter version of *hex_colour*."""
        h = hex_colour.lstrip("#")
        r, g, b = (int(h[i:i + 2], 16) for i in (0, 2, 4))
        return (
            f"#{min(255, r + amount):02x}"
            f"{min(255, g + amount):02x}"
            f"{min(255, b + amount):02x}"
        )
