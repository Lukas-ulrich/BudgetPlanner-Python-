"""
Reusable Tkinter widget helpers.

Every widget factory accepts a Palette so it can be restyled without
touching business logic.
"""
from __future__ import annotations

import tkinter as tk
from tkinter import ttk
from typing import Callable, Optional

from budgetplanner.ui.theme import Palette


# ---------------------------------------------------------------------------
# Button factory
# ---------------------------------------------------------------------------
def make_button(
    parent: tk.Widget,
    text: str,
    command: Callable,
    colour: str,
    palette: Palette,
    width: Optional[int] = None,
) -> tk.Button:
    btn = tk.Button(
        parent,
        text=text,
        command=command,
        bg=colour,
        fg="white",
        font=("Segoe UI", 9, "bold"),
        relief="flat",
        cursor="hand2",
        padx=12,
        pady=6,
        borderwidth=0,
    )
    if width is not None:
        btn.config(width=width)

    lighter = _lighten(colour)
    btn.bind("<Enter>", lambda _: btn.config(bg=lighter))
    btn.bind("<Leave>", lambda _: btn.config(bg=colour))
    return btn


# ---------------------------------------------------------------------------
# Stat card  (label + big value)
# ---------------------------------------------------------------------------
def make_stat_card(
    parent: tk.Widget,
    title: str,
    palette: Palette,
    value_colour: str,
    initial_value: str = "0.00 EUR",
) -> tuple[tk.Frame, tk.Label]:
    """Return (frame, value_label) so callers can update the label."""
    card = tk.Frame(parent, bg=palette.bg_tertiary, relief="flat")
    card.pack(fill="x", pady=5)

    tk.Label(
        card,
        text=title,
        bg=palette.bg_tertiary,
        fg=palette.fg_muted,
        font=("Segoe UI", 9),
    ).pack(anchor="w", padx=12, pady=(8, 2))

    val_lbl = tk.Label(
        card,
        text=initial_value,
        bg=palette.bg_tertiary,
        fg=value_colour,
        font=("Segoe UI", 14, "bold"),
    )
    val_lbl.pack(anchor="w", padx=12, pady=(0, 8))
    return card, val_lbl


# ---------------------------------------------------------------------------
# Horizontal progress bar (canvas-based for custom colours)
# ---------------------------------------------------------------------------
def make_progress_bar(
    parent: tk.Widget,
    height: int = 18,
    bg_colour: str = "#2d2d30",
) -> tk.Canvas:
    bar = tk.Canvas(parent, height=height, bg=bg_colour, highlightthickness=0)
    return bar


def draw_progress_bar(
    canvas: tk.Canvas,
    pct: float,
    fill_colour: str,
    label: str = "",
    bg_colour: str = "#2d2d30",
) -> None:
    canvas.delete("all")
    w = canvas.winfo_width()
    h = canvas.winfo_height()
    if w <= 1:
        return
    canvas.create_rectangle(0, 0, w, h, fill=bg_colour, outline="")
    filled = int(w * min(pct, 100.0) / 100.0)
    if filled > 0:
        canvas.create_rectangle(0, 0, filled, h, fill=fill_colour, outline="")
    if label:
        canvas.create_text(
            w // 2, h // 2,
            text=label,
            fill="white",
            font=("Segoe UI", 8, "bold"),
        )


# ---------------------------------------------------------------------------
# Scrollable frame
# ---------------------------------------------------------------------------
class ScrollFrame(tk.Frame):
    """A frame with a vertical scrollbar; children go into .inner."""

    def __init__(self, parent: tk.Widget, palette: Palette, **kwargs) -> None:
        super().__init__(parent, bg=palette.bg, **kwargs)

        canvas    = tk.Canvas(self, bg=palette.bg, highlightthickness=0)
        scrollbar = ttk.Scrollbar(self, orient="vertical", command=canvas.yview)
        self.inner = tk.Frame(canvas, bg=palette.bg)

        self.inner.bind(
            "<Configure>",
            lambda _: canvas.configure(scrollregion=canvas.bbox("all")),
        )
        canvas.create_window((0, 0), window=self.inner, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        canvas.bind_all(
            "<MouseWheel>",
            lambda e: canvas.yview_scroll(int(-1 * (e.delta / 120)), "units"),
        )
        self._canvas = canvas

    def scroll_to_top(self) -> None:
        self._canvas.yview_moveto(0.0)


# ---------------------------------------------------------------------------
# Section header (coloured title bar for category groups)
# ---------------------------------------------------------------------------
def make_section_header(
    parent: tk.Widget,
    title: str,
    palette: Palette,
    accent_colour: Optional[str] = None,
) -> tk.Frame:
    colour = accent_colour or palette.bg_tertiary
    frame  = tk.Frame(parent, bg=colour, height=4)
    frame.pack(fill="x")
    tk.Label(
        frame,
        text=title,
        bg=colour,
        fg=palette.fg,
        font=("Segoe UI", 11, "bold"),
        anchor="w",
    ).pack(side="left", padx=12, pady=6)
    return frame


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _lighten(hex_colour: str, amount: int = 20) -> str:
    h = hex_colour.lstrip("#")
    r, g, b = (int(h[i:i + 2], 16) for i in (0, 2, 4))
    return (
        f"#{min(255, r + amount):02x}"
        f"{min(255, g + amount):02x}"
        f"{min(255, b + amount):02x}"
    )
