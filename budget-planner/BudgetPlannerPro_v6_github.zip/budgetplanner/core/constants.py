"""
Application-wide constants.

Separating constants from logic makes them easy to override in tests
and keeps magic strings out of business logic.
"""
from __future__ import annotations

APP_NAME    = "BudgetPlanner Pro"
APP_VERSION = "6.0.0"

# ---------------------------------------------------------------------------
# Storage
# ---------------------------------------------------------------------------
BASE_FOLDER   = "profiles"
DEFAULT_PROFILE = "default"
SETTINGS_FILE = "settings.json"

UNDO_STACK_SIZE = 50
AUTOSAVE_INTERVAL_MS = 120_000   # 2 minutes

# ---------------------------------------------------------------------------
# Default category structure
# ---------------------------------------------------------------------------
DEFAULT_STRUCTURE: dict[str, dict[str, list[str]]] = {
    "Einnahmen": {
        "Gehalt":    ["Gehalt Hauptjob", "Nebentatigkeit"],
        "Sonstiges": ["Geschenke", "Verkauf"],
    },
    "Fixkosten": {
        "Wohnen":        ["Miete", "Strom", "Wasser"],
        "Versicherungen": ["Krankenversicherung", "Hausrat"],
    },
    "Variable Kosten": {
        "Essen":   ["Supermarkt", "Restaurant"],
        "Freizeit": ["Abos", "Urlaub", "Kino"],
    },
    "Sparen": {
        "Ziele": ["Notgroschen", "Urlaub", "Rente"],
    },
}

# ---------------------------------------------------------------------------
# Auto-categorisation keyword map
# format: keyword_lowercase -> (main_category, sub_category, item)
# ---------------------------------------------------------------------------
CATEGORY_KEYWORDS: dict[str, tuple[str, str, str]] = {
    # --- Einnahmen ---
    "gehalt":           ("Einnahmen", "Gehalt",    "Gehalt Hauptjob"),
    "lohn":             ("Einnahmen", "Gehalt",    "Gehalt Hauptjob"),
    "salary":           ("Einnahmen", "Gehalt",    "Gehalt Hauptjob"),
    "nebenjob":         ("Einnahmen", "Gehalt",    "Nebentatigkeit"),
    "freiberuf":        ("Einnahmen", "Gehalt",    "Nebentatigkeit"),
    "geschenk":         ("Einnahmen", "Sonstiges", "Geschenke"),
    "ebay":             ("Einnahmen", "Sonstiges", "Verkauf"),
    "verkauf":          ("Einnahmen", "Sonstiges", "Verkauf"),
    "paypal":           ("Einnahmen", "Sonstiges", "Verkauf"),
    # --- Fixkosten Wohnen ---
    "miete":            ("Fixkosten", "Wohnen", "Miete"),
    "warmmiete":        ("Fixkosten", "Wohnen", "Miete"),
    "kaltmiete":        ("Fixkosten", "Wohnen", "Miete"),
    "strom":            ("Fixkosten", "Wohnen", "Strom"),
    "energie":          ("Fixkosten", "Wohnen", "Strom"),
    "vattenfall":       ("Fixkosten", "Wohnen", "Strom"),
    "eon":              ("Fixkosten", "Wohnen", "Strom"),
    "wasser":           ("Fixkosten", "Wohnen", "Wasser"),
    "stadtwerke":       ("Fixkosten", "Wohnen", "Strom"),
    "gas":              ("Fixkosten", "Wohnen", "Strom"),
    # --- Fixkosten Versicherungen ---
    "versicherung":     ("Fixkosten", "Versicherungen", "Hausrat"),
    "krankenkasse":     ("Fixkosten", "Versicherungen", "Krankenversicherung"),
    "krankenversicherung": ("Fixkosten", "Versicherungen", "Krankenversicherung"),
    "aok":              ("Fixkosten", "Versicherungen", "Krankenversicherung"),
    "tkk":              ("Fixkosten", "Versicherungen", "Krankenversicherung"),
    "barmer":           ("Fixkosten", "Versicherungen", "Krankenversicherung"),
    "hausrat":          ("Fixkosten", "Versicherungen", "Hausrat"),
    "huk":              ("Fixkosten", "Versicherungen", "Hausrat"),
    # --- Variable Kosten Essen ---
    "rewe":             ("Variable Kosten", "Essen", "Supermarkt"),
    "edeka":            ("Variable Kosten", "Essen", "Supermarkt"),
    "aldi":             ("Variable Kosten", "Essen", "Supermarkt"),
    "lidl":             ("Variable Kosten", "Essen", "Supermarkt"),
    "netto":            ("Variable Kosten", "Essen", "Supermarkt"),
    "penny":            ("Variable Kosten", "Essen", "Supermarkt"),
    "kaufland":         ("Variable Kosten", "Essen", "Supermarkt"),
    "norma":            ("Variable Kosten", "Essen", "Supermarkt"),
    "supermarkt":       ("Variable Kosten", "Essen", "Supermarkt"),
    "lebensmittel":     ("Variable Kosten", "Essen", "Supermarkt"),
    "backerei":         ("Variable Kosten", "Essen", "Supermarkt"),
    "metzger":          ("Variable Kosten", "Essen", "Supermarkt"),
    "restaurant":       ("Variable Kosten", "Essen", "Restaurant"),
    "gasthaus":         ("Variable Kosten", "Essen", "Restaurant"),
    "lieferando":       ("Variable Kosten", "Essen", "Restaurant"),
    "pizza":            ("Variable Kosten", "Essen", "Restaurant"),
    "mcdonalds":        ("Variable Kosten", "Essen", "Restaurant"),
    "burger":           ("Variable Kosten", "Essen", "Restaurant"),
    "cafe":             ("Variable Kosten", "Essen", "Restaurant"),
    "kaffee":           ("Variable Kosten", "Essen", "Restaurant"),
    # --- Variable Kosten Freizeit ---
    "netflix":          ("Variable Kosten", "Freizeit", "Abos"),
    "spotify":          ("Variable Kosten", "Freizeit", "Abos"),
    "amazon prime":     ("Variable Kosten", "Freizeit", "Abos"),
    "disney":           ("Variable Kosten", "Freizeit", "Abos"),
    "abo":              ("Variable Kosten", "Freizeit", "Abos"),
    "mitglied":         ("Variable Kosten", "Freizeit", "Abos"),
    "fitness":          ("Variable Kosten", "Freizeit", "Abos"),
    "gym":              ("Variable Kosten", "Freizeit", "Abos"),
    "kino":             ("Variable Kosten", "Freizeit", "Kino"),
    "cinema":           ("Variable Kosten", "Freizeit", "Kino"),
    "urlaub":           ("Variable Kosten", "Freizeit", "Urlaub"),
    "hotel":            ("Variable Kosten", "Freizeit", "Urlaub"),
    "flug":             ("Variable Kosten", "Freizeit", "Urlaub"),
    "booking":          ("Variable Kosten", "Freizeit", "Urlaub"),
    # --- Sparen ---
    "sparplan":         ("Sparen", "Ziele", "Notgroschen"),
    "tagesgeld":        ("Sparen", "Ziele", "Notgroschen"),
    "sparkasse":        ("Sparen", "Ziele", "Notgroschen"),
    "depot":            ("Sparen", "Ziele", "Rente"),
    "etf":              ("Sparen", "Ziele", "Rente"),
    "aktien":           ("Sparen", "Ziele", "Rente"),
    "rente":            ("Sparen", "Ziele", "Rente"),
    "riester":          ("Sparen", "Ziele", "Rente"),
}

# ---------------------------------------------------------------------------
# Budget warning thresholds (% of limit)
# ---------------------------------------------------------------------------
WARNING_THRESHOLD_WARN     = 80.0
WARNING_THRESHOLD_OVER     = 100.0
WARNING_THRESHOLD_CRITICAL = 120.0

# ---------------------------------------------------------------------------
# UI colour palette keys (resolved at runtime by ThemeManager)
# ---------------------------------------------------------------------------
class ColourKey:
    BG            = "bg"
    BG_SECONDARY  = "bg_secondary"
    BG_TERTIARY   = "bg_tertiary"
    BG_INPUT      = "bg_input"
    FG            = "fg"
    FG_SECONDARY  = "fg_secondary"
    FG_MUTED      = "fg_muted"
    ACCENT        = "accent"
    SUCCESS       = "success"
    DANGER        = "danger"
    WARNING       = "warning"
