"""
Pure data models used throughout BudgetPlanner.

All classes are dataclasses or simple containers – zero UI dependency.
"""
from __future__ import annotations

import copy
import json
import logging
import os
from dataclasses import dataclass, field
from typing import Optional

from budgetplanner.core.constants import (
    BASE_FOLDER,
    CATEGORY_KEYWORDS,
    DEFAULT_PROFILE,
    DEFAULT_STRUCTURE,
    SETTINGS_FILE,
    WARNING_THRESHOLD_CRITICAL,
    WARNING_THRESHOLD_OVER,
    WARNING_THRESHOLD_WARN,
)

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Type aliases
# ---------------------------------------------------------------------------
ItemKey    = tuple[str, str, str]   # (main_cat, sub_cat, item)
EntryValue = dict[str, str]         # {"amount": "0", "note": ""}
Structure  = dict[str, dict[str, list[str]]]


# ---------------------------------------------------------------------------
# Small value objects
# ---------------------------------------------------------------------------
@dataclass
class SavingsGoal:
    name:    str
    target:  float
    saved:   float   = 0.0
    monthly: float   = 0.0
    icon:    str     = "target"

    @property
    def progress_pct(self) -> float:
        return min(self.saved / self.target * 100.0, 100.0) if self.target > 0 else 0.0

    @property
    def months_remaining(self) -> Optional[int]:
        remaining = self.target - self.saved
        if self.monthly > 0 and remaining > 0:
            return int(remaining / self.monthly) + (1 if remaining % self.monthly else 0)
        return None

    def to_dict(self) -> dict:
        return {
            "name":    self.name,
            "target":  self.target,
            "saved":   self.saved,
            "monthly": self.monthly,
            "icon":    self.icon,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "SavingsGoal":
        return cls(
            name    = d.get("name", ""),
            target  = float(d.get("target", 0)),
            saved   = float(d.get("saved", 0)),
            monthly = float(d.get("monthly", 0)),
            icon    = d.get("icon", "target"),
        )


@dataclass
class Totals:
    income:   float
    expense:  float
    fixed:    float
    variable: float
    per_item: dict[ItemKey, float]
    per_main: dict[str, float]

    @property
    def balance(self) -> float:
        return self.income - self.expense

    @property
    def saving_rate(self) -> float:
        return (self.balance / self.income * 100.0) if self.income > 0 else 0.0


# ---------------------------------------------------------------------------
# Budget model
# ---------------------------------------------------------------------------
class BudgetModel:
    """
    All business logic – no Tkinter imports, fully testable.
    """

    def __init__(self) -> None:
        self.structure: Structure          = copy.deepcopy(DEFAULT_STRUCTURE)
        self.values: dict[ItemKey, EntryValue] = {}
        self.budget_warnings: dict[str, float] = {}
        self.dark_mode:          bool      = True
        self.auto_fill_enabled:  bool      = True
        self.current_profile:    str       = DEFAULT_PROFILE
        self.custom_keyword_map: dict[str, tuple[str, str, str]] = {}
        self.savings_goals:      list[SavingsGoal] = []

    # ------------------------------------------------------------------
    # Calculations
    # ------------------------------------------------------------------
    def get_totals(self) -> Totals:
        income = expense = fixed = variable = 0.0
        per_item: dict[ItemKey, float] = {}
        per_main: dict[str, float]     = {}

        for (mc, sc, item), val in self.values.items():
            amt = _to_float(val.get("amount", "0"))
            per_item[(mc, sc, item)] = amt
            per_main[mc]             = per_main.get(mc, 0.0) + amt

            mc_lower = mc.lower()
            if "einnahmen" in mc_lower:
                income += amt
            elif "fix" in mc_lower:
                fixed   += amt
                expense += amt
            else:
                variable += amt
                expense  += amt

        return Totals(
            income   = income,
            expense  = expense,
            fixed    = fixed,
            variable = variable,
            per_item = per_item,
            per_main = per_main,
        )

    def get_top_expenses(self, n: int = 3) -> list[tuple[str, float]]:
        totals = self.get_totals()
        by_sub: dict[str, float] = {}
        for (mc, sc, _item), amt in totals.per_item.items():
            if "einnahmen" not in mc.lower() and amt > 0:
                key = f"{mc} / {sc}"
                by_sub[key] = by_sub.get(key, 0.0) + amt
        return sorted(by_sub.items(), key=lambda x: x[1], reverse=True)[:n]

    def get_budget_warning_level(
        self, main_cat: str, current: float
    ) -> tuple[Optional[str], float]:
        """
        Returns (level, pct_of_limit).
        level is None | 'ok' | 'warn' | 'over' | 'critical'
        """
        limit = self.budget_warnings.get(main_cat)
        if not limit or limit <= 0:
            return None, 0.0
        pct = current / limit * 100.0
        if pct >= WARNING_THRESHOLD_CRITICAL:
            return "critical", pct
        if pct >= WARNING_THRESHOLD_OVER:
            return "over", pct
        if pct >= WARNING_THRESHOLD_WARN:
            return "warn", pct
        return "ok", pct

    # ------------------------------------------------------------------
    # Auto-categorisation
    # ------------------------------------------------------------------
    def categorise(self, description: str, amount: float) -> Optional[ItemKey]:
        """
        Return the best-matching ItemKey or None.
        Priority: learned mappings > built-in keywords.
        """
        desc_lower = description.lower()

        # 1. learned
        if desc_lower in self.custom_keyword_map:
            mapping = self.custom_keyword_map[desc_lower]
            if self._key_exists(mapping):
                return mapping

        # 2. built-in
        for keyword, mapping in CATEGORY_KEYWORDS.items():
            if keyword in desc_lower and self._key_exists(mapping):
                return mapping

        return None

    def learn_mapping(self, description: str, key: ItemKey) -> None:
        self.custom_keyword_map[description.lower()] = key

    def batch_categorise(
        self, transactions: list[tuple[str, float]]
    ) -> list[tuple[str, float, Optional[ItemKey]]]:
        return [(d, a, self.categorise(d, a)) for d, a in transactions]

    def _key_exists(self, key: ItemKey) -> bool:
        mc, sc, item = key
        return (
            mc in self.structure
            and sc in self.structure[mc]
            and item in self.structure[mc][sc]
        )

    # ------------------------------------------------------------------
    # Category management
    # ------------------------------------------------------------------
    def reorder_items(self, mc: str, sc: str, old_idx: int, new_idx: int) -> None:
        items = self.structure[mc][sc]
        item  = items.pop(old_idx)
        items.insert(new_idx, item)

    # ------------------------------------------------------------------
    # Historical data helpers
    # ------------------------------------------------------------------
    def load_month_raw(self, profile: str, ym: str) -> Optional[dict]:
        """Load raw JSON for a month. Returns None if file missing."""
        path = _month_path(profile, ym)
        if not os.path.exists(path):
            return None
        try:
            with open(path, encoding="utf-8") as fh:
                return json.load(fh)
        except (json.JSONDecodeError, OSError) as exc:
            logger.error("Cannot read %s: %s", path, exc)
            return None

    def iter_history(
        self, profile: str, current_ym: str, months: int
    ) -> list[tuple[str, dict]]:
        """
        Return up to *months* entries [(ym, raw_data), ...] oldest-first.
        """
        results: list[tuple[str, dict]] = []
        ym = current_ym
        for _ in range(months):
            raw = self.load_month_raw(profile, ym)
            if raw is not None:
                results.append((ym, raw))
            prev = month_before(ym)
            if prev is None:
                break
            ym = prev
        results.reverse()
        return results

    # ------------------------------------------------------------------
    # Persistence
    # ------------------------------------------------------------------
    def load_month(self, profile: str, ym: str) -> tuple[bool, Optional[str]]:
        raw = self.load_month_raw(profile, ym)
        if raw is None:
            return False, None
        try:
            if "structure" in raw:
                self.structure = raw["structure"]
            self.values = {}
            for mc, subs in raw.get("values", {}).items():
                for sc, items in subs.items():
                    for item, val in items.items():
                        self.values[(mc, sc, item)] = val
            return True, None
        except Exception as exc:
            logger.exception("Failed to parse month data for %s/%s", profile, ym)
            return False, str(exc)

    def save_month(self, profile: str, ym: str) -> tuple[bool, Optional[str]]:
        path = _month_path(profile, ym)
        payload: dict = {"structure": self.structure, "values": {}}
        for (mc, sc, item), val in self.values.items():
            payload["values"].setdefault(mc, {}).setdefault(sc, {})[item] = val
        try:
            _ensure_dir(os.path.dirname(path))
            tmp = path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as fh:
                json.dump(payload, fh, indent=2, ensure_ascii=False)
            os.replace(tmp, path)
            logger.info("Saved %s/%s", profile, ym)
            return True, None
        except OSError as exc:
            logger.error("Cannot save %s: %s", path, exc)
            return False, str(exc)

    def load_settings(self) -> None:
        path = os.path.join(BASE_FOLDER, SETTINGS_FILE)
        if not os.path.exists(path):
            return
        try:
            with open(path, encoding="utf-8") as fh:
                s = json.load(fh)
            self.dark_mode          = s.get("dark_mode", True)
            self.auto_fill_enabled  = s.get("auto_fill", True)
            self.budget_warnings    = s.get("budget_warnings", {})
            self.custom_keyword_map = {
                k: tuple(v) for k, v in s.get("custom_keyword_map", {}).items()
            }
            self.savings_goals = [
                SavingsGoal.from_dict(g) for g in s.get("savings_goals", [])
            ]
            if "structure" in s:
                self.structure = s["structure"]
        except Exception as exc:
            logger.error("Cannot load settings: %s", exc)

    def save_settings(self) -> None:
        path = os.path.join(BASE_FOLDER, SETTINGS_FILE)
        _ensure_dir(BASE_FOLDER)
        payload = {
            "dark_mode":          self.dark_mode,
            "auto_fill":          self.auto_fill_enabled,
            "budget_warnings":    self.budget_warnings,
            "structure":          self.structure,
            "custom_keyword_map": {k: list(v) for k, v in self.custom_keyword_map.items()},
            "savings_goals":      [g.to_dict() for g in self.savings_goals],
            "profiles":           self.get_profiles(),
        }
        try:
            tmp = path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as fh:
                json.dump(payload, fh, indent=2, ensure_ascii=False)
            os.replace(tmp, path)
        except OSError as exc:
            logger.error("Cannot save settings: %s", exc)

    # ------------------------------------------------------------------
    # Profile management
    # ------------------------------------------------------------------
    def get_profiles(self) -> list[str]:
        if not os.path.exists(BASE_FOLDER):
            return [DEFAULT_PROFILE]
        dirs = [
            d for d in os.listdir(BASE_FOLDER)
            if os.path.isdir(os.path.join(BASE_FOLDER, d))
        ]
        return sorted(dirs) or [DEFAULT_PROFILE]

    def create_profile(self, name: str) -> None:
        _ensure_dir(os.path.join(BASE_FOLDER, name))

    def delete_profile(self, name: str) -> None:
        import shutil
        path = os.path.join(BASE_FOLDER, name)
        if os.path.exists(path):
            shutil.rmtree(path)


# ---------------------------------------------------------------------------
# Undo / Redo manager
# ---------------------------------------------------------------------------
class UndoRedoManager:
    """
    Stores snapshots of arbitrary state dicts.
    Thread-safe for single-threaded Tkinter use.
    """

    def __init__(self, max_size: int = 50) -> None:
        self._max  = max_size
        self._undo: list[dict] = []
        self._redo: list[dict] = []

    def push(self, state: dict) -> None:
        self._undo.append(copy.deepcopy(state))
        if len(self._undo) > self._max:
            self._undo.pop(0)
        self._redo.clear()

    def undo(self) -> Optional[dict]:
        if len(self._undo) < 2:
            return None
        current = self._undo.pop()
        self._redo.append(current)
        return copy.deepcopy(self._undo[-1])

    def redo(self) -> Optional[dict]:
        if not self._redo:
            return None
        state = self._redo.pop()
        self._undo.append(copy.deepcopy(state))
        return copy.deepcopy(state)

    @property
    def can_undo(self) -> bool:
        return len(self._undo) >= 2

    @property
    def can_redo(self) -> bool:
        return bool(self._redo)

    def clear(self) -> None:
        self._undo.clear()
        self._redo.clear()


# ---------------------------------------------------------------------------
# Utility functions
# ---------------------------------------------------------------------------
def _to_float(value: object) -> float:
    try:
        return float(str(value).strip().replace(",", ".") or "0")
    except ValueError:
        return 0.0


def _ensure_dir(path: str) -> None:
    os.makedirs(path, exist_ok=True)


def _month_path(profile: str, ym: str) -> str:
    return os.path.join(BASE_FOLDER, profile, f"budget_{ym}.json")


def month_before(ym: str) -> Optional[str]:
    try:
        y, m = map(int, ym.split("-"))
        return f"{y - 1}-12" if m == 1 else f"{y}-{m - 1:02d}"
    except ValueError:
        return None


def month_after(ym: str) -> Optional[str]:
    try:
        y, m = map(int, ym.split("-"))
        return f"{y + 1}-01" if m == 12 else f"{y}-{m + 1:02d}"
    except ValueError:
        return None


def is_valid_ym(ym: str) -> bool:
    import re
    if not re.fullmatch(r"\d{4}-\d{2}", ym):
        return False
    y, m = map(int, ym.split("-"))
    return 1 <= m <= 12 and 1900 <= y <= 2100


# Public re-export so callers can do: from budgetplanner.core.models import ...
__all__ = [
    "BudgetModel",
    "UndoRedoManager",
    "SavingsGoal",
    "Totals",
    "ItemKey",
    "EntryValue",
    "month_before",
    "month_after",
    "is_valid_ym",
]
