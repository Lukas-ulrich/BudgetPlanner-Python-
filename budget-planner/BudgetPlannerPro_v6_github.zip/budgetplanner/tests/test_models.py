"""
Unit tests for BudgetPlanner core models.

Run with:
    pytest budgetplanner/tests/
    pytest budgetplanner/tests/ -v
    pytest budgetplanner/tests/ --tb=short
"""
from __future__ import annotations

import pytest

from budgetplanner.core.models import (
    BudgetModel,
    SavingsGoal,
    Totals,
    UndoRedoManager,
    is_valid_ym,
    month_after,
    month_before,
)


# ===========================================================================
# Date helpers
# ===========================================================================
class TestMonthHelpers:
    def test_month_before_midyear(self):
        assert month_before("2025-06") == "2025-05"

    def test_month_before_january_wraps(self):
        assert month_before("2025-01") == "2024-12"

    def test_month_after_midyear(self):
        assert month_after("2025-06") == "2025-07"

    def test_month_after_december_wraps(self):
        assert month_after("2025-12") == "2026-01"

    def test_month_before_invalid(self):
        assert month_before("not-a-date") is None

    @pytest.mark.parametrize("ym,expected", [
        ("2025-01", True),
        ("2025-12", True),
        ("2025-00", False),
        ("2025-13", False),
        ("abcd-01", False),
        ("2025-1",  False),
    ])
    def test_is_valid_ym(self, ym, expected):
        assert is_valid_ym(ym) == expected


# ===========================================================================
# BudgetModel – totals
# ===========================================================================
class TestBudgetModelTotals:
    @pytest.fixture
    def model_with_data(self) -> BudgetModel:
        m = BudgetModel()
        m.values = {
            ("Einnahmen",       "Gehalt", "Gehalt Hauptjob"): {"amount": "3000", "note": ""},
            ("Fixkosten",       "Wohnen", "Miete"):            {"amount": "800",  "note": ""},
            ("Variable Kosten", "Essen",  "Supermarkt"):       {"amount": "300",  "note": ""},
        }
        return m

    def test_income(self, model_with_data):
        assert model_with_data.get_totals().income == 3000.0

    def test_expense(self, model_with_data):
        assert model_with_data.get_totals().expense == 1100.0

    def test_balance(self, model_with_data):
        assert model_with_data.get_totals().balance == 1900.0

    def test_saving_rate(self, model_with_data):
        rate = model_with_data.get_totals().saving_rate
        assert abs(rate - (1900 / 3000 * 100)) < 0.01

    def test_empty_model_zeros(self):
        t = BudgetModel().get_totals()
        assert t.income == t.expense == t.balance == 0.0

    def test_saving_rate_zero_income(self):
        m = BudgetModel()
        m.values = {("Fixkosten", "Wohnen", "Miete"): {"amount": "500", "note": ""}}
        assert m.get_totals().saving_rate == 0.0


# ===========================================================================
# BudgetModel – budget warnings
# ===========================================================================
class TestBudgetWarnings:
    @pytest.fixture
    def model(self) -> BudgetModel:
        m = BudgetModel()
        m.budget_warnings = {"Fixkosten": 1000.0}
        return m

    @pytest.mark.parametrize("amount,expected_level", [
        (400.0,  "ok"),
        (850.0,  "warn"),
        (1050.0, "over"),
        (1250.0, "critical"),
    ])
    def test_warning_levels(self, model, amount, expected_level):
        level, _ = model.get_budget_warning_level("Fixkosten", amount)
        assert level == expected_level

    def test_no_limit_returns_none(self, model):
        level, pct = model.get_budget_warning_level("Variable Kosten", 500.0)
        assert level is None
        assert pct == 0.0

    def test_percentage_calculation(self, model):
        _, pct = model.get_budget_warning_level("Fixkosten", 800.0)
        assert abs(pct - 80.0) < 0.01


# ===========================================================================
# BudgetModel – categorisation
# ===========================================================================
class TestCategorisation:
    @pytest.fixture
    def model(self) -> BudgetModel:
        return BudgetModel()

    @pytest.mark.parametrize("desc,expected_item", [
        ("REWE Supermarkt Berlin", "Supermarkt"),
        ("Netflix Abo monatlich",  "Abos"),
        ("Gehalt April 2025",      "Gehalt Hauptjob"),
        ("Miete Mai",              "Miete"),
        ("Lidl Kauf",              "Supermarkt"),
    ])
    def test_known_keywords(self, model, desc, expected_item):
        key = model.categorise(desc, -10.0)
        assert key is not None
        assert key[2] == expected_item

    def test_unknown_returns_none(self, model):
        assert model.categorise("Unbekannte GmbH XYZ999", -99.0) is None

    def test_learned_mapping_takes_priority(self, model):
        target = ("Variable Kosten", "Freizeit", "Abos")
        model.learn_mapping("McFit Beitrag", target)
        key = model.categorise("McFit Beitrag", -29.0)
        assert key == target

    def test_batch_categorise_length(self, model):
        txs = [("REWE", -50.0), ("Gehalt", 3000.0), ("???", -1.0)]
        result = model.batch_categorise(txs)
        assert len(result) == 3

    def test_batch_categorise_unknown_is_none(self, model):
        result = model.batch_categorise([("???", -1.0)])
        assert result[0][2] is None


# ===========================================================================
# UndoRedoManager
# ===========================================================================
class TestUndoRedoManager:
    def test_basic_undo(self):
        mgr = UndoRedoManager()
        mgr.push({"v": 1})
        mgr.push({"v": 2})
        state = mgr.undo()
        assert state == {"v": 1}

    def test_redo_after_undo(self):
        mgr = UndoRedoManager()
        mgr.push({"v": 1})
        mgr.push({"v": 2})
        mgr.undo()
        assert mgr.redo() == {"v": 2}

    def test_redo_cleared_on_new_push(self):
        mgr = UndoRedoManager()
        mgr.push({"v": 1})
        mgr.push({"v": 2})
        mgr.undo()
        mgr.push({"v": 3})
        assert not mgr.can_redo

    def test_undo_returns_none_if_empty(self):
        assert UndoRedoManager().undo() is None

    def test_redo_returns_none_if_empty(self):
        assert UndoRedoManager().redo() is None

    def test_max_size_respected(self):
        mgr = UndoRedoManager(max_size=3)
        for i in range(10):
            mgr.push({"v": i})
        assert len(mgr._undo) == 3

    def test_clear(self):
        mgr = UndoRedoManager()
        mgr.push({"v": 1})
        mgr.push({"v": 2})
        mgr.clear()
        assert not mgr.can_undo
        assert not mgr.can_redo

    def test_deepcopy_isolation(self):
        """Mutations to a pushed state must not affect stored state."""
        mgr  = UndoRedoManager()
        data = {"items": [1, 2, 3]}
        mgr.push(data)
        data["items"].append(99)
        mgr.push(data)
        state = mgr.undo()
        assert state is not None
        assert 99 not in state["items"]


# ===========================================================================
# SavingsGoal
# ===========================================================================
class TestSavingsGoal:
    def test_progress_pct_partial(self):
        g = SavingsGoal("Urlaub", target=2000.0, saved=800.0)
        assert abs(g.progress_pct - 40.0) < 0.01

    def test_progress_pct_complete(self):
        g = SavingsGoal("Notgroschen", target=5000.0, saved=5000.0)
        assert g.progress_pct == 100.0

    def test_progress_pct_capped_at_100(self):
        g = SavingsGoal("X", target=100.0, saved=200.0)
        assert g.progress_pct == 100.0

    def test_months_remaining(self):
        g = SavingsGoal("X", target=2000.0, saved=800.0, monthly=200.0)
        assert g.months_remaining == 6

    def test_months_remaining_none_when_no_monthly(self):
        g = SavingsGoal("X", target=2000.0, saved=800.0, monthly=0.0)
        assert g.months_remaining is None

    def test_roundtrip_serialisation(self):
        original = SavingsGoal("Test", 1500.0, 600.0, 150.0, "savings")
        restored = SavingsGoal.from_dict(original.to_dict())
        assert restored.name    == original.name
        assert restored.target  == original.target
        assert restored.saved   == original.saved
        assert restored.monthly == original.monthly
        assert restored.icon    == original.icon
