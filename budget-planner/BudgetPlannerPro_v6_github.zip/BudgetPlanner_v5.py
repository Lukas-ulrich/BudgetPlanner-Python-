import tkinter as tk
from tkinter import ttk, messagebox, simpledialog, filedialog
import json
import os
import csv
from datetime import datetime, timedelta
from collections import defaultdict
import re
from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import matplotlib.pyplot as plt
import numpy as np
import copy
import logging

# Logging konfigurieren (Datei + Konsole)
logging.basicConfig(
    level=logging.WARNING,
    format='%(asctime)s [%(levelname)s] %(message)s',
    handlers=[
        logging.FileHandler("budgetplanner.log", encoding="utf-8"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("BudgetPlanner")

# ------------------------------
# Konfiguration / Standard-Daten
# ------------------------------
DEFAULT_STRUCTURE = {
    "Einnahmen": {
        "Gehalt": ["Gehalt Hauptjob", "Nebentätigkeit"],
        "Sonstiges": ["Geschenke", "Verkauf"]
    },
    "Fixkosten": {
        "Wohnen": ["Miete", "Strom", "Wasser"],
        "Versicherungen": ["Krankenversicherung", "Hausrat"]
    },
    "Variable Kosten": {
        "Essen": ["Supermarkt", "Restaurant"],
        "Freizeit": ["Abos", "Urlaub", "Kino"]
    },
    "Sparen": {
        "Ziele": ["Notgroschen", "Urlaub", "Rente"]
    }
}

BASE_FOLDER = "profiles"
DEFAULT_PROFILE = "default"
SETTINGS_FILE = "settings.json"

# ------------------------------
# Auto-Kategorisierung Keyword-Mapping
# ------------------------------
CATEGORY_KEYWORDS = {
    # Format: keyword (lowercase) -> (main_cat, sub_cat, item)
    # Einnahmen
    "gehalt": ("Einnahmen", "Gehalt", "Gehalt Hauptjob"),
    "lohn": ("Einnahmen", "Gehalt", "Gehalt Hauptjob"),
    "salary": ("Einnahmen", "Gehalt", "Gehalt Hauptjob"),
    "nebenjob": ("Einnahmen", "Gehalt", "Nebentätigkeit"),
    "freiberuf": ("Einnahmen", "Gehalt", "Nebentätigkeit"),
    "geschenk": ("Einnahmen", "Sonstiges", "Geschenke"),
    "ebay": ("Einnahmen", "Sonstiges", "Verkauf"),
    "verkauf": ("Einnahmen", "Sonstiges", "Verkauf"),
    "paypal": ("Einnahmen", "Sonstiges", "Verkauf"),

    # Fixkosten Wohnen
    "miete": ("Fixkosten", "Wohnen", "Miete"),
    "warmmiete": ("Fixkosten", "Wohnen", "Miete"),
    "kaltmiete": ("Fixkosten", "Wohnen", "Miete"),
    "strom": ("Fixkosten", "Wohnen", "Strom"),
    "energie": ("Fixkosten", "Wohnen", "Strom"),
    "vattenfall": ("Fixkosten", "Wohnen", "Strom"),
    "eon": ("Fixkosten", "Wohnen", "Strom"),
    "wasser": ("Fixkosten", "Wohnen", "Wasser"),
    "stadtwerke": ("Fixkosten", "Wohnen", "Strom"),
    "gas": ("Fixkosten", "Wohnen", "Strom"),

    # Fixkosten Versicherungen
    "versicherung": ("Fixkosten", "Versicherungen", "Hausrat"),
    "krankenkasse": ("Fixkosten", "Versicherungen", "Krankenversicherung"),
    "krankenversicherung": ("Fixkosten", "Versicherungen", "Krankenversicherung"),
    "aok": ("Fixkosten", "Versicherungen", "Krankenversicherung"),
    "tkk": ("Fixkosten", "Versicherungen", "Krankenversicherung"),
    "barmer": ("Fixkosten", "Versicherungen", "Krankenversicherung"),
    "hausrat": ("Fixkosten", "Versicherungen", "Hausrat"),
    "huk": ("Fixkosten", "Versicherungen", "Hausrat"),

    # Variable Kosten Essen
    "rewe": ("Variable Kosten", "Essen", "Supermarkt"),
    "edeka": ("Variable Kosten", "Essen", "Supermarkt"),
    "aldi": ("Variable Kosten", "Essen", "Supermarkt"),
    "lidl": ("Variable Kosten", "Essen", "Supermarkt"),
    "netto": ("Variable Kosten", "Essen", "Supermarkt"),
    "penny": ("Variable Kosten", "Essen", "Supermarkt"),
    "kaufland": ("Variable Kosten", "Essen", "Supermarkt"),
    "norma": ("Variable Kosten", "Essen", "Supermarkt"),
    "supermarkt": ("Variable Kosten", "Essen", "Supermarkt"),
    "lebensmittel": ("Variable Kosten", "Essen", "Supermarkt"),
    "backerei": ("Variable Kosten", "Essen", "Supermarkt"),
    "bäckerei": ("Variable Kosten", "Essen", "Supermarkt"),
    "metzger": ("Variable Kosten", "Essen", "Supermarkt"),
    "restaurant": ("Variable Kosten", "Essen", "Restaurant"),
    "gasthaus": ("Variable Kosten", "Essen", "Restaurant"),
    "lieferando": ("Variable Kosten", "Essen", "Restaurant"),
    "pizza": ("Variable Kosten", "Essen", "Restaurant"),
    "mcdonalds": ("Variable Kosten", "Essen", "Restaurant"),
    "burger": ("Variable Kosten", "Essen", "Restaurant"),
    "cafe": ("Variable Kosten", "Essen", "Restaurant"),
    "kaffee": ("Variable Kosten", "Essen", "Restaurant"),
    "bäcker": ("Variable Kosten", "Essen", "Restaurant"),

    # Variable Kosten Freizeit
    "netflix": ("Variable Kosten", "Freizeit", "Abos"),
    "spotify": ("Variable Kosten", "Freizeit", "Abos"),
    "amazon prime": ("Variable Kosten", "Freizeit", "Abos"),
    "disney": ("Variable Kosten", "Freizeit", "Abos"),
    "abo": ("Variable Kosten", "Freizeit", "Abos"),
    "mitglied": ("Variable Kosten", "Freizeit", "Abos"),
    "fitness": ("Variable Kosten", "Freizeit", "Abos"),
    "gym": ("Variable Kosten", "Freizeit", "Abos"),
    "kino": ("Variable Kosten", "Freizeit", "Kino"),
    "cinema": ("Variable Kosten", "Freizeit", "Kino"),
    "urlaub": ("Variable Kosten", "Freizeit", "Urlaub"),
    "hotel": ("Variable Kosten", "Freizeit", "Urlaub"),
    "flug": ("Variable Kosten", "Freizeit", "Urlaub"),
    "booking": ("Variable Kosten", "Freizeit", "Urlaub"),

    # Sparen
    "sparplan": ("Sparen", "Ziele", "Notgroschen"),
    "tagesgeld": ("Sparen", "Ziele", "Notgroschen"),
    "sparkasse": ("Sparen", "Ziele", "Notgroschen"),
    "depot": ("Sparen", "Ziele", "Rente"),
    "etf": ("Sparen", "Ziele", "Rente"),
    "aktien": ("Sparen", "Ziele", "Rente"),
    "rente": ("Sparen", "Ziele", "Rente"),
    "riester": ("Sparen", "Ziele", "Rente"),
}


# ------------------------------
# BudgetModel – Datenmodell (MVC: Model)
# ------------------------------
class BudgetModel:
    """Enthält alle Geschäftslogik, getrennt von der UI."""

    def __init__(self):
        self.structure = copy.deepcopy(DEFAULT_STRUCTURE)
        self.values = {}          # {(mc, sc, item): {'amount': str, 'note': str}}
        self.budget_warnings = {}
        self.dark_mode = True
        self.auto_fill_enabled = True
        self.current_profile = DEFAULT_PROFILE
        self.custom_keyword_map = {}  # Lernende Zuordnungen: beschreibung_lower -> (mc, sc, item)
        # Multi-Sparziele: [{'name': str, 'target': float, 'saved': float, 'icon': str}, ...]
        self.savings_goals = []

    # ---- Berechnungen ----
    def get_totals(self):
        total_income = 0.0
        total_expense = 0.0
        fixed_total = 0.0
        variable_total = 0.0
        per_item = {}
        per_main = {}

        for (mc, sc, item), val in self.values.items():
            amt = ensure_float(val.get('amount', '0'))
            per_item[(mc, sc, item)] = amt
            per_main[mc] = per_main.get(mc, 0.0) + amt

            if "Einnahmen" in mc or mc.lower().startswith("ein"):
                total_income += amt
            elif "Fix" in mc or mc.lower().startswith("fix"):
                fixed_total += amt
                total_expense += amt
            elif "Variable" in mc or mc.lower().startswith("var"):
                variable_total += amt
                total_expense += amt
            elif mc == "Sparen":
                total_expense += amt
                variable_total += amt
            else:
                total_expense += amt
                variable_total += amt

        return {
            'income': total_income,
            'expense': total_expense,
            'fixed': fixed_total,
            'variable': variable_total,
            'balance': total_income - total_expense,
            'per_item': per_item,
            'per_main': per_main,
        }

    def get_top3_expenses(self):
        totals = self.get_totals()
        per_item = totals['per_item']
        expense_by_sub = {}
        for (mc, sc, item), amt in per_item.items():
            if "Einnahmen" in mc or mc.lower().startswith("ein"):
                continue
            key = f"{mc} / {sc}"
            expense_by_sub[key] = expense_by_sub.get(key, 0.0) + amt
        return sorted(expense_by_sub.items(), key=lambda x: x[1], reverse=True)[:3]

    def get_budget_warning_level(self, main_cat, current_amount):
        """
        Gibt den Warnstufen-Status zurück:
        None = kein Limit, 'ok' = <80%, 'warn' = 80-99%, 'over' = 100-119%, 'critical' = >=120%
        """
        limit = self.budget_warnings.get(main_cat)
        if not limit or limit <= 0:
            return None, 0.0
        pct = (current_amount / limit) * 100.0
        if pct >= 120:
            return 'critical', pct
        elif pct >= 100:
            return 'over', pct
        elif pct >= 80:
            return 'warn', pct
        else:
            return 'ok', pct

    def get_top_categories_history(self, profile, current_month, num_months=6):
        """Gibt historische Ausgaben pro Hauptkategorie zurück für Top-Kategorien-Chart."""
        months_data = []
        month = current_month
        for _ in range(num_months):
            fname = filename_for_month(profile, month)
            if os.path.exists(fname):
                try:
                    with open(fname, 'r', encoding='utf-8') as f:
                        data = json.load(f)
                    months_data.append((month, data))
                except Exception:
                    pass  # logged silently
            prev = get_previous_month(month)
            if not prev:
                break
            month = prev
        months_data.reverse()
        return months_data

    # ---- Auto-Kategorisierung ----
    def categorize_transaction(self, description, amount):
        """
        Ordnet eine Transaktion einer Kategorie zu.
        Gibt (mc, sc, item) oder None zurück.
        """
        desc_lower = description.lower()

        # 1. Zuerst lernende Zuordnungen prüfen (höchste Priorität)
        if desc_lower in self.custom_keyword_map:
            return self.custom_keyword_map[desc_lower]

        # 2. Dann Standard-Keyword-Mapping
        for keyword, mapping in CATEGORY_KEYWORDS.items():
            if keyword in desc_lower:
                # Prüfen ob Kategorie existiert
                mc, sc, item = mapping
                if mc in self.structure and sc in self.structure[mc] and item in self.structure[mc][sc]:
                    return mapping

        # 3. Betragsbasierte Heuristik als Fallback
        if amount > 0:
            return ("Einnahmen", "Sonstiges", "Geschenke") if ("Einnahmen", "Sonstiges", "Geschenke") in [(mc, sc, i) for (mc, sc, i) in self.values] else None
        
        return None

    def learn_mapping(self, description, mc, sc, item):
        """Speichert eine gelernte Zuordnung."""
        self.custom_keyword_map[description.lower()] = (mc, sc, item)

    def batch_categorize(self, transactions):
        """
        Kategorisiert eine Liste von Transaktionen.
        transactions: [(description, amount), ...]
        Gibt [(desc, amount, category_or_None), ...] zurück.
        """
        results = []
        for desc, amount in transactions:
            cat = self.categorize_transaction(desc, amount)
            results.append((desc, amount, cat))
        return results

    # ---- Dateioperationen ----
    def load_month(self, profile, ym):
        fname = filename_for_month(profile, ym)
        if not os.path.exists(fname):
            return False, None
        try:
            with open(fname, "r", encoding="utf-8") as f:
                payload = json.load(f)
            if "structure" in payload:
                self.structure = payload["structure"]
            raw_values = payload.get("values", {})
            self.values = {}
            for mc, subs in raw_values.items():
                for sc, items in subs.items():
                    for item, val in items.items():
                        self.values[(mc, sc, item)] = val
            return True, payload
        except json.JSONDecodeError as e:
            logger.error("JSON-Fehler beim Laden von %s: %s", fname, e)
            return False, f"Ungültige JSON-Datei: {e}"
        except OSError as e:
            logger.error("Dateifehler beim Laden von %s: %s", fname, e)
            return False, f"Datei konnte nicht gelesen werden: {e}"
        except Exception as e:
            logger.exception("Unbekannter Fehler beim Laden von %s", fname)
            return False, str(e)

    def save_month(self, profile, ym):
        fname = filename_for_month(profile, ym)
        payload = {"structure": self.structure, "values": {}}
        for (mc, sc, item), val in self.values.items():
            payload["values"].setdefault(mc, {}).setdefault(sc, {})[item] = val
        try:
            ensure_dir(os.path.dirname(fname))
            # Atomic write: temp-Datei dann rename
            tmp = fname + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(payload, f, indent=2, ensure_ascii=False)
            os.replace(tmp, fname)
            logger.info("Monat gespeichert: %s", fname)
            return True, None
        except OSError as e:
            logger.error("Fehler beim Speichern von %s: %s", fname, e)
            return False, f"Datei konnte nicht gespeichert werden: {e}"
        except Exception as e:
            logger.exception("Unbekannter Fehler beim Speichern von %s", fname)
            return False, str(e)

    def load_settings(self):
        settings_path = os.path.join(BASE_FOLDER, SETTINGS_FILE)
        if os.path.exists(settings_path):
            try:
                with open(settings_path, 'r', encoding='utf-8') as f:
                    settings = json.load(f)
                    self.dark_mode = settings.get('dark_mode', True)
                    self.auto_fill_enabled = settings.get('auto_fill', True)
                    self.budget_warnings = settings.get('budget_warnings', {})
                    self.custom_keyword_map = settings.get('custom_keyword_map', {})
                    self.savings_goals = settings.get('savings_goals', [])
                    if 'structure' in settings:
                        self.structure = settings['structure']
                    if 'profiles' in settings:
                        self._profiles_list = settings['profiles']
                    else:
                        self._profiles_list = [DEFAULT_PROFILE]
            except Exception:
                pass  # logged silently

    def save_settings(self):
        settings_path = os.path.join(BASE_FOLDER, SETTINGS_FILE)
        ensure_dir(BASE_FOLDER)
        settings = {
            'dark_mode': self.dark_mode,
            'auto_fill': self.auto_fill_enabled,
            'budget_warnings': self.budget_warnings,
            'structure': self.structure,
            'custom_keyword_map': self.custom_keyword_map,
            'profiles': self.get_profiles(),
            'savings_goals': self.savings_goals,
        }
        try:
            with open(settings_path, 'w', encoding='utf-8') as f:
                json.dump(settings, f, indent=2, ensure_ascii=False)
        except Exception:
            pass  # logged silently

    def get_profiles(self):
        """Gibt alle vorhandenen Profile zurück."""
        profiles = []
        if os.path.exists(BASE_FOLDER):
            for d in os.listdir(BASE_FOLDER):
                full = os.path.join(BASE_FOLDER, d)
                if os.path.isdir(full):
                    profiles.append(d)
        if not profiles:
            profiles = [DEFAULT_PROFILE]
        return sorted(profiles)

    def create_profile(self, name):
        path = os.path.join(BASE_FOLDER, name)
        ensure_dir(path)

    def delete_profile(self, name):
        import shutil
        path = os.path.join(BASE_FOLDER, name)
        if os.path.exists(path):
            shutil.rmtree(path)


# ------------------------------
# Undo/Redo System
# ------------------------------
class UndoRedoManager:
    """Verwaltet einen History-Stack für Undo/Redo."""

    def __init__(self, max_size=50):
        self.max_size = max_size
        self._undo_stack = []  # Liste von States
        self._redo_stack = []

    def push(self, state):
        """Speichert einen neuen Zustand."""
        self._undo_stack.append(copy.deepcopy(state))
        if len(self._undo_stack) > self.max_size:
            self._undo_stack.pop(0)
        self._redo_stack.clear()  # Redo-Stack leeren bei neuer Aktion

    def undo(self):
        """Gibt den letzten Zustand zurück und speichert aktuellen in Redo."""
        if len(self._undo_stack) < 2:
            return None
        current = self._undo_stack.pop()
        self._redo_stack.append(current)
        return copy.deepcopy(self._undo_stack[-1])

    def redo(self):
        """Stellt Redo-Zustand wieder her."""
        if not self._redo_stack:
            return None
        state = self._redo_stack.pop()
        self._undo_stack.append(copy.deepcopy(state))
        return copy.deepcopy(state)

    def can_undo(self):
        return len(self._undo_stack) >= 2

    def can_redo(self):
        return len(self._redo_stack) > 0

    def clear(self):
        self._undo_stack.clear()
        self._redo_stack.clear()


# ------------------------------
# Hilfsfunktionen
# ------------------------------
def validate_month_format(ym_str):
    pattern = r'^\d{4}-\d{2}$'
    if not re.match(pattern, ym_str):
        return False
    try:
        year, month = map(int, ym_str.split('-'))
        return 1 <= month <= 12 and 1900 <= year <= 2100
    except:
        return False

def get_previous_month(ym_str):
    try:
        year, month = map(int, ym_str.split('-'))
        if month == 1:
            return f"{year-1}-12"
        else:
            return f"{year}-{month-1:02d}"
    except:
        return None

def get_next_month(ym_str):
    try:
        year, month = map(int, ym_str.split('-'))
        if month == 12:
            return f"{year+1}-01"
        else:
            return f"{year}-{month+1:02d}"
    except:
        return None

def month_key_from_selection(ym_str):
    return ym_str.strip()

def ensure_float(s):
    try:
        s = str(s).strip().replace(',', '.')
        if s == "":
            return 0.0
        return float(s)
    except (ValueError, AttributeError):
        return 0.0

def ensure_dir(path):
    if not os.path.exists(path):
        os.makedirs(path)

def profile_folder(profile):
    return os.path.join(BASE_FOLDER, profile)

def filename_for_month(profile, ym):
    return os.path.join(profile_folder(profile), f"budget_{ym}.json")


# ------------------------------
# Hauptklasse / App (nur UI!)
# ------------------------------
class BudgetApp:
    def __init__(self, root):
        self.root = root
        self.root.title("BudgetPlanner Pro – Kostenrechner")
        self.root.geometry("1400x820")

        # Model
        self.model = BudgetModel()
        self.model.load_settings()

        # Undo/Redo
        self.undo_redo = UndoRedoManager()

        # UI-Variablen
        self.dark_mode = tk.BooleanVar(value=self.model.dark_mode)
        self.auto_fill_enabled = tk.BooleanVar(value=self.model.auto_fill_enabled)
        self.current_month = tk.StringVar(value=datetime.now().strftime("%Y-%m"))
        self.saving_note = tk.StringVar(value="")
        self.savings_goal = tk.StringVar(value="0")
        self.labels_by_item = {}
        self.totals_per_category = {}
        self.delete_mode = tk.BooleanVar(value=False)
        self.current_profile = tk.StringVar(value=self.model.current_profile)

        # Undo-Buttons (werden später gesetzt)
        self.undo_btn = None
        self.redo_btn = None
        self._suppress_undo = False  # Verhindert Undo-Push während Restore

        # Such- & Filterfunktion
        self.search_var = tk.StringVar(value="")
        self._search_after_id = None  # Debounce-Timer

        # Drag & Drop
        self._drag_source = None  # (mc, sc, item, frame)
        self._drag_placeholder = None

        # Budget-Warnungs-Labels (für dynamische Farb-Updates)
        self._budget_warn_labels = {}

        # ── Unsaved-Changes Tracking ──
        self._unsaved = False
        self._autosave_interval_ms = 120_000   # 2 Minuten
        self._autosave_after_id = None

        # ── Statusleiste (wird in build_ui gesetzt) ──
        self.status_bar = None
        self._status_after_id = None

        # ── Bulk Actions ──
        self._bulk_select = {}       # key -> tk.BooleanVar
        self.bulk_mode = tk.BooleanVar(value=False)
        self._bulk_toolbar = None    # wird in build_budget_tab gesetzt

        ensure_dir(profile_folder(DEFAULT_PROFILE))

        self.apply_theme()
        self.build_ui()
        self.load_month(self.current_month.get())
        self.recalculate_all()

    # ---- Theme ----
    def apply_theme(self):
        if self.dark_mode.get():
            self.colors = {
                'bg': '#1a1a1a', 'bg_secondary': '#252526',
                'bg_tertiary': '#2d2d30', 'bg_input': '#3e3e42',
                'fg': 'white', 'fg_secondary': '#e0e0e0',
                'fg_muted': '#b0b0b0', 'accent': '#0078d4',
                'success': '#107c10', 'danger': '#d13438', 'warning': '#ffd700'
            }
        else:
            self.colors = {
                'bg': '#f5f5f5', 'bg_secondary': '#ffffff',
                'bg_tertiary': '#e8e8e8', 'bg_input': '#ffffff',
                'fg': '#000000', 'fg_secondary': '#333333',
                'fg_muted': '#666666', 'accent': '#0078d4',
                'success': '#107c10', 'danger': '#d13438', 'warning': '#ff8c00'
            }
        self.root.configure(bg=self.colors['bg'])

    def toggle_theme(self):
        self.dark_mode.set(not self.dark_mode.get())
        self.model.dark_mode = self.dark_mode.get()
        self.model.save_settings()

        current_values = {}
        for (mc, sc, item), refs in self.labels_by_item.items():
            current_values[(mc, sc, item)] = {
                "amt": refs["amt"].get(), "note": refs["note"].get()
            }

        self.apply_theme()
        for widget in self.root.winfo_children():
            widget.destroy()
        self.build_ui()

        for (mc, sc, item), refs in self.labels_by_item.items():
            if (mc, sc, item) in current_values:
                refs["amt"].set(current_values[(mc, sc, item)]["amt"])
                refs["note"].set(current_values[(mc, sc, item)]["note"])

        self.recalculate_all()
        self._refresh_goals_tab()
        if hasattr(self, 'dashboard_tab'):
            self.update_dashboard()

    # ══════════════════════════════════════════════════
    # Unsaved-Changes + Autosave + Status + Shortcuts
    # ══════════════════════════════════════════════════
    def _mark_unsaved(self):
        """Markiert den Zustand als ungespeichert (Stern im Titel + Statusleiste)."""
        if not self._unsaved:
            self._unsaved = True
            self.root.title("BudgetPlanner Pro * – Kostenrechner")
        self._set_status("⚠️ Nicht gespeichert", self.colors.get('warning', '#ffd700'))
        self._schedule_autosave()

    def _mark_saved(self, ym=None):
        """Markiert als gespeichert."""
        self._unsaved = False
        self.root.title("BudgetPlanner Pro – Kostenrechner")
        msg = f"💾 Gespeichert ({ym})" if ym else "💾 Gespeichert"
        self._set_status(msg, self.colors.get('success', '#107c10'))
        # Status nach 4 Sekunden auf neutral setzen
        if self._status_after_id:
            self.root.after_cancel(self._status_after_id)
        self._status_after_id = self.root.after(4000, lambda: self._set_status("✅ Bereit", self.colors.get('fg_muted', '#b0b0b0')))

    def _set_status(self, text, color=None):
        """Setzt den Text der Statusleiste."""
        if self.status_bar:
            fg = color or self.colors.get('fg_muted', '#b0b0b0')
            self.status_bar.config(text=text, fg=fg)

    def _build_status_bar(self):
        """Erstellt die Statusleiste am unteren Rand."""
        bar = tk.Frame(self.root, bg=self.colors['bg_tertiary'], height=26)
        bar.pack(fill="x", side="bottom")
        bar.pack_propagate(False)

        self.status_bar = tk.Label(bar, text="✅ Bereit",
                                   bg=self.colors['bg_tertiary'],
                                   fg=self.colors['fg_muted'],
                                   font=("Segoe UI", 9), anchor="w")
        self.status_bar.pack(side="left", padx=12)

        # Autosave-Toggle rechts
        self._autosave_var = tk.BooleanVar(value=True)
        tk.Checkbutton(bar, text="🔄 Autosave (2 min)",
                       variable=self._autosave_var,
                       bg=self.colors['bg_tertiary'],
                       fg=self.colors['fg_muted'],
                       selectcolor=self.colors['bg_tertiary'],
                       activebackground=self.colors['bg_tertiary'],
                       activeforeground=self.colors['fg_muted'],
                       font=("Segoe UI", 9),
                       command=self._toggle_autosave).pack(side="right", padx=12)

        # Shortcut-Hinweis
        tk.Label(bar, text="Ctrl+S Speichern  |  Ctrl+Z Rückgängig  |  Ctrl+Y Wiederholen  |  Ctrl+F Suchen",
                 bg=self.colors['bg_tertiary'], fg=self.colors['fg_muted'],
                 font=("Segoe UI", 8)).pack(side="right", padx=20)

    def _schedule_autosave(self):
        """Plant den nächsten Autosave."""
        if self._autosave_after_id:
            self.root.after_cancel(self._autosave_after_id)
        if getattr(self, '_autosave_var', None) and self._autosave_var.get():
            self._autosave_after_id = self.root.after(
                self._autosave_interval_ms, self._do_autosave)

    def _do_autosave(self):
        """Führt automatisches Speichern durch (nur wenn ungespeichert)."""
        if self._unsaved:
            ym = self.current_month.get()
            if validate_month_format(ym):
                self.model.values = {}
                for (mc, sc, item), varsd in self.labels_by_item.items():
                    self.model.values[(mc, sc, item)] = {
                        'amount': varsd["amt"].get().strip(),
                        'note': varsd["note"].get().strip()
                    }
                ok, _ = self.model.save_month(self.current_profile.get(), ym)
                if ok:
                    self._mark_saved(f"{ym} Auto")
                    self.model.save_settings()

    def _toggle_autosave(self):
        if self._autosave_var.get():
            self._set_status("🔄 Autosave aktiviert", self.colors['accent'])
            self._schedule_autosave()
        else:
            if self._autosave_after_id:
                self.root.after_cancel(self._autosave_after_id)
            self._set_status("⏸️ Autosave deaktiviert", self.colors['fg_muted'])

    def _bind_shortcuts(self):
        """Registriert globale Tastenkürzel."""
        self.root.bind_all("<Control-s>",   lambda e: self.on_save_click())
        self.root.bind_all("<Control-S>",   lambda e: self.on_save_click())
        self.root.bind_all("<Control-z>",   lambda e: self.do_undo())
        self.root.bind_all("<Control-Z>",   lambda e: self.do_undo())
        self.root.bind_all("<Control-y>",   lambda e: self.do_redo())
        self.root.bind_all("<Control-Y>",   lambda e: self.do_redo())
        self.root.bind_all("<Control-f>",   lambda e: self._focus_search())
        self.root.bind_all("<Control-F>",   lambda e: self._focus_search())
        self.root.bind_all("<Control-n>",   lambda e: self._shortcut_new_month())
        self.root.bind_all("<F5>",          lambda e: self.recalculate_all())
        self.root.bind_all("<Control-d>",   lambda e: self._shortcut_toggle_dark())
        self.root.bind_all("<Control-D>",   lambda e: self._shortcut_toggle_dark())
        # Löschmodus Del-Taste (nur wenn ein item ausgewählt)
        self.root.bind_all("<Delete>", self._shortcut_delete_focused)

    def _focus_search(self):
        """Setzt den Fokus auf das Suchfeld und wechselt zum Budget-Tab."""
        self.notebook.select(self.budget_tab)
        # Suchfeld über alle Widgets finden und fokussieren
        self.search_var.set("")
        self.root.after(100, lambda: self.root.focus_get())

    def _shortcut_new_month(self):
        """Ctrl+N → Navigiert zum nächsten Monat."""
        self.navigate_month(1)

    def _shortcut_toggle_dark(self):
        """Ctrl+D → Dark/Light Toggle."""
        self.toggle_theme()

    def _shortcut_delete_focused(self, event):
        """Del → Löscht das fokussierte Item (nur im Löschmodus)."""
        if not self.delete_mode.get():
            return
        # Fokussiertes Widget finden
        widget = self.root.focus_get()
        if widget:
            # Suche das Item, das zu diesem Widget gehört
            for key, refs in self.labels_by_item.items():
                f = refs.get("frame")
                if f and (widget == f or widget in f.winfo_children()):
                    mc, sc, item = key
                    self.delete_item(mc, sc, item)
                    break

    # ---- UI Aufbau ----
    def build_ui(self):
        # Topbar
        top_frame = tk.Frame(self.root, bg=self.colors['bg_tertiary'], height=60)
        top_frame.pack(fill="x")

        # Links: Monat
        left_top = tk.Frame(top_frame, bg=self.colors['bg_tertiary'])
        left_top.pack(side="left", padx=15, pady=10)

        tk.Label(left_top, text="📅 Monat:", bg=self.colors['bg_tertiary'],
                 fg=self.colors['fg_secondary'], font=("Segoe UI", 11, "bold")).pack(side="left", padx=(0, 8))
        month_entry = tk.Entry(left_top, textvariable=self.current_month, width=10,
                               font=("Segoe UI", 11), bg=self.colors['bg_input'],
                               fg=self.colors['fg'], insertbackground=self.colors['fg'],
                               relief="flat", borderwidth=2)
        month_entry.pack(side="left", padx=5)

        self.create_button(left_top, "◀", lambda: self.navigate_month(-1), self.colors['accent'], width=3).pack(side="left", padx=2)
        self.create_button(left_top, "▶", lambda: self.navigate_month(1), self.colors['accent'], width=3).pack(side="left", padx=2)
        self.create_button(left_top, "📂 Laden", self.on_load_click, self.colors['accent']).pack(side="left", padx=3)
        self.create_button(left_top, "💾 Speichern", self.on_save_click, self.colors['success']).pack(side="left", padx=3)

        # Mitte: Quick Actions + Undo/Redo
        mid_top = tk.Frame(top_frame, bg=self.colors['bg_tertiary'])
        mid_top.pack(side="left", padx=20)

        self.create_button(mid_top, "🔄 Auto-Fill", self.auto_fill_fixed, "#5c2d91").pack(side="left", padx=3)
        self.create_button(mid_top, "⚙️ Budget-Limits", self.set_budget_limits, "#ff8c00").pack(side="left", padx=3)
        self.create_button(mid_top, "📥 CSV Import", self.import_bank_csv, "#ca5010").pack(side="left", padx=3)

        # Undo / Redo Buttons
        self.undo_btn = self.create_button(mid_top, "↩️ Rückgängig", self.do_undo, "#555555")
        self.undo_btn.pack(side="left", padx=3)
        self.redo_btn = self.create_button(mid_top, "↪️ Wiederholen", self.do_redo, "#555555")
        self.redo_btn.pack(side="left", padx=3)

        # Rechts: Profil + Theme + Export + Löschen
        right_top = tk.Frame(top_frame, bg=self.colors['bg_tertiary'])
        right_top.pack(side="right", padx=15, pady=10)

        theme_icon = "🌙" if self.dark_mode.get() else "☀️"
        self.create_button(right_top, theme_icon, self.toggle_theme, "#5c2d91", width=3).pack(side="left", padx=3)
        self.create_button(right_top, "📄 PDF", self.export_pdf, "#ca5010").pack(side="left", padx=3)
        self.create_button(right_top, "📊 CSV", self.export_csv, "#107c10").pack(side="left", padx=3)

        delete_check = tk.Checkbutton(
            right_top, text="🗑️ Löschmodus", variable=self.delete_mode,
            bg=self.colors['bg_tertiary'], fg=self.colors['danger'],
            selectcolor=self.colors['bg_tertiary'],
            activebackground=self.colors['bg_tertiary'],
            activeforeground=self.colors['danger'],
            font=("Segoe UI", 10, "bold"), command=self.toggle_delete_mode
        )
        delete_check.pack(side="left", padx=8)

        bulk_check = tk.Checkbutton(
            right_top, text="☑️ Multi-Auswahl", variable=self.bulk_mode,
            bg=self.colors['bg_tertiary'], fg=self.colors['accent'],
            selectcolor=self.colors['bg_tertiary'],
            activebackground=self.colors['bg_tertiary'],
            activeforeground=self.colors['accent'],
            font=("Segoe UI", 10, "bold"), command=self._toggle_bulk_mode
        )
        bulk_check.pack(side="left", padx=4)

        # Profil-Leiste (zweite Zeile)
        profile_bar = tk.Frame(self.root, bg=self.colors['bg_secondary'], height=40)
        profile_bar.pack(fill="x")
        self._build_profile_bar(profile_bar)

        # Main area mit Tabs
        main_frame = tk.Frame(self.root, bg=self.colors['bg'])
        main_frame.pack(fill="both", expand=True)

        style = ttk.Style()
        style.theme_use('default')
        style.configure('TNotebook', background=self.colors['bg'], borderwidth=0)
        style.configure('TNotebook.Tab', background=self.colors['bg_tertiary'],
                        foreground=self.colors['fg'], padding=[20, 10])
        style.map('TNotebook.Tab', background=[('selected', self.colors['accent'])])

        self.notebook = ttk.Notebook(main_frame)
        self.notebook.pack(fill="both", expand=True, padx=10, pady=10)

        self.budget_tab = tk.Frame(self.notebook, bg=self.colors['bg'])
        self.notebook.add(self.budget_tab, text="💰 Budget-Eingabe")

        self.stats_tab = tk.Frame(self.notebook, bg=self.colors['bg'])
        self.notebook.add(self.stats_tab, text="📊 Monatsvergleich")

        self.year_tab = tk.Frame(self.notebook, bg=self.colors['bg'])
        self.notebook.add(self.year_tab, text="📅 Jahresübersicht")

        self.trends_tab = tk.Frame(self.notebook, bg=self.colors['bg'])
        self.notebook.add(self.trends_tab, text="📈 Trends & Prognosen")

        self.goals_tab = tk.Frame(self.notebook, bg=self.colors['bg'])
        self.notebook.add(self.goals_tab, text="🎯 Sparziele")

        self.dashboard_tab = tk.Frame(self.notebook, bg=self.colors['bg'])
        self.notebook.add(self.dashboard_tab, text="🏦 Dashboard")

        self.ki_tab = tk.Frame(self.notebook, bg=self.colors['bg'])
        self.notebook.add(self.ki_tab, text="🤖 KI-Analyse")

        self.rules_tab = tk.Frame(self.notebook, bg=self.colors['bg'])
        self.notebook.add(self.rules_tab, text="⚙️ Regeln")

        self.build_budget_tab()
        self.build_stats_tab()
        self.build_year_tab()
        self.build_trends_tab()
        self.build_goals_tab()
        self.build_dashboard_tab()
        self.build_ki_tab()
        self.build_rules_tab()
        self._update_undo_redo_buttons()

        # ── Statusleiste (ganz unten) ──
        self._build_status_bar()

        # ── Keyboard Shortcuts ──
        self._bind_shortcuts()

    def _build_profile_bar(self, bar):
        """Erstellt die Profil-Leiste mit Dropdown, Erstellen und Löschen."""
        tk.Label(bar, text="👤 Profil:", bg=self.colors['bg_secondary'],
                 fg=self.colors['fg'], font=("Segoe UI", 10, "bold")).pack(side="left", padx=(15, 5), pady=8)

        profiles = self.model.get_profiles()
        self.profile_var = tk.StringVar(value=self.current_profile.get())
        self.profile_combo = ttk.Combobox(bar, textvariable=self.profile_var,
                                          values=profiles, state="readonly", width=18,
                                          font=("Segoe UI", 10))
        self.profile_combo.pack(side="left", padx=5, pady=8)
        self.profile_combo.bind("<<ComboboxSelected>>", self._on_profile_selected)

        self.create_button(bar, "➕ Neues Profil", self._create_profile, self.colors['success']).pack(side="left", padx=5)
        self.create_button(bar, "🗑️ Profil löschen", self._delete_profile, self.colors['danger']).pack(side="left", padx=5)

        # Aktueller Profil-Anzeige
        self.profile_info_label = tk.Label(bar, text=f"Aktives Profil: {self.current_profile.get()}",
                                           bg=self.colors['bg_secondary'], fg=self.colors['fg_muted'],
                                           font=("Segoe UI", 9, "italic"))
        self.profile_info_label.pack(side="left", padx=20)

        # 🔍 Suchfeld (rechts in der Profil-Leiste)
        search_frame = tk.Frame(bar, bg=self.colors['bg_secondary'])
        search_frame.pack(side="right", padx=15, pady=5)
        tk.Label(search_frame, text="🔍", bg=self.colors['bg_secondary'],
                 fg=self.colors['fg'], font=("Segoe UI", 12)).pack(side="left", padx=(0, 5))
        search_entry = tk.Entry(search_frame, textvariable=self.search_var, width=22,
                                font=("Segoe UI", 10), bg=self.colors['bg_input'],
                                fg=self.colors['fg'], insertbackground=self.colors['fg'],
                                relief="flat", borderwidth=2)
        search_entry.pack(side="left")
        search_entry.insert(0, "Suchen…")
        search_entry.config(fg=self.colors['fg_muted'])

        def on_focus_in(e):
            if search_entry.get() == "Suchen…":
                search_entry.delete(0, "end")
                search_entry.config(fg=self.colors['fg'])

        def on_focus_out(e):
            if search_entry.get() == "":
                search_entry.insert(0, "Suchen…")
                search_entry.config(fg=self.colors['fg_muted'])
                self.search_var.set("")
                self._apply_search_filter("")

        search_entry.bind("<FocusIn>", on_focus_in)
        search_entry.bind("<FocusOut>", on_focus_out)
        self.search_var.trace_add("write", self._on_search_change)

        clear_btn = tk.Button(search_frame, text="✕", command=lambda: [self.search_var.set(""),
                                                                         search_entry.delete(0, "end"),
                                                                         search_entry.insert(0, "Suchen…"),
                                                                         search_entry.config(fg=self.colors['fg_muted']),
                                                                         self._apply_search_filter("")],
                              bg=self.colors['bg_tertiary'], fg=self.colors['fg_muted'],
                              font=("Segoe UI", 8), relief="flat", cursor="hand2", padx=4)
        clear_btn.pack(side="left", padx=2)

    def _on_profile_selected(self, event=None):
        """Wechselt das aktive Profil."""
        new_profile = self.profile_var.get()
        if new_profile == self.current_profile.get():
            return
        if messagebox.askyesno("Profil wechseln",
                               f"Zum Profil '{new_profile}' wechseln?\n(Ungespeicherte Änderungen gehen verloren)"):
            self.current_profile.set(new_profile)
            self.model.current_profile = new_profile
            self.undo_redo.clear()
            self.load_month(self.current_month.get())
            self.profile_info_label.config(text=f"Aktives Profil: {new_profile}")

    def _create_profile(self):
        name = simpledialog.askstring("Neues Profil", "Name des neuen Profils:", parent=self.root)
        if not name or not name.strip():
            return
        name = name.strip().replace(" ", "_")
        if name in self.model.get_profiles():
            messagebox.showinfo("Info", "Profil existiert bereits.")
            return
        self.model.create_profile(name)
        self.model.save_settings()
        # Dropdown aktualisieren
        profiles = self.model.get_profiles()
        self.profile_combo['values'] = profiles
        messagebox.showinfo("✅ Erfolg", f"Profil '{name}' erstellt!\nSie können es jetzt im Dropdown auswählen.")

    def _delete_profile(self):
        profile = self.current_profile.get()
        if profile == DEFAULT_PROFILE:
            messagebox.showerror("Fehler", "Das Standard-Profil kann nicht gelöscht werden.")
            return
        if not messagebox.askyesno("Profil löschen",
                                   f"Profil '{profile}' wirklich löschen?\nAlle Daten dieses Profils werden gelöscht!"):
            return
        self.model.delete_profile(profile)
        self.current_profile.set(DEFAULT_PROFILE)
        self.model.current_profile = DEFAULT_PROFILE
        self.profile_var.set(DEFAULT_PROFILE)
        profiles = self.model.get_profiles()
        self.profile_combo['values'] = profiles
        self.load_month(self.current_month.get())
        self.profile_info_label.config(text=f"Aktives Profil: {DEFAULT_PROFILE}")
        messagebox.showinfo("✅", f"Profil '{profile}' gelöscht.")

    # ---- Undo/Redo ----
    def _get_current_state(self):
        """Snapshot des aktuellen Zustands für Undo/Redo."""
        state = {}
        for (mc, sc, item), refs in self.labels_by_item.items():
            state[(mc, sc, item)] = {
                'amount': refs['amt'].get(),
                'note': refs['note'].get()
            }
        return state

    def _push_undo_state(self):
        """Speichert den aktuellen Zustand in den Undo-Stack."""
        if self._suppress_undo:
            return
        state = self._get_current_state()
        self.undo_redo.push(state)
        self._update_undo_redo_buttons()

    def _restore_state(self, state):
        """Stellt einen gespeicherten Zustand wieder her."""
        if state is None:
            return
        self._suppress_undo = True
        for (mc, sc, item), refs in self.labels_by_item.items():
            if (mc, sc, item) in state:
                refs['amt'].set(state[(mc, sc, item)]['amount'])
                refs['note'].set(state[(mc, sc, item)]['note'])
        self._suppress_undo = False
        self.recalculate_all()
        self._update_undo_redo_buttons()

    def do_undo(self):
        if not self.undo_redo.can_undo():
            return
        state = self.undo_redo.undo()
        self._restore_state(state)

    def do_redo(self):
        if not self.undo_redo.can_redo():
            return
        state = self.undo_redo.redo()
        self._restore_state(state)

    def _update_undo_redo_buttons(self):
        if self.undo_btn:
            self.undo_btn.config(
                bg="#555555" if not self.undo_redo.can_undo() else "#0078d4",
                state="normal" if self.undo_redo.can_undo() else "disabled"
            )
        if self.redo_btn:
            self.redo_btn.config(
                bg="#555555" if not self.undo_redo.can_redo() else "#5c2d91",
                state="normal" if self.undo_redo.can_redo() else "disabled"
            )

    # ---- Budget Tab ----
    def build_budget_tab(self):
        left = tk.Frame(self.budget_tab, bg=self.colors['bg'])
        left.pack(side="left", fill="both", expand=True, padx=10, pady=10)

        right = tk.Frame(self.budget_tab, bg=self.colors['bg_secondary'])
        right.pack(side="right", fill="y", padx=(0, 10), pady=10)

        # ── Bulk-Action-Toolbar (initial versteckt) ──
        self._bulk_toolbar_frame = tk.Frame(left, bg=self.colors['bg_tertiary'])
        # Wird erst bei Bulk-Mode eingeblendet
        self._build_bulk_toolbar(self._bulk_toolbar_frame)

        canvas = tk.Canvas(left, bg=self.colors['bg'], highlightthickness=0)
        scrollbar = ttk.Scrollbar(left, orient="vertical", command=canvas.yview)
        self.cat_frame = tk.Frame(canvas, bg=self.colors['bg'])
        self.cat_frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=self.cat_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        canvas.bind_all("<MouseWheel>", lambda e: canvas.yview_scroll(int(-1 * (e.delta / 120)), "units"))

        self.build_categories_ui()

        right_inner = tk.Frame(right, bg=self.colors['bg_secondary'], width=340)
        right_inner.pack(fill="both", expand=True, padx=15, pady=15)
        right_inner.pack_propagate(False)

        header = tk.Frame(right_inner, bg=self.colors['bg_tertiary'], height=50)
        header.pack(fill="x", pady=(0, 15))
        tk.Label(header, text="📊 Finanzübersicht", bg=self.colors['bg_tertiary'],
                 fg=self.colors['fg'], font=("Segoe UI", 14, "bold")).pack(pady=12)

        self.create_stat_card(right_inner, "💰 Gesamteinnahmen", "0.00 €", self.colors['success'], "income_label")
        self.create_stat_card(right_inner, "💸 Gesamtausgaben", "0.00 €", self.colors['danger'], "expense_label")

        saldo_card = tk.Frame(right_inner, bg=self.colors['bg_tertiary'], relief="flat")
        saldo_card.pack(fill="x", pady=8)
        tk.Label(saldo_card, text="💵 Saldo", bg=self.colors['bg_tertiary'],
                 fg=self.colors['fg_muted'], font=("Segoe UI", 10)).pack(anchor="w", padx=12, pady=(10, 2))
        self.balance_label = tk.Label(saldo_card, text="0.00 €", bg=self.colors['bg_tertiary'],
                                      fg=self.colors['fg'], font=("Segoe UI", 18, "bold"))
        self.balance_label.pack(anchor="w", padx=12, pady=(0, 10))

        ttk.Separator(right_inner, orient="horizontal").pack(fill="x", pady=15)

        goal_frame = tk.Frame(right_inner, bg=self.colors['bg_secondary'])
        goal_frame.pack(fill="x", pady=5)
        tk.Label(goal_frame, text="🎯 Sparziele", bg=self.colors['bg_secondary'],
                 fg=self.colors['fg_secondary'], font=("Segoe UI", 11, "bold")).pack(anchor="w", pady=(0, 5))

        # Mini-Vorschau Sparziele (max 2)
        self.goal_preview_frame = tk.Frame(goal_frame, bg=self.colors['bg_secondary'])
        self.goal_preview_frame.pack(fill="x")

        self.create_button(goal_frame, "📋 Alle Ziele verwalten",
                           lambda: self.notebook.select(self.goals_tab),
                           self.colors['accent']).pack(anchor="w", pady=(8, 0))

        ttk.Separator(right_inner, orient="horizontal").pack(fill="x", pady=15)
        tk.Label(right_inner, text="🔝 Top-3 Ausgaben", bg=self.colors['bg_secondary'],
                 fg=self.colors['fg_secondary'], font=("Segoe UI", 11, "bold")).pack(anchor="w", pady=(0, 10))
        self.top3_boxes = []
        for i in range(3):
            box = tk.Frame(right_inner, bg=self.colors['bg_tertiary'], relief="flat")
            box.pack(fill="x", pady=3)
            lbl = tk.Label(box, text=f"{i + 1}. -", bg=self.colors['bg_tertiary'],
                           fg=self.colors['fg_secondary'], font=("Segoe UI", 9), anchor="w")
            lbl.pack(padx=10, pady=6, fill="x")
            self.top3_boxes.append(lbl)

        ttk.Separator(right_inner, orient="horizontal").pack(fill="x", pady=15)
        info_frame = tk.Frame(right_inner, bg=self.colors['bg_secondary'])
        info_frame.pack(fill="x")
        self.saving_rate_label = tk.Label(info_frame, text="📈 Sparquote: 0.0 %",
                                          bg=self.colors['bg_secondary'], fg=self.colors['fg_secondary'],
                                          font=("Segoe UI", 9))
        self.saving_rate_label.pack(anchor="w", pady=3)
        self.fixed_var_label = tk.Label(info_frame, text="🔒 Fixkosten: 0.00 €",
                                        bg=self.colors['bg_secondary'], fg=self.colors['fg_secondary'],
                                        font=("Segoe UI", 9))
        self.fixed_var_label.pack(anchor="w", pady=3)
        self.variable_var_label = tk.Label(info_frame, text="🔄 Variable Kosten: 0.00 €",
                                           bg=self.colors['bg_secondary'], fg=self.colors['fg_secondary'],
                                           font=("Segoe UI", 9))
        self.variable_var_label.pack(anchor="w", pady=3)

    def build_stats_tab(self):
        controls = tk.Frame(self.stats_tab, bg=self.colors['bg'])
        controls.pack(fill="x", padx=20, pady=10)
        tk.Label(controls, text="Vergleichsmonate:", bg=self.colors['bg'],
                 fg=self.colors['fg'], font=("Segoe UI", 11, "bold")).pack(side="left", padx=10)
        self.comparison_months = tk.StringVar(value="6")
        ttk.Spinbox(controls, from_=1, to=12, textvariable=self.comparison_months, width=5).pack(side="left", padx=5)
        self.create_button(controls, "🔄 Aktualisieren", self.update_charts,
                           self.colors['accent']).pack(side="left", padx=10)

        # Chart-Auswahl Tabs
        chart_nb = ttk.Notebook(self.stats_tab)
        chart_nb.pack(fill="both", expand=True, padx=10, pady=5)

        # Tab A: Verlauf (Einnahmen/Ausgaben/Saldo)
        tab_verlauf = tk.Frame(chart_nb, bg=self.colors['bg'])
        chart_nb.add(tab_verlauf, text="📈 Verlauf")

        # Tab B: Ausgaben % Vergleich
        tab_pct = tk.Frame(chart_nb, bg=self.colors['bg'])
        chart_nb.add(tab_pct, text="📊 Vergleich %")

        # Tab C: Sparquote
        tab_sparquote = tk.Frame(chart_nb, bg=self.colors['bg'])
        chart_nb.add(tab_sparquote, text="💚 Sparquote")

        # Tab D: Top-Kategorien Verlauf
        tab_topcat = tk.Frame(chart_nb, bg=self.colors['bg'])
        chart_nb.add(tab_topcat, text="🏆 Top-Kategorien")

        # Figures
        self.fig1 = Figure(figsize=(9, 4), facecolor=self.colors['bg'])
        self.canvas1 = FigureCanvasTkAgg(self.fig1, tab_verlauf)
        self.canvas1.get_tk_widget().pack(fill="both", expand=True)

        self.fig_pct = Figure(figsize=(9, 4), facecolor=self.colors['bg'])
        self.canvas_pct = FigureCanvasTkAgg(self.fig_pct, tab_pct)
        self.canvas_pct.get_tk_widget().pack(fill="both", expand=True)

        self.fig_sparquote = Figure(figsize=(9, 4), facecolor=self.colors['bg'])
        self.canvas_sparquote = FigureCanvasTkAgg(self.fig_sparquote, tab_sparquote)
        self.canvas_sparquote.get_tk_widget().pack(fill="both", expand=True)

        self.fig_topcat = Figure(figsize=(9, 4), facecolor=self.colors['bg'])
        self.canvas_topcat = FigureCanvasTkAgg(self.fig_topcat, tab_topcat)
        self.canvas_topcat.get_tk_widget().pack(fill="both", expand=True)

        # Pie chart tab (Ausgaben-Verteilung) als 5. Tab
        tab_pie = tk.Frame(chart_nb, bg=self.colors['bg'])
        chart_nb.add(tab_pie, text="🥧 Verteilung")
        self.fig2 = Figure(figsize=(6, 4), facecolor=self.colors['bg'])
        self.canvas2 = FigureCanvasTkAgg(self.fig2, tab_pie)
        self.canvas2.get_tk_widget().pack(fill="both", expand=True)

    def build_year_tab(self):
        controls = tk.Frame(self.year_tab, bg=self.colors['bg'])
        controls.pack(fill="x", padx=20, pady=10)
        tk.Label(controls, text="Jahr:", bg=self.colors['bg'],
                 fg=self.colors['fg'], font=("Segoe UI", 11, "bold")).pack(side="left", padx=10)
        self.year_select = tk.StringVar(value=str(datetime.now().year))
        ttk.Spinbox(controls, from_=2000, to=2100, textvariable=self.year_select, width=6).pack(side="left", padx=5)
        self.create_button(controls, "🔄 Laden", self.update_year_overview, self.colors['accent']).pack(side="left", padx=10)

        stats_frame = tk.Frame(self.year_tab, bg=self.colors['bg_secondary'])
        stats_frame.pack(fill="both", expand=True, padx=20, pady=10)

        summary = tk.Frame(stats_frame, bg=self.colors['bg_secondary'])
        summary.pack(fill="x", pady=10)
        self.year_income_label = tk.Label(summary, text="Jahreseinnahmen: 0.00 €",
                                          bg=self.colors['bg_secondary'], fg=self.colors['success'],
                                          font=("Segoe UI", 14, "bold"))
        self.year_income_label.pack(pady=5)
        self.year_expense_label = tk.Label(summary, text="Jahresausgaben: 0.00 €",
                                           bg=self.colors['bg_secondary'], fg=self.colors['danger'],
                                           font=("Segoe UI", 14, "bold"))
        self.year_expense_label.pack(pady=5)
        self.year_balance_label = tk.Label(summary, text="Jahressaldo: 0.00 €",
                                           bg=self.colors['bg_secondary'], fg=self.colors['accent'],
                                           font=("Segoe UI", 16, "bold"))
        self.year_balance_label.pack(pady=10)

        ttk.Separator(stats_frame).pack(fill="x", pady=10)
        avg_frame = tk.Frame(stats_frame, bg=self.colors['bg_secondary'])
        avg_frame.pack(fill="x", pady=10)
        tk.Label(avg_frame, text="📊 Durchschnittswerte (Monat)", bg=self.colors['bg_secondary'],
                 fg=self.colors['fg'], font=("Segoe UI", 12, "bold")).pack(pady=5)
        self.avg_income_label = tk.Label(avg_frame, text="Ø Einnahmen: 0.00 €",
                                         bg=self.colors['bg_secondary'], fg=self.colors['fg_secondary'],
                                         font=("Segoe UI", 11))
        self.avg_income_label.pack(pady=3)
        self.avg_expense_label = tk.Label(avg_frame, text="Ø Ausgaben: 0.00 €",
                                          bg=self.colors['bg_secondary'], fg=self.colors['fg_secondary'],
                                          font=("Segoe UI", 11))
        self.avg_expense_label.pack(pady=3)
        self.avg_balance_label = tk.Label(avg_frame, text="Ø Saldo: 0.00 €",
                                          bg=self.colors['bg_secondary'], fg=self.colors['fg_secondary'],
                                          font=("Segoe UI", 11))
        self.avg_balance_label.pack(pady=3)

        self.fig_year = Figure(figsize=(10, 5), facecolor=self.colors['bg'])
        self.canvas_year = FigureCanvasTkAgg(self.fig_year, stats_frame)
        self.canvas_year.get_tk_widget().pack(fill="both", expand=True, pady=10)

    def build_trends_tab(self):
        controls = tk.Frame(self.trends_tab, bg=self.colors['bg'])
        controls.pack(fill="x", padx=20, pady=10)

        tk.Label(controls, text="🔮 Prognose:", bg=self.colors['bg'],
                 fg=self.colors['fg'], font=("Segoe UI", 11, "bold")).pack(side="left", padx=(0, 8))

        self.forecast_months = tk.StringVar(value="3")
        ttk.Spinbox(controls, from_=1, to=6, textvariable=self.forecast_months,
                    width=4).pack(side="left", padx=(0, 5))
        tk.Label(controls, text="Monate voraus", bg=self.colors['bg'],
                 fg=self.colors['fg_muted'], font=("Segoe UI", 9)).pack(side="left", padx=(0, 15))

        tk.Label(controls, text="Basis:", bg=self.colors['bg'],
                 fg=self.colors['fg'], font=("Segoe UI", 10)).pack(side="left")
        self.trend_history_months = tk.StringVar(value="6")
        ttk.Spinbox(controls, from_=3, to=24, textvariable=self.trend_history_months,
                    width=4).pack(side="left", padx=5)
        tk.Label(controls, text="Monate", bg=self.colors['bg'],
                 fg=self.colors['fg_muted'], font=("Segoe UI", 9)).pack(side="left", padx=(0, 15))

        self.create_button(controls, "🔄 Berechnen", self.update_trends,
                           self.colors['accent']).pack(side="left", padx=5)

        # Sub-Tabs für verschiedene Prognose-Ansichten
        trend_nb = ttk.Notebook(self.trends_tab)
        trend_nb.pack(fill="both", expand=True, padx=10, pady=5)

        tab_main = tk.Frame(trend_nb, bg=self.colors['bg'])
        trend_nb.add(tab_main, text="📈 Hauptprognose")

        tab_scenario = tk.Frame(trend_nb, bg=self.colors['bg'])
        trend_nb.add(tab_scenario, text="🎭 Best/Worst Case")

        tab_seasonal = tk.Frame(trend_nb, bg=self.colors['bg'])
        trend_nb.add(tab_seasonal, text="📅 Saisonalität")

        tab_moving = tk.Frame(trend_nb, bg=self.colors['bg'])
        trend_nb.add(tab_moving, text="〰️ Gleitender Ø")

        self.fig_trend = Figure(figsize=(11, 5), facecolor=self.colors['bg'])
        self.canvas_trend = FigureCanvasTkAgg(self.fig_trend, tab_main)
        self.canvas_trend.get_tk_widget().pack(fill="both", expand=True)

        self.fig_scenario = Figure(figsize=(11, 5), facecolor=self.colors['bg'])
        self.canvas_scenario = FigureCanvasTkAgg(self.fig_scenario, tab_scenario)
        self.canvas_scenario.get_tk_widget().pack(fill="both", expand=True)

        self.fig_seasonal = Figure(figsize=(11, 5), facecolor=self.colors['bg'])
        self.canvas_seasonal = FigureCanvasTkAgg(self.fig_seasonal, tab_seasonal)
        self.canvas_seasonal.get_tk_widget().pack(fill="both", expand=True)

        self.fig_moving = Figure(figsize=(11, 5), facecolor=self.colors['bg'])
        self.canvas_moving = FigureCanvasTkAgg(self.fig_moving, tab_moving)
        self.canvas_moving.get_tk_widget().pack(fill="both", expand=True)

    def create_button(self, parent, text, command, color, width=None):
        btn = tk.Button(parent, text=text, command=command, bg=color, fg="white",
                        font=("Segoe UI", 9, "bold"), relief="flat", cursor="hand2",
                        padx=12, pady=6, borderwidth=0)
        if width:
            btn.config(width=width)
        btn.bind("<Enter>", lambda e: btn.config(bg=self.lighten_color(color)))
        btn.bind("<Leave>", lambda e: btn.config(bg=color))
        return btn

    def lighten_color(self, color):
        color = color.lstrip('#')
        r, g, b = tuple(int(color[i:i + 2], 16) for i in (0, 2, 4))
        return f'#{min(255, r + 20):02x}{min(255, g + 20):02x}{min(255, b + 20):02x}'

    def create_stat_card(self, parent, title, value, color, var_name):
        card = tk.Frame(parent, bg=self.colors['bg_tertiary'], relief="flat")
        card.pack(fill="x", pady=5)
        tk.Label(card, text=title, bg=self.colors['bg_tertiary'], fg=self.colors['fg_muted'],
                 font=("Segoe UI", 9)).pack(anchor="w", padx=12, pady=(8, 2))
        lbl = tk.Label(card, text=value, bg=self.colors['bg_tertiary'], fg=color,
                       font=("Segoe UI", 14, "bold"))
        lbl.pack(anchor="w", padx=12, pady=(0, 8))
        setattr(self, var_name, lbl)

    def build_categories_ui(self):
        current_values = {}
        for (mc, sc, item), refs in self.labels_by_item.items():
            current_values[(mc, sc, item)] = {
                "amt": refs["amt"].get(), "note": refs["note"].get()
            }

        for w in self.cat_frame.winfo_children():
            w.destroy()
        self.labels_by_item.clear()
        self.totals_per_category.clear()
        self._budget_warn_labels = {}

        row = 0
        for main_cat, subs in self.model.structure.items():
            mc_frame = tk.LabelFrame(self.cat_frame, text="", bg=self.colors['bg_secondary'],
                                     fg=self.colors['fg'], relief="flat", borderwidth=2, padx=12, pady=10)
            mc_frame.grid(row=row, column=0, sticky="we", padx=8, pady=8)
            mc_frame.columnconfigure(2, weight=1)

            header_frame = tk.Frame(mc_frame, bg=self.colors['bg_secondary'])
            header_frame.grid(row=0, column=0, columnspan=4, sticky="we", pady=(0, 8))

            icon = "💰" if "Einnahmen" in main_cat else "🏠" if "Fix" in main_cat else "🛒" if "Variable" in main_cat else "🎯"
            tk.Label(header_frame, text=f"{icon} {main_cat}", bg=self.colors['bg_secondary'],
                     fg=self.colors['fg'], font=("Segoe UI", 12, "bold")).pack(side="left")

            tk.Button(header_frame, text="➕ Unterkat.",
                      command=lambda mc=main_cat: self.quick_add_subcategory(mc),
                      bg=self.colors['accent'], fg="white", font=("Segoe UI", 8, "bold"),
                      relief="flat", cursor="hand2", padx=8, pady=3).pack(side="left", padx=5)

            # Löschen der gesamten Hauptkategorie (nur im Löschmodus)
            if self.delete_mode.get():
                tk.Button(header_frame, text="🗑️ Kat.",
                          command=lambda mc=main_cat: self.delete_main_category(mc),
                          bg=self.colors['danger'], fg="white", font=("Segoe UI", 8, "bold"),
                          relief="flat", cursor="hand2", padx=8, pady=3).pack(side="left", padx=5)

            budget_limit = self.model.budget_warnings.get(main_cat)
            if budget_limit:
                # Warnstufen-Label (wird in recalculate_all dynamisch aktualisiert)
                warn_lbl = tk.Label(header_frame, text=f"Limit: {budget_limit:.0f} €",
                                    bg=self.colors['bg_secondary'], fg=self.colors['warning'],
                                    font=("Segoe UI", 9))
                warn_lbl.pack(side="left", padx=10)
                # Merke Label für dynamische Aktualisierung
                if not hasattr(self, '_budget_warn_labels'):
                    self._budget_warn_labels = {}
                self._budget_warn_labels[main_cat] = warn_lbl

            total_label = tk.Label(header_frame, text="Summe: 0.00 €",
                                   bg=self.colors['bg_secondary'], fg=self.colors['warning'],
                                   font=("Segoe UI", 11, "bold"))
            total_label.pack(side="right")
            self.totals_per_category[main_cat] = total_label

            subrow = 1
            for subcat, items in subs.items():
                sc_frame = tk.Frame(mc_frame, bg=self.colors['bg_tertiary'])
                sc_frame.grid(row=subrow, column=0, columnspan=5, sticky="we", pady=(8, 4))
                tk.Label(sc_frame, text=f"📁 {subcat}", bg=self.colors['bg_tertiary'],
                         fg=self.colors['fg_secondary'], font=("Segoe UI", 10, "bold")).pack(side="left", padx=8, pady=4)
                tk.Button(sc_frame, text="➕",
                          command=lambda mc=main_cat, sc=subcat: self.quick_add_item(mc, sc),
                          bg=self.colors['success'], fg="white", font=("Segoe UI", 8, "bold"),
                          relief="flat", cursor="hand2", width=3).pack(side="left", padx=5)
                # Löschen der gesamten Unterkategorie (nur im Löschmodus)
                if self.delete_mode.get():
                    tk.Button(sc_frame, text="🗑️ Unterkat.",
                              command=lambda mc=main_cat, sc=subcat: self.delete_subcategory(mc, sc),
                              bg=self.colors['danger'], fg="white", font=("Segoe UI", 8, "bold"),
                              relief="flat", cursor="hand2", padx=8, pady=3).pack(side="left", padx=5)
                subrow += 1

                for item in items:
                    item_frame = tk.Frame(mc_frame, bg=self.colors['bg_secondary'])
                    item_frame.grid(row=subrow, column=0, columnspan=5, sticky="we", pady=2)
                    item_frame.columnconfigure(3, weight=1)

                    col = 0

                    # ── Bulk-Auswahl Checkbox ──
                    key = (main_cat, subcat, item)
                    if self.bulk_mode.get():
                        bulk_var = self._bulk_select.get(key, tk.BooleanVar(value=False))
                        self._bulk_select[key] = bulk_var
                        cb = tk.Checkbutton(item_frame, variable=bulk_var,
                                            bg=self.colors['bg_secondary'],
                                            activebackground=self.colors['bg_secondary'],
                                            selectcolor=self.colors['accent'],
                                            command=self._update_bulk_toolbar)
                        cb.grid(row=0, column=col, padx=(4, 0))
                        col += 1
                    else:
                        # Drag Handle ⠿
                        drag_handle = tk.Label(item_frame, text="⠿",
                                               bg=self.colors['bg_secondary'],
                                               fg=self.colors['fg_muted'],
                                               font=("Segoe UI", 12), cursor="fleur")
                        drag_handle.grid(row=0, column=col, padx=(4, 0))
                        self._bind_drag(drag_handle, main_cat, subcat, item, item_frame)
                        col += 1

                    # Item-Name (Doppelklick zum Umbenennen)
                    name_lbl = tk.Label(item_frame, text=f"• {item}",
                                        bg=self.colors['bg_secondary'],
                                        fg=self.colors['fg'],
                                        font=("Segoe UI", 10), anchor="w", width=20,
                                        cursor="hand2")
                    name_lbl.grid(row=0, column=col, sticky="w", padx=(4, 8))
                    name_lbl.bind("<Double-Button-1>",
                                  lambda e, mc=main_cat, sc=subcat, it=item:
                                  self._inline_rename_item(mc, sc, it, e.widget))
                    col += 1

                    # Hover-Highlight für die gesamte Zeile
                    def _row_enter(e, f=item_frame):
                        f.config(bg=self.colors['bg_tertiary'])
                        for ch in f.winfo_children():
                            try:
                                ch.config(bg=self.colors['bg_tertiary'])
                            except Exception:
                                pass

                    def _row_leave(e, f=item_frame):
                        f.config(bg=self.colors['bg_secondary'])
                        for ch in f.winfo_children():
                            try:
                                ch.config(bg=self.colors['bg_secondary'])
                            except Exception:
                                pass

                    item_frame.bind("<Enter>", _row_enter)
                    item_frame.bind("<Leave>", _row_leave)

                    amt_var = tk.StringVar(value="0")
                    amt_entry = tk.Entry(item_frame, textvariable=amt_var, width=12,
                                        font=("Segoe UI", 10), bg=self.colors['bg_input'],
                                        fg=self.colors['fg'],
                                        insertbackground=self.colors['fg'],
                                        relief="flat", justify="right")
                    amt_entry.grid(row=0, column=col, sticky="w", padx=5)
                    col += 1

                    note_var = tk.StringVar(value="")
                    note_entry = tk.Entry(item_frame, textvariable=note_var, width=25,
                                         font=("Segoe UI", 9), bg=self.colors['bg_input'],
                                         fg=self.colors['fg_muted'],
                                         insertbackground=self.colors['fg'],
                                         relief="flat")
                    note_entry.grid(row=0, column=col, sticky="we", padx=5)
                    col += 1

                    if self.delete_mode.get():
                        tk.Button(item_frame, text="❌",
                                  command=lambda m=main_cat, s=subcat, i=item:
                                  self.delete_item(m, s, i),
                                  bg=self.colors['danger'], fg="white",
                                  font=("Segoe UI", 8, "bold"),
                                  relief="flat", cursor="hand2", width=3
                                  ).grid(row=0, column=col, padx=5)

                    self.labels_by_item[key] = {
                        "amt": amt_var, "note": note_var,
                        "frame": item_frame, "mc": main_cat,
                        "sc": subcat, "item": item
                    }

                    if key in current_values:
                        amt_var.set(current_values[key]["amt"])
                        note_var.set(current_values[key]["note"])

                    def _on_change(*_args, k=key):
                        self.on_amount_change(k)
                    amt_var.trace_add("write", _on_change)

                    subrow += 1
            row += 1

        # Ersten Undo-State pushen nach UI-Aufbau
        self.root.after(100, self._push_undo_state)

    def toggle_delete_mode(self):
        if self.bulk_mode.get():
            self.bulk_mode.set(False)
        self.build_categories_ui()

    # ══════════════════════════════════════════════════
    # Feature 3: Bulk Actions
    # ══════════════════════════════════════════════════
    def _toggle_bulk_mode(self):
        """Schaltet Bulk-Auswahl-Modus um."""
        if self.bulk_mode.get():
            if self.delete_mode.get():
                self.delete_mode.set(False)
            self._bulk_select.clear()
            self._bulk_toolbar_frame.pack(fill="x", before=self.cat_frame.master)
        else:
            self._bulk_toolbar_frame.pack_forget()
            self._bulk_select.clear()
        self.build_categories_ui()

    def _build_bulk_toolbar(self, parent):
        """Erstellt die Bulk-Action-Toolbar."""
        tk.Label(parent, text="☑️ Multi-Auswahl:", bg=self.colors['bg_tertiary'],
                 fg=self.colors['fg'], font=("Segoe UI", 10, "bold")).pack(side="left", padx=10, pady=6)

        self.create_button(parent, "☑️ Alle", self._bulk_select_all, self.colors['accent']
                           ).pack(side="left", padx=3)
        self.create_button(parent, "☐ Keine", self._bulk_deselect_all, "#555555"
                           ).pack(side="left", padx=3)

        ttk.Separator(parent, orient="vertical").pack(side="left", fill="y", padx=8, pady=4)

        self.create_button(parent, "🗑️ Ausgewählte löschen",
                           self._bulk_delete, self.colors['danger']).pack(side="left", padx=3)
        self.create_button(parent, "📁 Verschieben nach…",
                           self._bulk_move, "#ff8c00").pack(side="left", padx=3)
        self.create_button(parent, "🔀 Kategorie setzen",
                           self._bulk_recategorize, "#5c2d91").pack(side="left", padx=3)

        self._bulk_count_lbl = tk.Label(parent, text="0 ausgewählt",
                                        bg=self.colors['bg_tertiary'],
                                        fg=self.colors['fg_muted'],
                                        font=("Segoe UI", 9))
        self._bulk_count_lbl.pack(side="right", padx=15)

    def _update_bulk_toolbar(self):
        """Aktualisiert die Anzahl ausgewählter Items."""
        count = sum(1 for v in self._bulk_select.values() if v.get())
        if hasattr(self, '_bulk_count_lbl'):
            self._bulk_count_lbl.config(
                text=f"{count} ausgewählt",
                fg=self.colors['accent'] if count > 0 else self.colors['fg_muted'])

    def _bulk_select_all(self):
        for v in self._bulk_select.values():
            v.set(True)
        self._update_bulk_toolbar()

    def _bulk_deselect_all(self):
        for v in self._bulk_select.values():
            v.set(False)
        self._update_bulk_toolbar()

    def _get_selected_keys(self):
        return [k for k, v in self._bulk_select.items() if v.get()]

    def _bulk_delete(self):
        selected = self._get_selected_keys()
        if not selected:
            messagebox.showinfo("Info", "Keine Items ausgewählt.")
            return
        names = [it for (_, _, it) in selected]
        if not messagebox.askyesno("Bulk-Löschen",
                                   f"{len(selected)} Posten löschen?\n" +
                                   "\n".join(f"  • {n}" for n in names[:10]) +
                                   ("\n  …" if len(names) > 10 else "")):
            return
        self._push_undo_state()
        for mc, sc, item in selected:
            try:
                if mc in self.model.structure and sc in self.model.structure[mc]:
                    lst = self.model.structure[mc][sc]
                    if item in lst:
                        lst.remove(item)
                    if not lst:
                        del self.model.structure[mc][sc]
                    if not self.model.structure.get(mc):
                        del self.model.structure[mc]
            except Exception:
                pass
        self.model.save_settings()
        self._bulk_select.clear()
        self.build_categories_ui()
        self.recalculate_all()
        self._set_status(f"🗑️ {len(selected)} Posten gelöscht", self.colors['danger'])

    def _bulk_move(self):
        """Verschiebt ausgewählte Items in eine andere Unterkategorie."""
        selected = self._get_selected_keys()
        if not selected:
            messagebox.showinfo("Info", "Keine Items ausgewählt.")
            return

        # Ziel-Auswahl Dialog
        dialog = tk.Toplevel(self.root)
        dialog.title("Verschieben nach…")
        dialog.geometry("400x280")
        dialog.configure(bg=self.colors['bg'])
        dialog.grab_set()

        tk.Label(dialog, text=f"📁 {len(selected)} Posten verschieben nach:",
                 bg=self.colors['bg'], fg=self.colors['fg'],
                 font=("Segoe UI", 11, "bold")).pack(pady=15)

        all_subcats = []
        for mc, subs in self.model.structure.items():
            for sc in subs:
                all_subcats.append(f"{mc} › {sc}")

        dest_var = tk.StringVar(value=all_subcats[0] if all_subcats else "")
        ttk.Combobox(dialog, textvariable=dest_var, values=all_subcats,
                     state="readonly", font=("Segoe UI", 10),
                     width=40).pack(padx=20, pady=10)

        def do_move():
            sel = dest_var.get()
            try:
                parts = sel.split(" › ")
                t_mc, t_sc = parts[0], parts[1]
            except Exception:
                messagebox.showerror("Fehler", "Ungültiges Ziel.", parent=dialog)
                return
            self._push_undo_state()
            for mc, sc, item in selected:
                try:
                    if mc in self.model.structure and sc in self.model.structure[mc]:
                        self.model.structure[mc][sc].remove(item)
                        if not self.model.structure[mc][sc]:
                            del self.model.structure[mc][sc]
                    if t_mc in self.model.structure and t_sc in self.model.structure[t_mc]:
                        if item not in self.model.structure[t_mc][t_sc]:
                            self.model.structure[t_mc][t_sc].append(item)
                except Exception:
                    pass
            self.model.save_settings()
            self._bulk_select.clear()
            dialog.destroy()
            self.build_categories_ui()
            self.recalculate_all()
            self._set_status(f"📁 {len(selected)} Posten verschoben nach {t_sc}",
                             self.colors['accent'])

        tk.Button(dialog, text="📁 Verschieben", command=do_move,
                  bg=self.colors['success'], fg="white",
                  font=("Segoe UI", 10, "bold"), relief="flat",
                  padx=20, pady=8).pack(pady=15)

    def _bulk_recategorize(self):
        """Setzt für ausgewählte Items eine neue Hauptkategorie."""
        selected = self._get_selected_keys()
        if not selected:
            messagebox.showinfo("Info", "Keine Items ausgewählt.")
            return

        dialog = tk.Toplevel(self.root)
        dialog.title("Kategorie setzen")
        dialog.geometry("420x300")
        dialog.configure(bg=self.colors['bg'])
        dialog.grab_set()

        tk.Label(dialog, text=f"🔀 Kategorie für {len(selected)} Posten:",
                 bg=self.colors['bg'], fg=self.colors['fg'],
                 font=("Segoe UI", 11, "bold")).pack(pady=15)

        all_items_flat = []
        for mc, subs in self.model.structure.items():
            for sc, its in subs.items():
                all_items_flat.append(f"{mc} › {sc}")

        dest_var = tk.StringVar(value=all_items_flat[0] if all_items_flat else "")
        ttk.Combobox(dialog, textvariable=dest_var, values=list(set(all_items_flat)),
                     state="readonly", font=("Segoe UI", 10), width=40).pack(padx=20, pady=10)

        def do_recategorize():
            sel = dest_var.get()
            try:
                parts = sel.split(" › ")
                t_mc, t_sc = parts[0], parts[1]
            except Exception:
                return
            self._bulk_select.clear()
            dialog.destroy()
            # Delegate to bulk_move with same target
            for mc, sc, item in selected:
                try:
                    self.model.structure[mc][sc].remove(item)
                    if not self.model.structure[mc][sc]:
                        del self.model.structure[mc][sc]
                    if t_mc in self.model.structure and t_sc in self.model.structure[t_mc]:
                        if item not in self.model.structure[t_mc][t_sc]:
                            self.model.structure[t_mc][t_sc].append(item)
                except Exception:
                    pass
            self.model.save_settings()
            self.build_categories_ui()
            self.recalculate_all()

        tk.Button(dialog, text="✅ Übernehmen", command=do_recategorize,
                  bg=self.colors['accent'], fg="white",
                  font=("Segoe UI", 10, "bold"), relief="flat",
                  padx=20, pady=8).pack(pady=15)

    # ══════════════════════════════════════════════════
    # Feature 4: Inline Editing (Doppelklick → Umbenennen)
    # ══════════════════════════════════════════════════
    def _inline_rename_item(self, mc, sc, old_name, label_widget):
        """Ersetzt das Label durch ein Entry zum direkten Umbenennen."""
        frame = label_widget.master

        entry_var = tk.StringVar(value=old_name)
        entry = tk.Entry(frame, textvariable=entry_var, width=20,
                         font=("Segoe UI", 10),
                         bg=self.colors['bg_input'], fg=self.colors['fg'],
                         insertbackground=self.colors['fg'],
                         relief="solid", borderwidth=1)

        # Platziere Entry über dem Label
        label_widget.grid_remove()
        entry.grid(row=0, column=label_widget.grid_info().get('column', 1),
                   sticky="w", padx=(4, 8))
        entry.select_range(0, "end")
        entry.focus_set()

        def commit(event=None):
            new_name = entry_var.get().strip()
            entry.destroy()
            label_widget.grid()

            if not new_name or new_name == old_name:
                return

            # Im Modell umbenennen
            items_list = self.model.structure.get(mc, {}).get(sc, [])
            if old_name in items_list:
                idx = items_list.index(old_name)
                items_list[idx] = new_name

                # Wert mitnehmen
                old_key = (mc, sc, old_name)
                new_key = (mc, sc, new_name)
                if old_key in self.model.values:
                    self.model.values[new_key] = self.model.values.pop(old_key)

                self.model.save_settings()
                self._mark_unsaved()
                self._set_status(f"✏️ '{old_name}' → '{new_name}'", self.colors['accent'])
                self.build_categories_ui()
                self.recalculate_all()

        def cancel(event=None):
            entry.destroy()
            label_widget.grid()

        entry.bind("<Return>", commit)
        entry.bind("<Escape>", cancel)
        entry.bind("<FocusOut>", commit)

    # ---- Drag & Drop ----
    def _bind_drag(self, handle, mc, sc, item, frame):
        """Bindet Drag & Drop Events an den Handle-Label."""
        def on_drag_start(event):
            self._drag_source = (mc, sc, item)
            frame.config(bg=self.colors['accent'])
            for child in frame.winfo_children():
                try:
                    child.config(bg=self.colors['accent'])
                except Exception:
                    pass  # logged silently

        def on_drag_end(event):
            frame.config(bg=self.colors['bg_secondary'])
            for child in frame.winfo_children():
                try:
                    child.config(bg=self.colors['bg_secondary'])
                except Exception:
                    pass  # logged silently
            # Finde Ziel-Item unter Mauszeiger
            x, y = event.x_root, event.y_root
            target = self._find_item_under_cursor(x, y)
            if target and target != self._drag_source:
                self._perform_drop(self._drag_source, target)
            self._drag_source = None

        handle.bind("<ButtonPress-1>", on_drag_start)
        handle.bind("<ButtonRelease-1>", on_drag_end)

        def on_drag_motion(event):
            if self._drag_source:
                x, y = event.x_root, event.y_root
                target = self._find_item_under_cursor(x, y)
                # Hover-Feedback
                for key, refs in self.labels_by_item.items():
                    f = refs.get("frame")
                    if f:
                        if key == target and key != self._drag_source:
                            f.config(bg=self.colors['warning'])
                            for child in f.winfo_children():
                                try:
                                    child.config(bg=self.colors['warning'])
                                except Exception:
                                    pass  # logged silently
                        elif key != self._drag_source:
                            f.config(bg=self.colors['bg_secondary'])
                            for child in f.winfo_children():
                                try:
                                    child.config(bg=self.colors['bg_secondary'])
                                except Exception:
                                    pass  # logged silently
        handle.bind("<B1-Motion>", on_drag_motion)

    def _find_item_under_cursor(self, x, y):
        """Findet das Item-Key unter den Mauskoordinaten."""
        for key, refs in self.labels_by_item.items():
            f = refs.get("frame")
            if not f:
                continue
            try:
                fx = f.winfo_rootx()
                fy = f.winfo_rooty()
                fw = f.winfo_width()
                fh = f.winfo_height()
                if fx <= x <= fx + fw and fy <= y <= fy + fh:
                    return key
            except Exception:
                pass  # logged silently
        return None

    def _perform_drop(self, source, target):
        """Verschiebt source-Item an die Position von target (gleiche subcat)."""
        s_mc, s_sc, s_item = source
        t_mc, t_sc, t_item = target

        # Nur innerhalb der gleichen Unterkategorie verschieben
        if s_mc != t_mc or s_sc != t_sc:
            # Anderen subcat? Frage ob verschieben
            if messagebox.askyesno("Verschieben",
                                   f"'{s_item}' nach '{t_sc}' ({t_mc}) verschieben?"):
                items_src = self.model.structure[s_mc][s_sc]
                items_tgt = self.model.structure[t_mc][t_sc]
                if s_item in items_src:
                    items_src.remove(s_item)
                    idx = items_tgt.index(t_item) if t_item in items_tgt else len(items_tgt)
                    items_tgt.insert(idx, s_item)
                    if not items_src:
                        del self.model.structure[s_mc][s_sc]
                    self.model.save_settings()
                    self.build_categories_ui()
                    self.recalculate_all()
            return

        # Gleiche subcat: Reihenfolge tauschen
        items_list = self.model.structure[s_mc][s_sc]
        if s_item in items_list and t_item in items_list:
            si = items_list.index(s_item)
            ti = items_list.index(t_item)
            items_list[si], items_list[ti] = items_list[ti], items_list[si]
            self.model.save_settings()
            self.build_categories_ui()
            self.recalculate_all()

    # ---- Such- & Filterfunktion ----
    def _on_search_change(self, *args):
        """Debounced search: wartet 200ms nach letzter Eingabe."""
        if self._search_after_id:
            self.root.after_cancel(self._search_after_id)
        query = self.search_var.get()
        if query == "Suchen…":
            return
        self._search_after_id = self.root.after(200, lambda: self._apply_search_filter(query))

    def _apply_search_filter(self, query):
        """Zeigt/versteckt Kategorien und Items basierend auf dem Suchtext."""
        q = query.strip().lower()
        if not q:
            # Alles anzeigen
            for w in self.cat_frame.winfo_children():
                w.grid()
            for key, refs in self.labels_by_item.items():
                f = refs.get("frame")
                if f:
                    f.grid()
            return

        # Items filtern
        matched_mcs = set()
        for key, refs in self.labels_by_item.items():
            mc, sc, item = key
            visible = q in item.lower() or q in sc.lower() or q in mc.lower()
            f = refs.get("frame")
            if f:
                if visible:
                    f.grid()
                    matched_mcs.add(mc)
                else:
                    f.grid_remove()

        # Kategorien-Frames: nur zeigen wenn Treffer vorhanden
        for i, w in enumerate(self.cat_frame.winfo_children()):
            # Hole den main_cat-Namen aus dem Frame
            mc_keys = [k for k in self.labels_by_item if k[0] == list(self.model.structure.keys())[i]] if i < len(self.model.structure) else []
            mc_name = list(self.model.structure.keys())[i] if i < len(self.model.structure) else None
            if mc_name and mc_name in matched_mcs:
                w.grid()
            elif mc_name:
                w.grid_remove()

    # ---- Sparziele Tab ----
    def build_goals_tab(self):
        """Erstellt den Sparziele-Tab mit Multi-Ziel-Verwaltung."""
        # Header
        header = tk.Frame(self.goals_tab, bg=self.colors['bg_tertiary'])
        header.pack(fill="x", padx=0, pady=0)
        tk.Label(header, text="🎯 Sparziele verwalten", bg=self.colors['bg_tertiary'],
                 fg=self.colors['fg'], font=("Segoe UI", 14, "bold")).pack(side="left", padx=20, pady=12)
        self.create_button(header, "➕ Neues Ziel", self._add_savings_goal,
                           self.colors['success']).pack(side="left", padx=10)

        # Gesamtsaldo Info
        self.goals_balance_info = tk.Label(header, text="Verfügbar: 0.00 €",
                                           bg=self.colors['bg_tertiary'], fg=self.colors['accent'],
                                           font=("Segoe UI", 11, "bold"))
        self.goals_balance_info.pack(side="right", padx=20)

        # Scrollbarer Bereich für Ziele
        goals_canvas = tk.Canvas(self.goals_tab, bg=self.colors['bg'], highlightthickness=0)
        goals_scroll = ttk.Scrollbar(self.goals_tab, orient="vertical", command=goals_canvas.yview)
        self.goals_list_frame = tk.Frame(goals_canvas, bg=self.colors['bg'])
        self.goals_list_frame.bind("<Configure>",
                                   lambda e: goals_canvas.configure(scrollregion=goals_canvas.bbox("all")))
        goals_canvas.create_window((0, 0), window=self.goals_list_frame, anchor="nw")
        goals_canvas.configure(yscrollcommand=goals_scroll.set)
        goals_canvas.pack(side="left", fill="both", expand=True, padx=10, pady=10)
        goals_scroll.pack(side="right", fill="y")

        # Chart für Sparziele-Übersicht
        chart_frame = tk.Frame(self.goals_tab, bg=self.colors['bg_secondary'], width=320)
        chart_frame.pack(side="right", fill="y", padx=10, pady=10)
        chart_frame.pack_propagate(False)

        tk.Label(chart_frame, text="📊 Übersicht", bg=self.colors['bg_secondary'],
                 fg=self.colors['fg'], font=("Segoe UI", 12, "bold")).pack(pady=10)

        self.goals_fig = Figure(figsize=(3.2, 4), facecolor=self.colors['bg_secondary'])
        self.goals_canvas_widget = FigureCanvasTkAgg(self.goals_fig, chart_frame)
        self.goals_canvas_widget.get_tk_widget().pack(fill="both", expand=True)

        self._refresh_goals_tab()

    def _refresh_goals_tab(self):
        """Aktualisiert die Sparziel-Karten und den Chart."""
        # Lösche alte Karten
        for w in self.goals_list_frame.winfo_children():
            w.destroy()

        goals = self.model.savings_goals
        balance = self.model.get_totals().get('balance', 0.0)

        if hasattr(self, 'goals_balance_info'):
            color = self.colors['success'] if balance >= 0 else self.colors['danger']
            self.goals_balance_info.config(
                text=f"Verfügbarer Saldo: {balance:.2f} €", fg=color)

        if not goals:
            tk.Label(self.goals_list_frame, text="Noch keine Sparziele definiert.\nKlicke auf '➕ Neues Ziel' um zu starten!",
                     bg=self.colors['bg'], fg=self.colors['fg_muted'],
                     font=("Segoe UI", 11), justify="center").pack(pady=60)
        else:
            for i, goal in enumerate(goals):
                self._build_goal_card(i, goal, balance)

        self._update_goals_chart()

    def _build_goal_card(self, idx, goal, balance):
        """Erstellt eine einzelne Sparziel-Karte mit Fortschrittsbalken."""
        name = goal.get('name', 'Unbekannt')
        target = float(goal.get('target', 0))
        saved = float(goal.get('saved', 0))
        icon = goal.get('icon', '🎯')
        monthly = float(goal.get('monthly', 0))

        card = tk.Frame(self.goals_list_frame, bg=self.colors['bg_secondary'],
                        relief="flat", borderwidth=1)
        card.pack(fill="x", padx=10, pady=6)

        # Header der Karte
        card_header = tk.Frame(card, bg=self.colors['bg_secondary'])
        card_header.pack(fill="x", padx=15, pady=(12, 5))

        tk.Label(card_header, text=f"{icon} {name}", bg=self.colors['bg_secondary'],
                 fg=self.colors['fg'], font=("Segoe UI", 13, "bold")).pack(side="left")

        # Bearbeiten / Löschen Buttons
        btn_frame = tk.Frame(card_header, bg=self.colors['bg_secondary'])
        btn_frame.pack(side="right")
        tk.Button(btn_frame, text="✏️", command=lambda i=idx: self._edit_savings_goal(i),
                  bg=self.colors['bg_tertiary'], fg=self.colors['fg'],
                  font=("Segoe UI", 9), relief="flat", cursor="hand2", padx=6).pack(side="left", padx=2)
        tk.Button(btn_frame, text="❌", command=lambda i=idx: self._delete_savings_goal(i),
                  bg=self.colors['danger'], fg="white",
                  font=("Segoe UI", 9), relief="flat", cursor="hand2", padx=6).pack(side="left", padx=2)

        # Fortschritt
        pct = min((saved / target * 100) if target > 0 else 0, 100)
        remaining = max(target - saved, 0)

        stats_frame = tk.Frame(card, bg=self.colors['bg_secondary'])
        stats_frame.pack(fill="x", padx=15, pady=3)

        tk.Label(stats_frame, text=f"Gespart: {saved:.2f} € / {target:.2f} €",
                 bg=self.colors['bg_secondary'], fg=self.colors['fg_secondary'],
                 font=("Segoe UI", 10)).pack(side="left")
        tk.Label(stats_frame, text=f"{pct:.1f}%",
                 bg=self.colors['bg_secondary'],
                 fg=self.colors['success'] if pct >= 100 else self.colors['accent'],
                 font=("Segoe UI", 11, "bold")).pack(side="right")

        # Fortschrittsbalken (Canvas)
        bar_frame = tk.Frame(card, bg=self.colors['bg_secondary'])
        bar_frame.pack(fill="x", padx=15, pady=(3, 5))

        bar_canvas = tk.Canvas(bar_frame, height=18, bg=self.colors['bg_tertiary'],
                               highlightthickness=0)
        bar_canvas.pack(fill="x")

        def draw_bar(event=None):
            bar_canvas.delete("all")
            w = bar_canvas.winfo_width()
            if w <= 1:
                return
            # Hintergrund
            bar_canvas.create_rectangle(0, 0, w, 18, fill=self.colors['bg_tertiary'], outline="")
            # Füllbalken
            filled_w = int(w * pct / 100)
            if pct >= 100:
                bar_color = self.colors['success']
            elif pct >= 80:
                bar_color = self.colors['warning']
            else:
                bar_color = self.colors['accent']
            if filled_w > 0:
                bar_canvas.create_rectangle(0, 0, filled_w, 18, fill=bar_color, outline="")
            # Prozentzahl im Balken
            bar_canvas.create_text(w // 2, 9, text=f"{pct:.0f}%",
                                   fill="white", font=("Segoe UI", 8, "bold"))

        bar_canvas.bind("<Configure>", draw_bar)
        bar_canvas.after(50, draw_bar)

        # Extra Infos
        info_frame = tk.Frame(card, bg=self.colors['bg_secondary'])
        info_frame.pack(fill="x", padx=15, pady=(0, 8))

        if monthly > 0 and remaining > 0:
            months_needed = int(remaining / monthly) + (1 if remaining % monthly else 0)
            tk.Label(info_frame, text=f"📅 Noch {months_needed} Monate bei {monthly:.2f} €/Monat",
                     bg=self.colors['bg_secondary'], fg=self.colors['fg_muted'],
                     font=("Segoe UI", 9)).pack(side="left")

        # Einzahlen Button
        deposit_frame = tk.Frame(card, bg=self.colors['bg_secondary'])
        deposit_frame.pack(fill="x", padx=15, pady=(0, 10))

        amount_var = tk.StringVar(value="")
        tk.Entry(deposit_frame, textvariable=amount_var, width=10,
                 font=("Segoe UI", 9), bg=self.colors['bg_input'],
                 fg=self.colors['fg'], insertbackground=self.colors['fg'],
                 relief="flat").pack(side="left", padx=(0, 5))
        tk.Label(deposit_frame, text="€", bg=self.colors['bg_secondary'],
                 fg=self.colors['fg'], font=("Segoe UI", 9)).pack(side="left")
        tk.Button(deposit_frame, text="💰 Einzahlen",
                  command=lambda i=idx, v=amount_var: self._deposit_to_goal(i, v),
                  bg=self.colors['success'], fg="white", font=("Segoe UI", 9, "bold"),
                  relief="flat", cursor="hand2", padx=8, pady=3).pack(side="left", padx=8)

        if pct >= 100:
            tk.Label(deposit_frame, text="✅ ZIEL ERREICHT!", bg=self.colors['bg_secondary'],
                     fg=self.colors['success'], font=("Segoe UI", 10, "bold")).pack(side="left", padx=10)

    def _update_goals_chart(self):
        """Aktualisiert den Übersichts-Chart der Sparziele."""
        if not hasattr(self, 'goals_fig'):
            return
        self.goals_fig.clear()
        goals = self.model.savings_goals

        if not goals:
            ax = self.goals_fig.add_subplot(111)
            ax.text(0.5, 0.5, "Keine Ziele\ndefiniert",
                    ha='center', va='center', transform=ax.transAxes,
                    color=self.colors['fg_muted'], fontsize=11)
            ax.set_facecolor(self.colors['bg_secondary'])
            ax.axis('off')
        else:
            ax = self.goals_fig.add_subplot(111)
            names = [g.get('name', '?')[:12] for g in goals]
            targets = [float(g.get('target', 0)) for g in goals]
            saved = [float(g.get('saved', 0)) for g in goals]
            remaining = [max(t - s, 0) for t, s in zip(targets, saved)]

            y = range(len(goals))
            bar_h = 0.35
            bars_saved = ax.barh([i + bar_h/2 for i in y], saved, bar_h,
                                 label='Gespart', color=self.colors['success'], alpha=0.9)
            bars_rem = ax.barh([i - bar_h/2 for i in y], remaining, bar_h,
                               label='Noch nötig', color=self.colors['bg_tertiary'], alpha=0.8)

            ax.set_yticks(list(y))
            ax.set_yticklabels(names, fontsize=8)
            ax.set_xlabel('€', color=self.colors['fg'], fontsize=8)
            ax.legend(fontsize=7, loc='lower right')
            ax.set_facecolor(self.colors['bg_secondary'])
            ax.tick_params(colors=self.colors['fg'], labelsize=8)
            ax.xaxis.label.set_color(self.colors['fg'])
            for spine in ax.spines.values():
                spine.set_color(self.colors['fg_muted'])
            ax.grid(True, alpha=0.2, axis='x')

        self.goals_fig.patch.set_facecolor(self.colors['bg_secondary'])
        self.goals_fig.tight_layout(pad=1.0)
        self.goals_canvas_widget.draw()

    def _add_savings_goal(self):
        """Öffnet Dialog zum Erstellen eines neuen Sparziels."""
        self._savings_goal_dialog(None)

    def _edit_savings_goal(self, idx):
        """Öffnet Dialog zum Bearbeiten eines Sparziels."""
        self._savings_goal_dialog(idx)

    def _savings_goal_dialog(self, idx=None):
        """Dialog zum Erstellen/Bearbeiten eines Sparziels."""
        editing = idx is not None
        goal = self.model.savings_goals[idx].copy() if editing else {
            'name': '', 'target': '', 'saved': '0', 'monthly': '', 'icon': '🎯'
        }

        dialog = tk.Toplevel(self.root)
        dialog.title("Sparziel bearbeiten" if editing else "Neues Sparziel")
        dialog.geometry("400x420")
        dialog.configure(bg=self.colors['bg'])
        dialog.grab_set()

        tk.Label(dialog, text="✏️ Sparziel" + (" bearbeiten" if editing else " erstellen"),
                 bg=self.colors['bg'], fg=self.colors['fg'],
                 font=("Segoe UI", 13, "bold")).pack(pady=15)

        frame = tk.Frame(dialog, bg=self.colors['bg'])
        frame.pack(fill="both", expand=True, padx=25, pady=5)

        fields = {}
        icon_choices = ["🎯", "✈️", "🏖️", "🏠", "🚗", "💻", "🎓", "💍", "🏋️", "🌍", "📱", "🔑", "🛡️", "💰"]

        for label, key, default in [
            ("Name des Ziels:", "name", goal.get('name', '')),
            ("Zielbetrag (€):", "target", str(goal.get('target', ''))),
            ("Bereits gespart (€):", "saved", str(goal.get('saved', '0'))),
            ("Monatliche Rate (€):", "monthly", str(goal.get('monthly', ''))),
        ]:
            tk.Label(frame, text=label, bg=self.colors['bg'], fg=self.colors['fg'],
                     font=("Segoe UI", 10)).pack(anchor="w", pady=(8, 2))
            var = tk.StringVar(value=default)
            tk.Entry(frame, textvariable=var, font=("Segoe UI", 10),
                     bg=self.colors['bg_input'], fg=self.colors['fg'],
                     insertbackground=self.colors['fg'], relief="flat").pack(fill="x", pady=2)
            fields[key] = var

        # Icon Auswahl
        tk.Label(frame, text="Icon:", bg=self.colors['bg'], fg=self.colors['fg'],
                 font=("Segoe UI", 10)).pack(anchor="w", pady=(8, 2))
        icon_frame = tk.Frame(frame, bg=self.colors['bg'])
        icon_frame.pack(fill="x")
        icon_var = tk.StringVar(value=goal.get('icon', '🎯'))
        for ic in icon_choices:
            btn = tk.Radiobutton(icon_frame, text=ic, variable=icon_var, value=ic,
                                 bg=self.colors['bg'], fg=self.colors['fg'],
                                 selectcolor=self.colors['accent'],
                                 activebackground=self.colors['bg'],
                                 font=("Segoe UI", 13), indicatoron=False,
                                 relief="flat", padx=3, pady=2)
            btn.pack(side="left")
        fields['icon'] = icon_var

        def save():
            name = fields['name'].get().strip()
            if not name:
                messagebox.showerror("Fehler", "Bitte einen Namen eingeben.", parent=dialog)
                return
            try:
                target = float(fields['target'].get().replace(',', '.'))
                saved = float(fields['saved'].get().replace(',', '.') or '0')
                monthly_str = fields['monthly'].get().replace(',', '.').strip()
                monthly = float(monthly_str) if monthly_str else 0.0
            except ValueError:
                messagebox.showerror("Fehler", "Bitte gültige Zahlen eingeben.", parent=dialog)
                return

            new_goal = {
                'name': name, 'target': target,
                'saved': saved, 'monthly': monthly,
                'icon': fields['icon'].get()
            }
            if editing:
                self.model.savings_goals[idx] = new_goal
            else:
                self.model.savings_goals.append(new_goal)
            self.model.save_settings()
            dialog.destroy()
            self._refresh_goals_tab()
            self._update_goal_preview()

        tk.Button(dialog, text="💾 Speichern", command=save,
                  bg=self.colors['success'], fg="white",
                  font=("Segoe UI", 10, "bold"), relief="flat",
                  padx=20, pady=8).pack(pady=15)

    def _delete_savings_goal(self, idx):
        name = self.model.savings_goals[idx].get('name', '')
        if messagebox.askyesno("Löschen", f"Sparziel '{name}' wirklich löschen?"):
            self.model.savings_goals.pop(idx)
            self.model.save_settings()
            self._refresh_goals_tab()
            self._update_goal_preview()

    def _deposit_to_goal(self, idx, amount_var):
        """Bucht einen Betrag auf ein Sparziel ein."""
        amt_str = amount_var.get().strip().replace(',', '.')
        try:
            amt = float(amt_str)
        except ValueError:
            messagebox.showerror("Fehler", "Bitte einen gültigen Betrag eingeben.")
            return
        if amt <= 0:
            messagebox.showerror("Fehler", "Betrag muss größer als 0 sein.")
            return
        self.model.savings_goals[idx]['saved'] = float(self.model.savings_goals[idx].get('saved', 0)) + amt
        self.model.save_settings()
        amount_var.set("")
        self._refresh_goals_tab()
        self._update_goal_preview()

    def _update_goal_preview(self):
        """Aktualisiert die Mini-Vorschau im rechten Panel des Budget-Tabs."""
        if not hasattr(self, 'goal_preview_frame'):
            return
        for w in self.goal_preview_frame.winfo_children():
            w.destroy()

        goals = self.model.savings_goals[:2]  # Max 2 anzeigen
        if not goals:
            tk.Label(self.goal_preview_frame, text="Keine Ziele definiert.",
                     bg=self.colors['bg_secondary'], fg=self.colors['fg_muted'],
                     font=("Segoe UI", 9)).pack(anchor="w")
            return

        for goal in goals:
            name = goal.get('name', '?')
            target = float(goal.get('target', 0))
            saved = float(goal.get('saved', 0))
            icon = goal.get('icon', '🎯')
            pct = min((saved / target * 100) if target > 0 else 0, 100)

            row = tk.Frame(self.goal_preview_frame, bg=self.colors['bg_secondary'])
            row.pack(fill="x", pady=2)
            tk.Label(row, text=f"{icon} {name[:14]}", bg=self.colors['bg_secondary'],
                     fg=self.colors['fg'], font=("Segoe UI", 9)).pack(side="left")
            pct_color = self.colors['success'] if pct >= 100 else self.colors['accent']
            tk.Label(row, text=f"{pct:.0f}%", bg=self.colors['bg_secondary'],
                     fg=pct_color, font=("Segoe UI", 9, "bold")).pack(side="right")

            # Mini-Fortschrittsbalken
            bar = tk.Canvas(self.goal_preview_frame, height=6, bg=self.colors['bg_tertiary'],
                            highlightthickness=0)
            bar.pack(fill="x", pady=(0, 3))

            def draw_mini(event=None, p=pct, b=bar):
                b.delete("all")
                w = b.winfo_width()
                if w <= 1:
                    return
                filled = int(w * p / 100)
                bar_c = self.colors['success'] if p >= 100 else (self.colors['warning'] if p >= 80 else self.colors['accent'])
                b.create_rectangle(0, 0, w, 6, fill=self.colors['bg_tertiary'], outline="")
                if filled > 0:
                    b.create_rectangle(0, 0, filled, 6, fill=bar_c, outline="")

            bar.bind("<Configure>", draw_mini)
            bar.after(50, draw_mini)

    def navigate_month(self, direction):
        try:
            current = self.current_month.get()
            year, month = map(int, current.split('-'))
            month += direction
            if month > 12:
                month = 1
                year += 1
            elif month < 1:
                month = 12
                year -= 1
            new_month = f"{year}-{month:02d}"
            self.current_month.set(new_month)
            self.load_month(new_month)
        except:
            messagebox.showerror("Fehler", "Ungültiges Monatsformat")

    def quick_add_subcategory(self, main_cat):
        subcat = simpledialog.askstring("Neue Unterkategorie",
                                        f"Name der Unterkategorie in '{main_cat}':", parent=self.root)
        if subcat and subcat.strip():
            if subcat not in self.model.structure[main_cat]:
                self.model.structure[main_cat][subcat] = []
                self.model.save_settings()
                self.build_categories_ui()
            else:
                messagebox.showinfo("Info", "Unterkategorie existiert bereits.")

    def quick_add_item(self, main_cat, subcat):
        item = simpledialog.askstring("Neuer Posten",
                                      f"Name des Postens in '{subcat}':", parent=self.root)
        if item and item.strip():
            if item not in self.model.structure[main_cat][subcat]:
                self.model.structure[main_cat][subcat].append(item)
                self.model.save_settings()
                self.build_categories_ui()
                self.recalculate_all()
            else:
                messagebox.showinfo("Info", "Posten existiert bereits.")

    def delete_item(self, main_cat, subcat, item):
        if not messagebox.askyesno("Löschen", f"Posten '{item}' wirklich löschen?"):
            return
        self._push_undo_state()
        if item in self.model.structure[main_cat][subcat]:
            self.model.structure[main_cat][subcat].remove(item)
        if not self.model.structure[main_cat][subcat]:
            del self.model.structure[main_cat][subcat]
        if not self.model.structure[main_cat]:
            del self.model.structure[main_cat]
        self.model.save_settings()
        self.build_categories_ui()
        self.recalculate_all()

    def delete_subcategory(self, main_cat, subcat):
        """Löscht eine gesamte Unterkategorie inkl. aller Posten."""
        items = self.model.structure.get(main_cat, {}).get(subcat, [])
        if not messagebox.askyesno(
                "Unterkategorie löschen",
                f"Unterkategorie '{subcat}' mit {len(items)} Posten wirklich löschen?\n"
                f"Posten: {', '.join(items) if items else '(keine)'}"):
            return
        self._push_undo_state()
        if main_cat in self.model.structure and subcat in self.model.structure[main_cat]:
            del self.model.structure[main_cat][subcat]
        if not self.model.structure.get(main_cat):
            del self.model.structure[main_cat]
        self.model.save_settings()
        self.build_categories_ui()
        self.recalculate_all()

    def delete_main_category(self, main_cat):
        """Löscht eine gesamte Hauptkategorie inkl. aller Unterkategorien."""
        structure = self.model.structure.get(main_cat, {})
        total_items = sum(len(v) for v in structure.values())
        subcats = list(structure.keys())
        if not messagebox.askyesno(
                "Hauptkategorie löschen",
                f"Hauptkategorie '{main_cat}' wirklich löschen?\n"
                f"Enthält: {len(subcats)} Unterkategorien, {total_items} Posten.\n"
                f"⚠️ Diese Aktion kann nicht rückgängig gemacht werden!"):
            return
        self._push_undo_state()
        if main_cat in self.model.structure:
            del self.model.structure[main_cat]
        self.model.save_settings()
        self.build_categories_ui()
        self.recalculate_all()

    def auto_fill_fixed(self):
        if not self.auto_fill_enabled.get():
            messagebox.showinfo("Info", "Auto-Fill ist deaktiviert.")
            return
        current_month = self.current_month.get()
        prev_month = get_previous_month(current_month)
        if not prev_month:
            messagebox.showerror("Fehler", "Vorheriger Monat konnte nicht ermittelt werden")
            return
        prev_file = filename_for_month(self.current_profile.get(), prev_month)
        if not os.path.exists(prev_file):
            messagebox.showinfo("Info", f"Keine Daten für {prev_month} gefunden")
            return
        try:
            with open(prev_file, 'r', encoding='utf-8') as f:
                prev_data = json.load(f)
            prev_values = prev_data.get('values', {})
            self._push_undo_state()
            filled_count = 0
            for (mc, sc, item), refs in self.labels_by_item.items():
                if "Fix" in mc or mc.lower().startswith("fix"):
                    prev_val = prev_values.get(mc, {}).get(sc, {}).get(item, {})
                    if prev_val.get('amount'):
                        refs['amt'].set(prev_val['amount'])
                        refs['note'].set(prev_val.get('note', ''))
                        filled_count += 1
            messagebox.showinfo("✅ Auto-Fill", f"{filled_count} Fixkosten vom {prev_month} übernommen!")
            self.recalculate_all()
        except Exception as e:
            messagebox.showerror("Fehler", f"Auto-Fill fehlgeschlagen: {str(e)}")

    def set_budget_limits(self):
        dialog = tk.Toplevel(self.root)
        dialog.title("Budget-Limits festlegen")
        dialog.geometry("400x500")
        dialog.configure(bg=self.colors['bg'])
        tk.Label(dialog, text="⚠️ Budget-Limits pro Kategorie", bg=self.colors['bg'],
                 fg=self.colors['fg'], font=("Segoe UI", 12, "bold")).pack(pady=15)
        frame = tk.Frame(dialog, bg=self.colors['bg'])
        frame.pack(fill="both", expand=True, padx=20, pady=10)
        limit_vars = {}
        for main_cat in self.model.structure.keys():
            if "Einnahmen" not in main_cat:
                cat_frame = tk.Frame(frame, bg=self.colors['bg_secondary'], relief="flat", borderwidth=1)
                cat_frame.pack(fill="x", pady=5, padx=5)
                tk.Label(cat_frame, text=main_cat, bg=self.colors['bg_secondary'],
                         fg=self.colors['fg'], font=("Segoe UI", 10, "bold")).pack(side="left", padx=10, pady=8)
                var = tk.StringVar(value=str(self.model.budget_warnings.get(main_cat, "")))
                tk.Entry(cat_frame, textvariable=var, width=12, bg=self.colors['bg_input'],
                         fg=self.colors['fg'], insertbackground=self.colors['fg']).pack(side="right", padx=10, pady=8)
                limit_vars[main_cat] = var

        def save_limits():
            for cat, var in limit_vars.items():
                val = var.get().strip()
                if val:
                    try:
                        self.model.budget_warnings[cat] = float(val)
                    except Exception:
                        pass  # logged silently
                elif cat in self.model.budget_warnings:
                    del self.model.budget_warnings[cat]
            self.model.save_settings()
            self.build_categories_ui()
            dialog.destroy()
            messagebox.showinfo("✅", "Budget-Limits gespeichert!")

        tk.Button(dialog, text="💾 Speichern", command=save_limits, bg=self.colors['success'],
                  fg="white", font=("Segoe UI", 10, "bold"), relief="flat", padx=20, pady=8).pack(pady=10)

    # ---- CSV Import mit Auto-Kategorisierung ----
    def import_bank_csv(self):
        file = filedialog.askopenfilename(
            title="Konto-CSV importieren",
            filetypes=[("CSV Dateien", "*.csv"), ("Alle Dateien", "*.*")]
        )
        if not file:
            return

        # CSV einlesen
        headers = []
        all_rows = []
        for enc in ['utf-8-sig', 'latin-1']:
            try:
                with open(file, 'r', encoding=enc) as f:
                    reader = csv.reader(f, delimiter=';')
                    headers = next(reader)
                    all_rows = list(reader)
                break
            except:
                continue

        if not headers:
            messagebox.showerror("Fehler", "CSV konnte nicht gelesen werden.")
            return

        # Spaltenzuordnung Dialog
        dialog = tk.Toplevel(self.root)
        dialog.title("CSV Import – Spalten zuordnen")
        dialog.geometry("550x450")
        dialog.configure(bg=self.colors['bg'])
        dialog.grab_set()

        tk.Label(dialog, text="📥 CSV Import – Spalten zuordnen",
                 bg=self.colors['bg'], fg=self.colors['fg'],
                 font=("Segoe UI", 12, "bold")).pack(pady=15)

        tk.Label(dialog, text=f"Gefundene Spalten: {', '.join(headers)}",
                 bg=self.colors['bg'], fg=self.colors['fg_muted'],
                 font=("Segoe UI", 9), wraplength=500).pack(padx=20)

        frame = tk.Frame(dialog, bg=self.colors['bg'])
        frame.pack(fill="both", expand=True, padx=20, pady=10)

        mappings = {}
        for field, label in [("Betrag", "Betrag-Spalte:"), ("Beschreibung", "Beschreibung-Spalte:")]:
            tk.Label(frame, text=label, bg=self.colors['bg'], fg=self.colors['fg'],
                     font=("Segoe UI", 10)).pack(anchor="w", pady=(10, 2))
            var = tk.StringVar(value=headers[0] if headers else "")
            # Auto-detect: suche nach typischen Spaltennamen
            for h in headers:
                hl = h.lower()
                if field == "Betrag" and any(k in hl for k in ['betrag', 'amount', 'wert', 'summe']):
                    var.set(h)
                    break
                if field == "Beschreibung" and any(k in hl for k in ['beschreibung', 'verwendungszweck', 'text', 'buchungstext', 'memo']):
                    var.set(h)
                    break
            combo = ttk.Combobox(frame, textvariable=var, values=headers, state="readonly")
            combo.pack(fill="x", pady=2)
            mappings[field] = var

        # Auto-Kategorisierung Checkbox
        auto_cat_var = tk.BooleanVar(value=True)
        tk.Checkbutton(frame, text="🤖 Auto-Kategorisierung aktivieren",
                       variable=auto_cat_var,
                       bg=self.colors['bg'], fg=self.colors['fg'],
                       selectcolor=self.colors['bg_input'],
                       activebackground=self.colors['bg'],
                       font=("Segoe UI", 10)).pack(anchor="w", pady=10)

        def do_import():
            try:
                amount_col = mappings["Betrag"].get()
                desc_col = mappings["Beschreibung"].get()
                if not amount_col or not desc_col:
                    messagebox.showerror("Fehler", "Bitte alle Spalten zuordnen")
                    return
                amount_idx = headers.index(amount_col)
                desc_idx = headers.index(desc_col)

                transactions = []
                for row in all_rows:
                    if len(row) <= max(amount_idx, desc_idx):
                        continue
                    amount_str = row[amount_idx].replace('.', '').replace(',', '.')
                    amount = ensure_float(amount_str)
                    desc = row[desc_idx].strip()
                    if amount != 0 or desc:
                        transactions.append((desc, amount))

                dialog.destroy()

                if auto_cat_var.get():
                    self._show_import_review(transactions)
                else:
                    messagebox.showinfo("Import", f"{len(transactions)} Transaktionen erkannt.\nAuto-Kategorisierung deaktiviert.")

            except Exception as e:
                messagebox.showerror("Fehler", f"Import fehlgeschlagen: {str(e)}")

        tk.Button(dialog, text="📥 Importieren & Kategorisieren", command=do_import,
                  bg=self.colors['success'], fg="white", font=("Segoe UI", 10, "bold"),
                  relief="flat", padx=20, pady=8).pack(pady=15)

    def _show_import_review(self, transactions):
        """Zeigt Dialog zum Überprüfen & Bestätigen der auto-kategorisierten Transaktionen."""
        categorized = self.model.batch_categorize(transactions)

        review_win = tk.Toplevel(self.root)
        review_win.title("Import – Transaktionen überprüfen")
        review_win.geometry("900x600")
        review_win.configure(bg=self.colors['bg'])
        review_win.grab_set()

        tk.Label(review_win, text=f"🔍 {len(categorized)} Transaktionen – Zuordnung überprüfen",
                 bg=self.colors['bg'], fg=self.colors['fg'],
                 font=("Segoe UI", 12, "bold")).pack(pady=10)

        tk.Label(review_win,
                 text="Grün = automatisch erkannt | Rot = nicht erkannt (manuelle Zuordnung nötig)",
                 bg=self.colors['bg'], fg=self.colors['fg_muted'],
                 font=("Segoe UI", 9)).pack()

        # Scrollbarer Bereich
        canvas = tk.Canvas(review_win, bg=self.colors['bg'], highlightthickness=0)
        scrollbar = ttk.Scrollbar(review_win, orient="vertical", command=canvas.yview)
        scroll_frame = tk.Frame(canvas, bg=self.colors['bg'])
        scroll_frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=scroll_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        canvas.pack(side="left", fill="both", expand=True, padx=10, pady=10)
        scrollbar.pack(side="right", fill="y")
        canvas.bind_all("<MouseWheel>", lambda e: canvas.yview_scroll(int(-1 * (e.delta / 120)), "units"))

        # Kategorieoptionen
        all_items = []
        for mc, subs in self.model.structure.items():
            for sc, items in subs.items():
                for item in items:
                    all_items.append(f"{mc} › {sc} › {item}")
        all_items = ["-- Überspringen --"] + all_items

        row_data = []

        # Header
        header = tk.Frame(scroll_frame, bg=self.colors['bg_tertiary'])
        header.pack(fill="x", padx=5, pady=(0, 5))
        for col, w, txt in [(0, 35, "Beschreibung"), (1, 10, "Betrag"), (2, 30, "Kategorie")]:
            tk.Label(header, text=txt, bg=self.colors['bg_tertiary'], fg=self.colors['fg'],
                     font=("Segoe UI", 9, "bold"), width=w, anchor="w").grid(row=0, column=col, padx=5, pady=5)

        for i, (desc, amount, cat) in enumerate(categorized):
            row_bg = self.colors['bg_secondary'] if i % 2 == 0 else self.colors['bg']
            row_frame = tk.Frame(scroll_frame, bg=row_bg)
            row_frame.pack(fill="x", padx=5, pady=1)

            tk.Label(row_frame, text=desc[:40], bg=row_bg, fg=self.colors['fg'],
                     font=("Segoe UI", 9), width=35, anchor="w").grid(row=0, column=0, padx=5, pady=3)
            amt_color = self.colors['success'] if amount > 0 else self.colors['danger']
            tk.Label(row_frame, text=f"{amount:+.2f} €", bg=row_bg, fg=amt_color,
                     font=("Segoe UI", 9, "bold"), width=10).grid(row=0, column=1, padx=5)

            cat_var = tk.StringVar()
            if cat:
                mc, sc, item = cat
                cat_var.set(f"{mc} › {sc} › {item}")
            else:
                cat_var.set("-- Überspringen --")

            combo = ttk.Combobox(row_frame, textvariable=cat_var, values=all_items,
                                 width=40, font=("Segoe UI", 9))
            combo.grid(row=0, column=2, padx=5)

            # Farb-Indikator
            indicator_color = self.colors['success'] if cat else self.colors['danger']
            tk.Label(row_frame, text="●", bg=row_bg, fg=indicator_color,
                     font=("Segoe UI", 10)).grid(row=0, column=3, padx=3)

            row_data.append((desc, amount, cat_var))

        def apply_import():
            self._push_undo_state()
            applied = 0
            learned = 0
            for desc, amount, cat_var in row_data:
                sel = cat_var.get()
                if sel == "-- Überspringen --":
                    continue
                try:
                    parts = sel.split(" › ")
                    if len(parts) != 3:
                        continue
                    mc, sc, item = parts
                    key = (mc, sc, item)
                    if key in self.labels_by_item:
                        current = ensure_float(self.labels_by_item[key]['amt'].get())
                        self.labels_by_item[key]['amt'].set(f"{current + abs(amount):.2f}")
                        # Lernende Zuordnung speichern
                        orig_cat = self.model.categorize_transaction(desc, amount)
                        if orig_cat != key:
                            self.model.learn_mapping(desc, mc, sc, item)
                            learned += 1
                        applied += 1
                except:
                    continue

            self.model.save_settings()
            review_win.destroy()
            self.recalculate_all()
            learn_msg = f"\n📚 {learned} neue Zuordnung(en) gelernt!" if learned else ""
            messagebox.showinfo("✅ Import abgeschlossen",
                                f"{applied} Transaktionen importiert!{learn_msg}")

        btn_frame = tk.Frame(review_win, bg=self.colors['bg'])
        btn_frame.pack(fill="x", padx=20, pady=10)
        tk.Button(btn_frame, text="✅ Alle übernehmen", command=apply_import,
                  bg=self.colors['success'], fg="white", font=("Segoe UI", 10, "bold"),
                  relief="flat", padx=20, pady=8).pack(side="left", padx=10)
        tk.Button(btn_frame, text="❌ Abbrechen", command=review_win.destroy,
                  bg=self.colors['danger'], fg="white", font=("Segoe UI", 10, "bold"),
                  relief="flat", padx=20, pady=8).pack(side="left")

        stats_auto = sum(1 for _, _, c in categorized if c)
        stats_manual = len(categorized) - stats_auto
        tk.Label(btn_frame,
                 text=f"🤖 {stats_auto} auto | ❓ {stats_manual} manuell",
                 bg=self.colors['bg'], fg=self.colors['fg_muted'],
                 font=("Segoe UI", 9)).pack(side="right", padx=10)

    def update_charts(self):
        try:
            num_months = int(self.comparison_months.get())
        except:
            num_months = 6

        # Daten sammeln
        months_data = []
        current = self.current_month.get()
        for i in range(num_months):
            month = current
            for _ in range(i):
                month = get_previous_month(month)
                if not month:
                    break
            if not month:
                break
            fname = filename_for_month(self.current_profile.get(), month)
            if os.path.exists(fname):
                try:
                    with open(fname, 'r', encoding='utf-8') as f:
                        data = json.load(f)
                    months_data.append((month, data))
                except Exception:
                    pass  # logged silently
        months_data.reverse()

        tc = self.colors['fg']

        def style_ax(ax, title=""):
            ax.set_facecolor(self.colors['bg'])
            ax.tick_params(colors=tc, labelsize=8)
            ax.yaxis.label.set_color(tc)
            ax.xaxis.label.set_color(tc)
            if title:
                ax.set_title(title, color=tc, fontsize=10)
            for spine in ax.spines.values():
                spine.set_color(self.colors['fg_muted'])
            ax.grid(True, alpha=0.2)

        # ---------- Chart 1: Monatlicher Verlauf (€) ----------
        self.fig1.clear()
        ax1 = self.fig1.add_subplot(111)
        if months_data:
            labels = [m[0] for m in months_data]
            incomes, expenses, balances = [], [], []
            for month, data in months_data:
                inc = exp = 0
                for mc, subs in data.get('values', {}).items():
                    for sc, items in subs.items():
                        for item, val in items.items():
                            amt = ensure_float(val.get('amount', 0))
                            if "Einnahmen" in mc:
                                inc += amt
                            else:
                                exp += amt
                incomes.append(inc)
                expenses.append(exp)
                balances.append(inc - exp)
            x = range(len(labels))
            ax1.plot(x, incomes, marker='o', label='Einnahmen', color='#107c10', linewidth=2)
            ax1.plot(x, expenses, marker='s', label='Ausgaben', color='#d13438', linewidth=2)
            ax1.fill_between(x, balances, alpha=0.15,
                             color=self.colors['success'] if balances[-1] >= 0 else self.colors['danger'])
            ax1.plot(x, balances, marker='^', label='Saldo', color='#0078d4', linewidth=2, linestyle='--')
            ax1.axhline(0, color=self.colors['fg_muted'], linewidth=0.8, alpha=0.5)
            ax1.set_xticks(list(x))
            ax1.set_xticklabels(labels, rotation=30, ha='right', fontsize=8)
            ax1.set_ylabel('€')
            ax1.legend(fontsize=8)
            style_ax(ax1, "Einnahmen / Ausgaben / Saldo")
        self.fig1.tight_layout()
        self.canvas1.draw()

        # ---------- Chart 2: Prozent-Vergleich (Ausgaben/Einnahmen %) ----------
        self.fig_pct.clear()
        ax_pct = self.fig_pct.add_subplot(111)
        if months_data:
            labels = [m[0] for m in months_data]
            expense_pcts = []
            saving_pcts = []
            for month, data in months_data:
                inc = exp = 0
                for mc, subs in data.get('values', {}).items():
                    for sc, items in subs.items():
                        for item, val in items.items():
                            amt = ensure_float(val.get('amount', 0))
                            if "Einnahmen" in mc:
                                inc += amt
                            else:
                                exp += amt
                expense_pct = (exp / inc * 100) if inc > 0 else 0
                saving_pct = max(((inc - exp) / inc * 100), 0) if inc > 0 else 0
                expense_pcts.append(expense_pct)
                saving_pcts.append(saving_pct)

            x = range(len(labels))
            w = 0.35
            ax_pct.bar([i - w/2 for i in x], expense_pcts, w, label='Ausgabenquote %',
                       color='#d13438', alpha=0.85)
            ax_pct.bar([i + w/2 for i in x], saving_pcts, w, label='Sparquote %',
                       color='#107c10', alpha=0.85)
            ax_pct.axhline(100, color=self.colors['fg_muted'], linewidth=0.8, linestyle='--', alpha=0.5)
            ax_pct.set_xticks(list(x))
            ax_pct.set_xticklabels(labels, rotation=30, ha='right', fontsize=8)
            ax_pct.set_ylabel('%')
            ax_pct.legend(fontsize=8)
            # Werte in Balken
            for i, (ep, sp) in enumerate(zip(expense_pcts, saving_pcts)):
                if ep > 5:
                    ax_pct.text(i - w/2, ep + 1, f'{ep:.0f}%', ha='center', fontsize=7, color=tc)
                if sp > 5:
                    ax_pct.text(i + w/2, sp + 1, f'{sp:.0f}%', ha='center', fontsize=7, color=tc)
            style_ax(ax_pct, "Ausgaben- vs. Sparquote (%)")
        self.fig_pct.tight_layout()
        self.canvas_pct.draw()

        # ---------- Chart 3: Sparquote-Verlauf ----------
        self.fig_sparquote.clear()
        ax_sq = self.fig_sparquote.add_subplot(111)
        if months_data:
            labels = [m[0] for m in months_data]
            sparquoten = []
            for month, data in months_data:
                inc = exp = 0
                for mc, subs in data.get('values', {}).items():
                    for sc, items in subs.items():
                        for item, val in items.items():
                            amt = ensure_float(val.get('amount', 0))
                            if "Einnahmen" in mc:
                                inc += amt
                            else:
                                exp += amt
                sq = ((inc - exp) / inc * 100) if inc > 0 else 0
                sparquoten.append(sq)

            x = list(range(len(labels)))
            # Farben nach positiv/negativ
            colors_sq = [self.colors['success'] if sq >= 0 else self.colors['danger']
                         for sq in sparquoten]
            bars = ax_sq.bar(x, sparquoten, color=colors_sq, alpha=0.85, width=0.6)
            ax_sq.plot(x, sparquoten, marker='o', color='#0078d4', linewidth=1.5, zorder=5)

            # Ziellinien
            ax_sq.axhline(0, color=self.colors['fg_muted'], linewidth=0.8)
            ax_sq.axhline(10, color='#ffa500', linewidth=1, linestyle=':', alpha=0.7,
                          label='Ziel 10%')
            ax_sq.axhline(20, color='#107c10', linewidth=1, linestyle=':', alpha=0.7,
                          label='Gut 20%')

            # Werte
            for i, sq in enumerate(sparquoten):
                ax_sq.text(i, sq + (1 if sq >= 0 else -3), f'{sq:.1f}%',
                           ha='center', fontsize=8, color=tc)

            ax_sq.set_xticks(x)
            ax_sq.set_xticklabels(labels, rotation=30, ha='right', fontsize=8)
            ax_sq.set_ylabel('Sparquote (%)')
            ax_sq.legend(fontsize=8)
            style_ax(ax_sq, "Sparquoten-Verlauf")
        self.fig_sparquote.tight_layout()
        self.canvas_sparquote.draw()

        # ---------- Chart 4: Top-Kategorien Verlauf ----------
        self.fig_topcat.clear()
        ax_tc = self.fig_topcat.add_subplot(111)
        if months_data:
            labels = [m[0] for m in months_data]
            # Sammle alle Ausgabe-Kategorien
            cat_series = {}
            for month, data in months_data:
                for mc, subs in data.get('values', {}).items():
                    if "Einnahmen" in mc:
                        continue
                    for sc, items in subs.items():
                        for item, val in items.items():
                            amt = ensure_float(val.get('amount', 0))
                            if amt > 0:
                                cat_key = mc
                                cat_series.setdefault(cat_key, [0] * len(months_data))

            # Befülle Serien
            for mi, (month, data) in enumerate(months_data):
                for mc, subs in data.get('values', {}).items():
                    if "Einnahmen" in mc:
                        continue
                    mc_sum = 0
                    for sc, items in subs.items():
                        for item, val in items.items():
                            mc_sum += ensure_float(val.get('amount', 0))
                    if mc in cat_series:
                        cat_series[mc][mi] = mc_sum

            # Top-5 Kategorien nach Gesamtsumme
            cat_totals = {k: sum(v) for k, v in cat_series.items()}
            top_cats = sorted(cat_totals, key=lambda k: cat_totals[k], reverse=True)[:5]

            colors_tc = ['#d13438', '#0078d4', '#107c10', '#ffa500', '#5c2d91']
            x = list(range(len(labels)))
            for ci, cat in enumerate(top_cats):
                vals = cat_series.get(cat, [0] * len(labels))
                ax_tc.plot(x, vals, marker='o', label=cat,
                           color=colors_tc[ci % len(colors_tc)], linewidth=2)

            ax_tc.set_xticks(x)
            ax_tc.set_xticklabels(labels, rotation=30, ha='right', fontsize=8)
            ax_tc.set_ylabel('€')
            ax_tc.legend(fontsize=8, loc='upper left')
            style_ax(ax_tc, "Top-Kategorien Verlauf")
        self.fig_topcat.tight_layout()
        self.canvas_topcat.draw()

        # ---------- Chart 5: Pie (Ausgaben-Verteilung aktueller Monat) ----------
        self.fig2.clear()
        ax2 = self.fig2.add_subplot(111)
        categories = {}
        for (mc, sc, item), refs in self.labels_by_item.items():
            if "Einnahmen" not in mc:
                amt = ensure_float(refs['amt'].get())
                if amt > 0:
                    categories[mc] = categories.get(mc, 0) + amt
        if categories:
            pie_colors = ['#0078d4', '#107c10', '#d13438', '#ffd700', '#ca5010', '#5c2d91']
            wedges, texts, autotexts = ax2.pie(
                list(categories.values()),
                labels=list(categories.keys()),
                autopct='%1.1f%%', startangle=90,
                colors=pie_colors[:len(categories)],
                pctdistance=0.8
            )
            for t in texts:
                t.set_color(tc)
                t.set_fontsize(8)
            for at in autotexts:
                at.set_fontsize(7)
            ax2.set_title("Aktuelle Ausgaben-Verteilung", color=tc, fontsize=10)
            ax2.axis('equal')
        ax2.set_facecolor(self.colors['bg'])
        self.fig2.tight_layout()
        self.canvas2.draw()

    def update_year_overview(self):
        try:
            year = int(self.year_select.get())
        except:
            messagebox.showerror("Fehler", "Ungültiges Jahr")
            return
        yearly_data = []
        for month in range(1, 13):
            month_str = f"{year}-{month:02d}"
            fname = filename_for_month(self.current_profile.get(), month_str)
            if os.path.exists(fname):
                try:
                    with open(fname, 'r', encoding='utf-8') as f:
                        data = json.load(f)
                    yearly_data.append((month_str, data))
                except Exception:
                    pass  # logged silently
        if not yearly_data:
            messagebox.showinfo("Info", f"Keine Daten für {year} gefunden")
            return
        total_income = total_expense = 0
        monthly_incomes, monthly_expenses, month_labels = [], [], []
        for month_str, data in yearly_data:
            income = expense = 0
            for mc, subs in data.get('values', {}).items():
                for sc, items in subs.items():
                    for item, val in items.items():
                        amt = ensure_float(val.get('amount', 0))
                        if "Einnahmen" in mc:
                            income += amt
                        else:
                            expense += amt
            total_income += income
            total_expense += expense
            monthly_incomes.append(income)
            monthly_expenses.append(expense)
            month_labels.append(month_str)
        balance = total_income - total_expense
        n = len(yearly_data)
        self.year_income_label.config(text=f"Jahreseinnahmen: {total_income:.2f} €")
        self.year_expense_label.config(text=f"Jahresausgaben: {total_expense:.2f} €")
        self.year_balance_label.config(text=f"Jahressaldo: {balance:.2f} €",
                                       fg=self.colors['success'] if balance >= 0 else self.colors['danger'])
        self.avg_income_label.config(text=f"Ø Einnahmen: {total_income / n:.2f} €")
        self.avg_expense_label.config(text=f"Ø Ausgaben: {total_expense / n:.2f} €")
        self.avg_balance_label.config(text=f"Ø Saldo: {balance / n:.2f} €")
        self.fig_year.clear()
        ax = self.fig_year.add_subplot(111)
        x = range(len(month_labels))
        w = 0.35
        ax.bar([i - w / 2 for i in x], monthly_incomes, w, label='Einnahmen', color='#107c10')
        ax.bar([i + w / 2 for i in x], monthly_expenses, w, label='Ausgaben', color='#d13438')
        ax.set_xlabel('Monat')
        ax.set_ylabel('Betrag (€)')
        ax.set_title(f'Jahresübersicht {year}')
        ax.set_xticks(x)
        ax.set_xticklabels(month_labels, rotation=45, ha='right')
        ax.legend()
        ax.grid(True, alpha=0.3, axis='y')
        tc = self.colors['fg']
        ax.tick_params(colors=tc)
        ax.title.set_color(tc)
        ax.yaxis.label.set_color(tc)
        ax.xaxis.label.set_color(tc)
        for spine in ax.spines.values():
            spine.set_color(tc)
        self.fig_year.tight_layout()
        self.canvas_year.draw()

    def update_trends(self):
        try:
            forecast_months = int(self.forecast_months.get())
        except:
            forecast_months = 3
        try:
            history_n = max(3, int(self.trend_history_months.get()))
        except:
            history_n = 6

        # Daten sammeln
        months_data = []
        current = self.current_month.get()
        for i in range(history_n):
            month = current
            for _ in range(i):
                month = get_previous_month(month)
                if not month:
                    break
            if not month:
                break
            fname = filename_for_month(self.current_profile.get(), month)
            if os.path.exists(fname):
                try:
                    with open(fname, 'r', encoding='utf-8') as f:
                        data = json.load(f)
                    months_data.append((month, data))
                except Exception:
                    pass  # logged silently
        if len(months_data) < 3:
            messagebox.showinfo("Info", "Mindestens 3 Monate Daten benötigt für Prognosen")
            return
        months_data.reverse()

        # Serien extrahieren
        incomes, expenses, labels = [], [], []
        for month, data in months_data:
            inc = exp = 0
            for mc, subs in data.get('values', {}).items():
                for sc, items_d in subs.items():
                    for item, val in items_d.items():
                        amt = ensure_float(val.get('amount', 0))
                        if "Einnahmen" in mc:
                            inc += amt
                        else:
                            exp += amt
            incomes.append(inc)
            expenses.append(exp)
            labels.append(month)

        n = len(incomes)
        x = np.arange(n)

        # Zukunfts-Labels
        future_labels = []
        nm = get_next_month(labels[-1])
        for _ in range(forecast_months):
            future_labels.append(nm)
            nm = get_next_month(nm)
        future_x = np.arange(n, n + forecast_months)
        all_x = np.concatenate([x, future_x])
        all_labels = labels + future_labels

        tc = self.colors['fg']

        def style_ax(ax, title=""):
            ax.set_facecolor(self.colors['bg'])
            ax.tick_params(colors=tc, labelsize=8)
            ax.yaxis.label.set_color(tc)
            ax.xaxis.label.set_color(tc)
            if title:
                ax.set_title(title, color=tc, fontsize=10)
            for spine in ax.spines.values():
                spine.set_color(self.colors['fg_muted'])
            ax.grid(True, alpha=0.2)

        # ─── Lineare Regression ───
        z_inc = np.polyfit(x, incomes, 1)
        p_inc = np.poly1d(z_inc)
        z_exp = np.polyfit(x, expenses, 1)
        p_exp = np.poly1d(z_exp)

        # ─── Gleitender Durchschnitt (3-Monats) ───
        win = min(3, n)
        def moving_avg(series, w):
            result = []
            for i in range(len(series)):
                start = max(0, i - w + 1)
                result.append(np.mean(series[start:i + 1]))
            return np.array(result)

        ma_inc = moving_avg(incomes, win)
        ma_exp = moving_avg(expenses, win)

        # Prognose via gleitendem Durchschnitt (letzter MA-Wert + Trend-Delta)
        trend_delta_inc = z_inc[0]  # monatliche Steigung
        trend_delta_exp = z_exp[0]
        ma_future_inc = np.array([ma_inc[-1] + trend_delta_inc * (i + 1) for i in range(forecast_months)])
        ma_future_exp = np.array([ma_exp[-1] + trend_delta_exp * (i + 1) for i in range(forecast_months)])

        # ─── Residuen / Streuung für Best/Worst Case ───
        residuals_inc = np.array(incomes) - p_inc(x)
        residuals_exp = np.array(expenses) - p_exp(x)
        std_inc = np.std(residuals_inc) if len(residuals_inc) > 1 else 0
        std_exp = np.std(residuals_exp) if len(residuals_exp) > 1 else 0

        # Prognose-Bänder: Basis = linearer Trend
        base_inc = p_inc(future_x)
        base_exp = p_exp(future_x)
        best_inc  = base_inc + 1.5 * std_inc   # optimistisch: mehr Einnahmen
        worst_inc = base_inc - 1.5 * std_inc   # pessimistisch: weniger Einnahmen
        best_exp  = base_exp - 1.5 * std_exp   # optimistisch: weniger Ausgaben
        worst_exp = base_exp + 1.5 * std_exp   # pessimistisch: mehr Ausgaben
        # Saldo-Szenarien
        best_balance  = best_inc - best_exp
        worst_balance = worst_inc - worst_exp
        base_balance  = base_inc - base_exp
        hist_balance  = np.array(incomes) - np.array(expenses)

        # ─── Saisonale Muster (Monat-zu-Monat, wenn genug Daten) ───
        month_indices = [int(lbl.split('-')[1]) for lbl in labels]
        seasonal_exp = {}
        for mi, exp_val in zip(month_indices, expenses):
            seasonal_exp.setdefault(mi, []).append(exp_val)
        seasonal_avg = {m: np.mean(v) for m, v in seasonal_exp.items()}

        # ════════ Chart 1: Hauptprognose ════════
        self.fig_trend.clear()
        ax = self.fig_trend.add_subplot(111)

        ax.plot(x, incomes, marker='o', label='Einnahmen (Ist)', color='#107c10', linewidth=2)
        ax.plot(x, expenses, marker='s', label='Ausgaben (Ist)', color='#d13438', linewidth=2)
        ax.plot(x, hist_balance, marker='^', label='Saldo (Ist)', color='#0078d4', linewidth=1.5, linestyle='--')

        # Trend-Linien (historisch)
        ax.plot(x, p_inc(x), '--', color='#107c10', alpha=0.4, linewidth=1)
        ax.plot(x, p_exp(x), '--', color='#d13438', alpha=0.4, linewidth=1)

        # Prognose
        ax.plot(future_x, base_inc, marker='o', label='Prognose Einnahmen',
                color='#107c10', linestyle=':', linewidth=2, markersize=7)
        ax.plot(future_x, base_exp, marker='s', label='Prognose Ausgaben',
                color='#d13438', linestyle=':', linewidth=2, markersize=7)
        ax.plot(future_x, base_balance, marker='^', label='Prognose Saldo',
                color='#0078d4', linestyle=':', linewidth=2, markersize=7)

        # Trennlinie Ist / Prognose
        ax.axvline(x=n - 0.5, color=self.colors['fg_muted'], linestyle='--', alpha=0.6, linewidth=1.5)
        ax.text(n - 0.45, ax.get_ylim()[0] if ax.get_ylim()[0] != 0 else 0,
                'Prognose ▶', color=self.colors['fg_muted'], fontsize=7, va='bottom')

        ax.set_xticks(list(all_x))
        ax.set_xticklabels(all_labels, rotation=35, ha='right', fontsize=7)
        ax.set_ylabel('€')
        ax.legend(fontsize=7, ncol=3)
        ax.axhline(0, color=self.colors['fg_muted'], linewidth=0.5)
        style_ax(ax, f"Prognose (lin. Trend, {win}-Monats-Basis)")
        self.fig_trend.tight_layout()
        self.canvas_trend.draw()

        # ════════ Chart 2: Best / Worst Case ════════
        self.fig_scenario.clear()
        ax2 = self.fig_scenario.add_subplot(111)

        # Historischer Saldo
        ax2.plot(x, hist_balance, marker='o', label='Saldo (Ist)', color='#0078d4', linewidth=2)

        # Szenarien als Flächen
        ax2.fill_between(future_x, worst_balance, best_balance,
                         color='#0078d4', alpha=0.15, label='Prognose-Band')
        ax2.plot(future_x, base_balance, marker='D', label='Basis (mittlere Prognose)',
                 color='#0078d4', linestyle='-', linewidth=2, markersize=7)
        ax2.plot(future_x, best_balance, marker='^', label='Best Case (+1.5σ)',
                 color='#107c10', linestyle=':', linewidth=1.8, markersize=6)
        ax2.plot(future_x, worst_balance, marker='v', label='Worst Case (-1.5σ)',
                 color='#d13438', linestyle=':', linewidth=1.8, markersize=6)

        # Werte annotieren
        for i, (b, w, ba) in enumerate(zip(best_balance, worst_balance, base_balance)):
            fi = future_x[i]
            ax2.annotate(f'+{b:.0f}€', (fi, b), textcoords="offset points",
                         xytext=(0, 6), ha='center', fontsize=7, color='#107c10')
            ax2.annotate(f'{w:.0f}€', (fi, w), textcoords="offset points",
                         xytext=(0, -12), ha='center', fontsize=7, color='#d13438')

        ax2.axvline(x=n - 0.5, color=self.colors['fg_muted'], linestyle='--', alpha=0.6)
        ax2.axhline(0, color=self.colors['fg_muted'], linewidth=0.8, alpha=0.5)
        ax2.set_xticks(list(all_x))
        ax2.set_xticklabels(all_labels, rotation=35, ha='right', fontsize=7)
        ax2.set_ylabel('Saldo (€)')
        ax2.legend(fontsize=7)
        style_ax(ax2, "Saldo-Szenarien: Best / Basis / Worst Case")
        self.fig_scenario.tight_layout()
        self.canvas_scenario.draw()

        # ════════ Chart 3: Saisonalität ════════
        self.fig_seasonal.clear()
        if len(months_data) >= 6 and len(seasonal_avg) >= 3:
            ax3 = self.fig_seasonal.add_subplot(111)
            months_list = sorted(seasonal_avg.keys())
            month_names = ['Jan','Feb','Mär','Apr','Mai','Jun',
                           'Jul','Aug','Sep','Okt','Nov','Dez']
            avg_vals = [seasonal_avg.get(m, 0) for m in months_list]
            labels3 = [month_names[m - 1] for m in months_list]
            overall_avg = np.mean(list(seasonal_avg.values()))

            colors3 = ['#d13438' if v > overall_avg else '#107c10' for v in avg_vals]
            bars = ax3.bar(range(len(months_list)), avg_vals, color=colors3, alpha=0.8, width=0.6)
            ax3.axhline(overall_avg, color='#ffa500', linestyle='--', linewidth=1.5,
                        label=f'Ø {overall_avg:.0f} €')

            for i, (b, v) in enumerate(zip(bars, avg_vals)):
                ax3.text(i, v + overall_avg * 0.02, f'{v:.0f}€',
                         ha='center', fontsize=7, color=tc)

            ax3.set_xticks(range(len(months_list)))
            ax3.set_xticklabels(labels3, fontsize=8)
            ax3.set_ylabel('Ø Ausgaben (€)')
            ax3.legend(fontsize=8)
            style_ax(ax3, "Saisonale Ausgaben-Muster (Ø pro Monat)")

            # Teuer/Günstig hervorheben
            if avg_vals:
                max_m = months_list[avg_vals.index(max(avg_vals))]
                min_m = months_list[avg_vals.index(min(avg_vals))]
                ax3.text(0.02, 0.96,
                         f"📈 Teuerster Monat: {month_names[max_m-1]}  |  "
                         f"💚 Günstigster Monat: {month_names[min_m-1]}",
                         transform=ax3.transAxes, fontsize=8, color=tc,
                         verticalalignment='top',
                         bbox=dict(boxstyle='round', facecolor=self.colors['bg_tertiary'], alpha=0.8))
        else:
            ax3 = self.fig_seasonal.add_subplot(111)
            ax3.text(0.5, 0.5,
                     "Mindestens 6 Monate Daten\nfür Saisonalitäts-Analyse benötigt.",
                     ha='center', va='center', transform=ax3.transAxes,
                     color=self.colors['fg_muted'], fontsize=11)
            ax3.set_facecolor(self.colors['bg'])
            ax3.axis('off')
        self.fig_seasonal.tight_layout()
        self.canvas_seasonal.draw()

        # ════════ Chart 4: Gleitender Durchschnitt ════════
        self.fig_moving.clear()
        ax4 = self.fig_moving.add_subplot(111)

        ax4.bar(x, expenses, color='#d13438', alpha=0.3, width=0.6, label='Ausgaben (Ist)')
        ax4.plot(x, ma_exp, marker='o', color='#d13438', linewidth=2.5,
                 label=f'{win}-Monats gleit. Ø (Ausgaben)', zorder=5)
        ax4.bar(x, incomes, color='#107c10', alpha=0.15, width=0.6, label='Einnahmen (Ist)')
        ax4.plot(x, ma_inc, marker='s', color='#107c10', linewidth=2.5,
                 label=f'{win}-Monats gleit. Ø (Einnahmen)', zorder=5)

        # MA Prognose
        ax4.plot(future_x, ma_future_exp, marker='o', color='#d13438', linestyle=':',
                 linewidth=2, markersize=7, label='MA-Prognose Ausgaben')
        ax4.plot(future_x, ma_future_inc, marker='s', color='#107c10', linestyle=':',
                 linewidth=2, markersize=7, label='MA-Prognose Einnahmen')

        ax4.axvline(x=n - 0.5, color=self.colors['fg_muted'], linestyle='--', alpha=0.6)
        ax4.set_xticks(list(all_x))
        ax4.set_xticklabels(all_labels, rotation=35, ha='right', fontsize=7)
        ax4.set_ylabel('€')
        ax4.legend(fontsize=7, ncol=2)
        style_ax(ax4, f"Gleitender {win}-Monats-Durchschnitt + MA-Prognose")
        self.fig_moving.tight_layout()
        self.canvas_moving.draw()

    def on_save_click(self):
        ym = month_key_from_selection(self.current_month.get())
        if not validate_month_format(ym):
            messagebox.showerror("Ungültiges Format", "Bitte Format YYYY-MM verwenden (z.B. 2025-01)")
            return
        self._set_status("💾 Speichere…", self.colors['accent'])
        # Werte aus UI in Model übertragen
        self.model.values = {}
        for (mc, sc, item), varsd in self.labels_by_item.items():
            self.model.values[(mc, sc, item)] = {
                'amount': varsd["amt"].get().strip(),
                'note': varsd["note"].get().strip()
            }
        ok, err = self.model.save_month(self.current_profile.get(), ym)
        if ok:
            self.model.save_settings()
            self._mark_saved(ym)
        else:
            self._set_status(f"❌ Fehler beim Speichern", self.colors['danger'])
            messagebox.showerror("Fehler beim Speichern", str(err))

    def on_load_click(self):
        ym = self.current_month.get()
        if not validate_month_format(ym):
            messagebox.showerror("Ungültiges Format", "Bitte Format YYYY-MM verwenden (z.B. 2025-01)")
            return
        self.load_month(ym)

    def load_month(self, ym):
        fname = filename_for_month(self.current_profile.get(), ym)
        if not os.path.exists(fname):
            for refs in self.labels_by_item.values():
                refs["amt"].set("0")
                refs["note"].set("")
            self.undo_redo.clear()
            self._push_undo_state()
            self.recalculate_all()
            return

        ok, err = self.model.load_month(self.current_profile.get(), ym)
        if not ok:
            messagebox.showerror("Fehler beim Laden", str(err))
            return

        self.build_categories_ui()

        for (mc, sc, item), refs in self.labels_by_item.items():
            v = self.model.values.get((mc, sc, item), {})
            refs["amt"].set(v.get("amount", "0"))
            refs["note"].set(v.get("note", ""))

        self.undo_redo.clear()
        self._push_undo_state()
        self.recalculate_all()

    def on_amount_change(self, key):
        self._push_undo_state()
        self._mark_unsaved()
        self.recalculate_all()

    def recalculate_all(self):
        # Aktuelle UI-Werte ins Model schreiben
        self.model.values = {}
        for (mc, sc, item), refs in self.labels_by_item.items():
            self.model.values[(mc, sc, item)] = {
                'amount': refs['amt'].get(),
                'note': refs['note'].get()
            }

        totals = self.model.get_totals()
        total_income = totals['income']
        total_expense = totals['expense']
        fixed_total = totals['fixed']
        variable_total = totals['variable']
        balance = totals['balance']
        per_main = totals['per_main']

        self.income_label.config(text=f"{total_income:.2f} €")
        self.expense_label.config(text=f"{total_expense:.2f} €")
        bal_color = self.colors['success'] if balance >= 0 else self.colors['danger']
        self.balance_label.config(text=f"{balance:.2f} €", fg=bal_color)

        saving_rate = (balance / total_income * 100.0) if total_income > 0 else 0.0
        self.saving_rate_label.config(text=f"📈 Sparquote: {saving_rate:.1f} %")
        self.fixed_var_label.config(text=f"🔒 Fixkosten: {fixed_total:.2f} €")
        self.variable_var_label.config(text=f"🔄 Variable Kosten: {variable_total:.2f} €")

        # ---- Intelligente Budget-Warnungen (5 Stufen) ----
        WARNING_COLORS = {
            'ok':       ('#107c10', '✅'),   # grün  < 80%
            'warn':     ('#ffa500', '⚠️'),   # orange 80-99%
            'over':     ('#d13438', '🔴'),   # rot   100-119%
            'critical': ('#8b0000', '🚨'),   # dunkelrot >=120%
        }

        for mc, lbl in self.totals_per_category.items():
            mc_sum = per_main.get(mc, 0.0)
            level, pct = self.model.get_budget_warning_level(mc, mc_sum)
            limit = self.model.budget_warnings.get(mc)

            if level is None:
                # Kein Limit gesetzt
                lbl.config(text=f"Summe: {mc_sum:.2f} €", fg=self.colors['warning'])
            else:
                color, icon = WARNING_COLORS.get(level, (self.colors['warning'], ''))
                if level == 'ok':
                    lbl.config(text=f"✅ {mc_sum:.2f} € / {limit:.0f} € ({pct:.0f}%)",
                               fg=color)
                else:
                    lbl.config(text=f"{icon} {mc_sum:.2f} € / {limit:.0f} € ({pct:.0f}%)",
                               fg=color)

            # Warn-Label neben Kategorie-Titel aktualisieren
            warn_lbl = self._budget_warn_labels.get(mc)
            if warn_lbl and limit:
                if level == 'ok':
                    warn_lbl.config(text=f"Limit: {limit:.0f} € ✅", fg=self.colors['success'])
                elif level == 'warn':
                    warn_lbl.config(text=f"⚠️ {pct:.0f}% von {limit:.0f} €", fg='#ffa500')
                elif level == 'over':
                    warn_lbl.config(text=f"🔴 ÜBERSCHRITTEN! {pct:.0f}%", fg=self.colors['danger'])
                elif level == 'critical':
                    warn_lbl.config(text=f"🚨 KRITISCH! {pct:.0f}%", fg='#8b0000')

            # Kategorie-Frame-Hintergrund einfärben bei Überschreitung
            # (via Rahmen-Farbe)
            mc_frame_widgets = self.totals_per_category.get(mc)

        # ---- Top-3 ----
        top3 = self.model.get_top3_expenses()
        for i in range(3):
            if i < len(top3):
                name, amt = top3[i]
                self.top3_boxes[i].config(text=f"{i + 1}. {name}: {amt:.2f} €")
            else:
                self.top3_boxes[i].config(text=f"{i + 1}. -")

        # ---- Sparziel-Vorschau aktualisieren ----
        self._update_goal_preview()

        # ---- Goals Tab Balance-Info aktualisieren ----
        if hasattr(self, 'goals_balance_info'):
            color = self.colors['success'] if balance >= 0 else self.colors['danger']
            self.goals_balance_info.config(
                text=f"Verfügbarer Saldo: {balance:.2f} €", fg=color)

        # ---- Dashboard aktualisieren ----
        if hasattr(self, '_dashboard_cards'):
            self._update_dashboard_cards(totals)

    def export_csv(self):
        file = filedialog.asksaveasfilename(
            defaultextension=".csv",
            filetypes=[("CSV Dateien", "*.csv")],
            initialfile=f"budget_{self.current_month.get()}.csv"
        )
        if not file:
            return
        try:
            with open(file, "w", newline="", encoding="utf-8") as f:
                writer = csv.writer(f, delimiter=';')
                writer.writerow(["Hauptkategorie", "Unterkategorie", "Posten", "Betrag", "Notiz"])
                for (mc, sc, item), refs in self.labels_by_item.items():
                    writer.writerow([mc, sc, item, refs["amt"].get().replace('.', ','), refs["note"].get()])
            messagebox.showinfo("✅ Export", "CSV erfolgreich exportiert!")
        except Exception as e:
            messagebox.showerror("Fehler beim CSV Export", str(e))

    def export_pdf(self):
        try:
            from reportlab.lib.pagesizes import A4
            from reportlab.pdfgen import canvas
            from reportlab.lib.units import cm

            file = filedialog.asksaveasfilename(
                defaultextension=".pdf",
                filetypes=[("PDF Dateien", "*.pdf")],
                initialfile=f"budget_{self.current_month.get()}.pdf"
            )
            if not file:
                return

            c = canvas.Canvas(file, pagesize=A4)
            width, height = A4
            c.setFont("Helvetica-Bold", 20)
            c.drawString(2 * cm, height - 2 * cm, f"Budget-Report {self.current_month.get()}")
            y = height - 4 * cm
            c.setFont("Helvetica", 12)
            totals = self.model.get_totals()
            c.drawString(2 * cm, y, f"Einnahmen: {totals['income']:.2f} EUR")
            y -= 0.7 * cm
            c.drawString(2 * cm, y, f"Ausgaben: {totals['expense']:.2f} EUR")
            y -= 0.7 * cm
            c.drawString(2 * cm, y, f"Saldo: {totals['balance']:.2f} EUR")
            y -= 1.5 * cm
            c.setFont("Helvetica-Bold", 14)
            c.drawString(2 * cm, y, "Details:")
            y -= 1 * cm
            c.setFont("Helvetica", 10)
            for (mc, sc, item), refs in self.labels_by_item.items():
                amt = refs["amt"].get()
                if ensure_float(amt) > 0:
                    if y < 2 * cm:
                        c.showPage()
                        y = height - 2 * cm
                    c.drawString(2 * cm, y, f"{mc} > {sc} > {item}: {amt} EUR")
                    y -= 0.5 * cm
            c.save()
            messagebox.showinfo("✅ Export", "PDF erfolgreich exportiert!")
        except ImportError:
            messagebox.showerror("Fehler", "reportlab nicht installiert.\nInstalliere mit: pip install reportlab")
        except Exception as e:
            messagebox.showerror("Fehler beim PDF Export", str(e))

    # ══════════════════════════════════════════════════
    # Feature 15: Dashboard (Banking-App Feeling)
    # ══════════════════════════════════════════════════
    def build_dashboard_tab(self):
        """Großes visuelles Dashboard mit Cards und Charts."""
        self._dashboard_cards = {}

        # Scrollbarer Haupt-Canvas
        outer = tk.Frame(self.dashboard_tab, bg=self.colors['bg'])
        outer.pack(fill="both", expand=True)

        dash_canvas = tk.Canvas(outer, bg=self.colors['bg'], highlightthickness=0)
        dash_scroll = ttk.Scrollbar(outer, orient="vertical", command=dash_canvas.yview)
        self._dash_inner = tk.Frame(dash_canvas, bg=self.colors['bg'])
        self._dash_inner.bind("<Configure>",
            lambda e: dash_canvas.configure(scrollregion=dash_canvas.bbox("all")))
        dash_canvas.create_window((0, 0), window=self._dash_inner, anchor="nw")
        dash_canvas.configure(yscrollcommand=dash_scroll.set)
        dash_canvas.pack(side="left", fill="both", expand=True)
        dash_scroll.pack(side="right", fill="y")
        dash_canvas.bind_all("<MouseWheel>",
            lambda e: dash_canvas.yview_scroll(int(-1*(e.delta/120)), "units"))

        self._build_dashboard_content()

    def _build_dashboard_content(self):
        """Baut den Dashboard-Inhalt auf."""
        for w in self._dash_inner.winfo_children():
            w.destroy()

        totals = self.model.get_totals()
        c = self.colors

        # ── Zeile 1: Monat + Aktualisieren Button ──
        hdr = tk.Frame(self._dash_inner, bg=c['bg_tertiary'])
        hdr.pack(fill="x", padx=0, pady=0)
        tk.Label(hdr, text=f"🏦 Dashboard  –  {self.current_month.get()}",
                 bg=c['bg_tertiary'], fg=c['fg'],
                 font=("Segoe UI", 16, "bold")).pack(side="left", padx=20, pady=12)
        self.create_button(hdr, "🔄 Aktualisieren", self.update_dashboard,
                           c['accent']).pack(side="left", padx=10)

        # ── Zeile 2: Große KPI-Cards (4 Stück) ──
        cards_row = tk.Frame(self._dash_inner, bg=c['bg'])
        cards_row.pack(fill="x", padx=15, pady=12)

        kpi_defs = [
            ("💰 Einnahmen",  f"{totals['income']:.2f} €",    c['success'],  "dash_income"),
            ("💸 Ausgaben",   f"{totals['expense']:.2f} €",   c['danger'],   "dash_expense"),
            ("💵 Saldo",      f"{totals['balance']:.2f} €",
             c['success'] if totals['balance'] >= 0 else c['danger'],         "dash_balance"),
            ("📈 Sparquote",
             f"{(totals['balance']/totals['income']*100):.1f}%" if totals['income'] > 0 else "0.0 %",
             c['accent'],  "dash_sparquote"),
        ]
        for i, (title, value, color, attr) in enumerate(kpi_defs):
            card = tk.Frame(cards_row, bg=c['bg_secondary'], relief="flat",
                            borderwidth=0, padx=20, pady=18)
            card.grid(row=0, column=i, padx=8, sticky="nsew")
            cards_row.columnconfigure(i, weight=1)

            tk.Label(card, text=title, bg=c['bg_secondary'], fg=c['fg_muted'],
                     font=("Segoe UI", 10)).pack(anchor="w")
            val_lbl = tk.Label(card, text=value, bg=c['bg_secondary'], fg=color,
                               font=("Segoe UI", 22, "bold"))
            val_lbl.pack(anchor="w", pady=(6, 0))
            self._dashboard_cards[attr] = val_lbl

        # ── Zeile 3: Fortschrittsbalken Budget-Limits ──
        limits_frame = tk.Frame(self._dash_inner, bg=c['bg_secondary'])
        limits_frame.pack(fill="x", padx=15, pady=(0, 10))
        tk.Label(limits_frame, text="⚠️ Budget-Limits", bg=c['bg_secondary'],
                 fg=c['fg'], font=("Segoe UI", 12, "bold")).pack(anchor="w", padx=15, pady=(10, 6))

        per_main = totals['per_main']
        has_limits = False
        for mc, limit in self.model.budget_warnings.items():
            has_limits = True
            current = per_main.get(mc, 0.0)
            pct = min(current / limit * 100, 100) if limit > 0 else 0
            level, _ = self.model.get_budget_warning_level(mc, current)
            bar_color = {'ok': c['success'], 'warn': '#ffa500',
                         'over': c['danger'], 'critical': '#8b0000'}.get(level, c['accent'])

            row = tk.Frame(limits_frame, bg=c['bg_secondary'])
            row.pack(fill="x", padx=15, pady=4)

            tk.Label(row, text=mc, bg=c['bg_secondary'], fg=c['fg'],
                     font=("Segoe UI", 10), width=18, anchor="w").pack(side="left")

            bar_bg = tk.Canvas(row, height=20, bg=c['bg_tertiary'],
                               highlightthickness=0, width=300)
            bar_bg.pack(side="left", padx=8)

            def draw_bar(ev=None, bc=bar_color, p=pct, bg_widget=bar_bg,
                         cur=current, lim=limit):
                bg_widget.delete("all")
                w = bg_widget.winfo_width() or 300
                filled = int(w * p / 100)
                bg_widget.create_rectangle(0, 0, w, 20, fill=c['bg_tertiary'], outline="")
                if filled > 0:
                    bg_widget.create_rectangle(0, 0, filled, 20, fill=bc, outline="")
                bg_widget.create_text(w//2, 10,
                                      text=f"{cur:.0f} / {lim:.0f} € ({p:.0f}%)",
                                      fill="white", font=("Segoe UI", 8, "bold"))

            bar_bg.bind("<Configure>", draw_bar)
            bar_bg.after(80, draw_bar)

        if not has_limits:
            tk.Label(limits_frame,
                     text="Keine Budget-Limits definiert. Klicke auf ⚙️ Budget-Limits.",
                     bg=c['bg_secondary'], fg=c['fg_muted'],
                     font=("Segoe UI", 9, "italic")).pack(padx=15, pady=8)

        # ── Zeile 4: Charts nebeneinander ──
        charts_row = tk.Frame(self._dash_inner, bg=c['bg'])
        charts_row.pack(fill="both", expand=True, padx=15, pady=10)

        # Mini Pie Chart
        pie_frame = tk.Frame(charts_row, bg=c['bg_secondary'])
        pie_frame.pack(side="left", fill="both", expand=True, padx=(0, 8))
        tk.Label(pie_frame, text="🥧 Ausgaben-Verteilung", bg=c['bg_secondary'],
                 fg=c['fg'], font=("Segoe UI", 11, "bold")).pack(pady=(10, 5))

        fig_dash_pie = Figure(figsize=(4, 3), facecolor=c['bg_secondary'])
        ax_pie = fig_dash_pie.add_subplot(111)
        categories = {}
        for (mc, sc, item), refs in self.labels_by_item.items():
            if "Einnahmen" not in mc:
                amt = ensure_float(refs['amt'].get())
                if amt > 0:
                    categories[mc] = categories.get(mc, 0) + amt
        if categories:
            pie_colors = ['#0078d4','#107c10','#d13438','#ffd700','#ca5010','#5c2d91']
            ax_pie.pie(list(categories.values()), labels=list(categories.keys()),
                       autopct='%1.0f%%', startangle=90,
                       colors=pie_colors[:len(categories)], pctdistance=0.75)
            ax_pie.axis('equal')
        else:
            ax_pie.text(0.5, 0.5, "Keine Daten", ha='center', va='center',
                        transform=ax_pie.transAxes, color=c['fg_muted'])
        ax_pie.set_facecolor(c['bg_secondary'])
        fig_dash_pie.patch.set_facecolor(c['bg_secondary'])
        fig_dash_pie.tight_layout(pad=0.5)
        FigureCanvasTkAgg(fig_dash_pie, pie_frame).get_tk_widget().pack(fill="both", expand=True)

        # Top-Ausgaben Balken
        top_frame = tk.Frame(charts_row, bg=c['bg_secondary'])
        top_frame.pack(side="left", fill="both", expand=True, padx=(0, 8))
        tk.Label(top_frame, text="🔝 Top-Ausgaben (Posten)", bg=c['bg_secondary'],
                 fg=c['fg'], font=("Segoe UI", 11, "bold")).pack(pady=(10, 5))

        per_item = totals['per_item']
        top_items = sorted(
            [(f"{it}", amt) for (mc, sc, it), amt in per_item.items()
             if "Einnahmen" not in mc and amt > 0],
            key=lambda x: x[1], reverse=True
        )[:8]

        fig_top = Figure(figsize=(4, 3), facecolor=c['bg_secondary'])
        ax_top = fig_top.add_subplot(111)
        if top_items:
            names = [t[0][:14] for t in top_items]
            vals = [t[1] for t in top_items]
            bars = ax_top.barh(range(len(names)), vals, color='#0078d4', alpha=0.85)
            ax_top.set_yticks(range(len(names)))
            ax_top.set_yticklabels(names, fontsize=7)
            ax_top.set_xlabel('€', color=c['fg'], fontsize=8)
            ax_top.tick_params(colors=c['fg'], labelsize=7)
            ax_top.set_facecolor(c['bg_secondary'])
            for spine in ax_top.spines.values():
                spine.set_color(c['fg_muted'])
            for i, (b, v) in enumerate(zip(bars, vals)):
                ax_top.text(v + max(vals)*0.01, i, f'{v:.0f}€',
                            va='center', fontsize=6, color=c['fg'])
        fig_top.patch.set_facecolor(c['bg_secondary'])
        fig_top.tight_layout(pad=0.5)
        FigureCanvasTkAgg(fig_top, top_frame).get_tk_widget().pack(fill="both", expand=True)

        # Spar-Gauge
        gauge_frame = tk.Frame(charts_row, bg=c['bg_secondary'], width=220)
        gauge_frame.pack(side="left", fill="y", padx=(0, 0))
        gauge_frame.pack_propagate(False)
        tk.Label(gauge_frame, text="💚 Finanz-Score", bg=c['bg_secondary'],
                 fg=c['fg'], font=("Segoe UI", 11, "bold")).pack(pady=(10, 5))

        # Einfacher Score (0–100) basierend auf Sparquote, Limitstatus
        sq = (totals['balance']/totals['income']*100) if totals['income'] > 0 else 0
        over_limits = sum(1 for mc, lim in self.model.budget_warnings.items()
                          if per_main.get(mc, 0) > lim)
        score = max(0, min(100, int(sq * 3) - over_limits * 10))

        score_color = c['success'] if score >= 70 else c['warning'] if score >= 40 else c['danger']
        tk.Label(gauge_frame, text=f"{score}", bg=c['bg_secondary'],
                 fg=score_color, font=("Segoe UI", 48, "bold")).pack(pady=10)
        tk.Label(gauge_frame, text="/ 100", bg=c['bg_secondary'],
                 fg=c['fg_muted'], font=("Segoe UI", 12)).pack()

        rating = "Ausgezeichnet 🌟" if score >= 80 else \
                 "Gut 👍" if score >= 60 else \
                 "Okay 🙂" if score >= 40 else \
                 "Verbesserungsbedarf ⚠️"
        tk.Label(gauge_frame, text=rating, bg=c['bg_secondary'],
                 fg=score_color, font=("Segoe UI", 10, "bold")).pack()

        # Sparziele Mini-Status
        tk.Label(gauge_frame, text="─" * 22, bg=c['bg_secondary'],
                 fg=c['fg_muted']).pack(pady=5)
        tk.Label(gauge_frame, text=f"🎯 {len(self.model.savings_goals)} Sparziel(e)",
                 bg=c['bg_secondary'], fg=c['fg'], font=("Segoe UI", 9)).pack()
        done = sum(1 for g in self.model.savings_goals
                   if float(g.get('saved',0)) >= float(g.get('target',1)))
        tk.Label(gauge_frame, text=f"✅ {done} erreicht",
                 bg=c['bg_secondary'], fg=c['success'], font=("Segoe UI", 9)).pack()

    def update_dashboard(self):
        """Dashboard komplett neu aufbauen."""
        if hasattr(self, '_dash_inner'):
            self._build_dashboard_content()

    def _update_dashboard_cards(self, totals):
        """Nur die KPI-Karten-Werte aktualisieren (schnell)."""
        if not hasattr(self, '_dashboard_cards'):
            return
        c = self.colors
        cards = self._dashboard_cards
        if 'dash_income' in cards:
            cards['dash_income'].config(text=f"{totals['income']:.2f} €")
        if 'dash_expense' in cards:
            cards['dash_expense'].config(text=f"{totals['expense']:.2f} €")
        if 'dash_balance' in cards:
            bal = totals['balance']
            cards['dash_balance'].config(
                text=f"{bal:.2f} €",
                fg=c['success'] if bal >= 0 else c['danger'])
        if 'dash_sparquote' in cards:
            sq = (totals['balance']/totals['income']*100) if totals['income'] > 0 else 0
            cards['dash_sparquote'].config(text=f"{sq:.1f}%")

    # ══════════════════════════════════════════════════
    # Feature 13: KI-Analyse (Ausgaben-Analyse + Spartipps)
    # ══════════════════════════════════════════════════
    def build_ki_tab(self):
        """KI-Analyse Tab: Muster erkennen + Spartipps generieren."""
        hdr = tk.Frame(self.ki_tab, bg=self.colors['bg_tertiary'])
        hdr.pack(fill="x")
        tk.Label(hdr, text="🤖 KI-Ausgaben-Analyse", bg=self.colors['bg_tertiary'],
                 fg=self.colors['fg'], font=("Segoe UI", 14, "bold")).pack(side="left", padx=20, pady=12)
        self.create_button(hdr, "🔍 Jetzt analysieren", self.run_ki_analysis,
                           self.colors['accent']).pack(side="left", padx=10)
        self.create_button(hdr, "💡 Spartipps", self.show_spartipps,
                           "#5c2d91").pack(side="left", padx=10)

        # Ergebnis-Bereich
        ki_outer = tk.Frame(self.ki_tab, bg=self.colors['bg'])
        ki_outer.pack(fill="both", expand=True, padx=15, pady=10)

        # Linke Spalte: Textuelles Analyse-Ergebnis
        left_ki = tk.Frame(ki_outer, bg=self.colors['bg_secondary'])
        left_ki.pack(side="left", fill="both", expand=True, padx=(0, 8))

        tk.Label(left_ki, text="📋 Analyse-Ergebnisse", bg=self.colors['bg_secondary'],
                 fg=self.colors['fg'], font=("Segoe UI", 11, "bold")).pack(anchor="w", padx=12, pady=(10, 5))

        self.ki_text = tk.Text(left_ki, bg=self.colors['bg_input'], fg=self.colors['fg'],
                               font=("Segoe UI", 10), relief="flat", padx=12, pady=8,
                               wrap="word", state="disabled")
        ki_scroll = ttk.Scrollbar(left_ki, orient="vertical", command=self.ki_text.yview)
        self.ki_text.configure(yscrollcommand=ki_scroll.set)
        self.ki_text.pack(side="left", fill="both", expand=True, padx=(12, 0), pady=(0, 12))
        ki_scroll.pack(side="right", fill="y", pady=(0, 12))

        # Rechte Spalte: Vergleichs-Chart
        right_ki = tk.Frame(ki_outer, bg=self.colors['bg_secondary'], width=360)
        right_ki.pack(side="right", fill="y")
        right_ki.pack_propagate(False)

        tk.Label(right_ki, text="📊 Monatsvergleich", bg=self.colors['bg_secondary'],
                 fg=self.colors['fg'], font=("Segoe UI", 11, "bold")).pack(pady=(10, 5))

        self.fig_ki = Figure(figsize=(3.5, 5), facecolor=self.colors['bg_secondary'])
        ki_chart = FigureCanvasTkAgg(self.fig_ki, right_ki)
        ki_chart.get_tk_widget().pack(fill="both", expand=True, padx=10, pady=10)
        self.ki_canvas = ki_chart

        # Initialer Hinweis
        self._ki_set_text("Klicke auf '🔍 Jetzt analysieren' um eine Analyse zu starten.\n\n"
                          "Die KI analysiert:\n"
                          "  • Ausgaben-Veränderungen zum Vormonat\n"
                          "  • Überdurchschnittliche Kategorien\n"
                          "  • Auffällige Muster\n"
                          "  • Budget-Limit-Verstöße\n"
                          "  • Sparquoten-Trend\n")

    def _ki_set_text(self, text):
        """Setzt den Text im KI-Analyse-Bereich."""
        self.ki_text.config(state="normal")
        self.ki_text.delete("1.0", "end")
        self.ki_text.insert("end", text)
        self.ki_text.config(state="disabled")

    def run_ki_analysis(self):
        """Führt die regelbasierte KI-Analyse durch."""
        current = self.current_month.get()
        prev = get_previous_month(current)
        prev2 = get_previous_month(prev) if prev else None

        # Aktuelle Daten
        totals = self.model.get_totals()
        per_main = totals['per_main']
        per_item = totals['per_item']

        # Vormonat laden
        prev_data = {}
        prev_per_main = {}
        if prev:
            fname = filename_for_month(self.current_profile.get(), prev)
            if os.path.exists(fname):
                try:
                    with open(fname, 'r', encoding='utf-8') as f:
                        pd_raw = json.load(f)
                    for mc, subs in pd_raw.get('values', {}).items():
                        for sc, items_d in subs.items():
                            for item, val in items_d.items():
                                amt = ensure_float(val.get('amount', 0))
                                prev_per_main[mc] = prev_per_main.get(mc, 0) + amt
                                prev_data[(mc, sc, item)] = amt
                except Exception:
                    pass  # logged silently

        findings = []
        findings.append(f"🔍 ANALYSE FÜR {current}\n{'─'*40}\n")

        # ── Einnahmen / Ausgaben Überblick ──
        inc = totals['income']
        exp = totals['expense']
        bal = totals['balance']
        sq = (bal / inc * 100) if inc > 0 else 0

        findings.append(f"💰 Einnahmen:  {inc:>10.2f} €")
        findings.append(f"💸 Ausgaben:   {exp:>10.2f} €")
        findings.append(f"💵 Saldo:      {bal:>10.2f} €")
        findings.append(f"📈 Sparquote:  {sq:>9.1f} %\n")

        if sq >= 20:
            findings.append("✅ Sehr gute Sparquote! Du sparst über 20% deines Einkommens.\n")
        elif sq >= 10:
            findings.append("👍 Solide Sparquote. Ziel: 20% oder mehr.\n")
        elif sq >= 0:
            findings.append("⚠️ Sparquote unter 10%. Prüfe deine variablen Ausgaben.\n")
        else:
            findings.append("🚨 Negativer Saldo! Du gibst mehr aus als du einnimmst.\n")

        # ── Vergleich mit Vormonat ──
        if prev_per_main:
            findings.append(f"\n📊 VERGLEICH MIT {prev}\n{'─'*40}")
            for mc, current_amt in per_main.items():
                if mc in prev_per_main and "Einnahmen" not in mc:
                    prev_amt = prev_per_main[mc]
                    if prev_amt > 0:
                        change = current_amt - prev_amt
                        pct_change = (change / prev_amt) * 100
                        icon = "🔺" if pct_change > 15 else "🔻" if pct_change < -15 else "➡️"
                        findings.append(
                            f"  {icon} {mc}: {current_amt:.2f} € "
                            f"({pct_change:+.1f}% vs. Vormonat)"
                        )
                        if pct_change > 30:
                            findings.append(
                                f"     ⚠️ Du gibst {pct_change:.0f}% mehr für {mc} aus "
                                f"als letzten Monat! (+{change:.2f} €)"
                            )
                        elif pct_change < -20:
                            findings.append(
                                f"     ✅ Sehr gut! Du hast {abs(pct_change):.0f}% "
                                f"bei {mc} gespart ({change:.2f} €)."
                            )

        # ── Budget-Limit-Verstöße ──
        limit_violations = []
        for mc, limit in self.model.budget_warnings.items():
            amt = per_main.get(mc, 0)
            level, pct = self.model.get_budget_warning_level(mc, amt)
            if level in ('over', 'critical'):
                limit_violations.append((mc, amt, limit, pct, level))

        if limit_violations:
            findings.append(f"\n🚨 BUDGET-LIMIT-VERSTÖSSE\n{'─'*40}")
            for mc, amt, limit, pct, level in limit_violations:
                icon = "🚨" if level == 'critical' else "🔴"
                findings.append(
                    f"  {icon} {mc}: {amt:.2f} € / {limit:.2f} € Limit ({pct:.0f}%)"
                )

        # ── Ungewöhnlich hohe Einzelposten ──
        if per_item:
            all_amounts = [v for v in per_item.values() if v > 0]
            if all_amounts:
                avg_item = np.mean(all_amounts)
                std_item = np.std(all_amounts)
                outliers = [(k, v) for k, v in per_item.items()
                            if v > avg_item + 2 * std_item and v > 50]
                if outliers:
                    findings.append(f"\n📍 AUFFÄLLIGE POSTEN (> Ø + 2σ)\n{'─'*40}")
                    for (mc, sc, item), amt in sorted(outliers, key=lambda x: x[1], reverse=True):
                        findings.append(f"  • {item} ({sc}): {amt:.2f} €")

        # ── Top-3 Kostentreiber ──
        expense_items = [(it, amt) for (mc, sc, it), amt in per_item.items()
                         if "Einnahmen" not in mc and amt > 0]
        top3 = sorted(expense_items, key=lambda x: x[1], reverse=True)[:3]
        if top3:
            findings.append(f"\n🏆 TOP-3 KOSTENTREIBER\n{'─'*40}")
            for i, (item, amt) in enumerate(top3, 1):
                pct_of_exp = (amt / exp * 100) if exp > 0 else 0
                findings.append(f"  {i}. {item}: {amt:.2f} € ({pct_of_exp:.1f}% der Ausgaben)")

        self._ki_set_text("\n".join(findings))

        # ── KI Chart: Kategorien-Vergleich ──
        self.fig_ki.clear()
        if prev_per_main and per_main:
            ax = self.fig_ki.add_subplot(111)
            cats = [mc for mc in per_main if "Einnahmen" not in mc and mc in prev_per_main]
            if cats:
                x = range(len(cats))
                cur_vals = [per_main.get(c, 0) for c in cats]
                prev_vals = [prev_per_main.get(c, 0) for c in cats]
                w = 0.38
                ax.barh([i + w/2 for i in x], cur_vals, w,
                        label=current, color='#0078d4', alpha=0.85)
                ax.barh([i - w/2 for i in x], prev_vals, w,
                        label=prev, color='#5c2d91', alpha=0.6)
                ax.set_yticks(list(x))
                ax.set_yticklabels([c[:14] for c in cats], fontsize=8)
                ax.set_xlabel('€', color=self.colors['fg'], fontsize=8)
                ax.legend(fontsize=8)
                ax.set_facecolor(self.colors['bg_secondary'])
                ax.tick_params(colors=self.colors['fg'], labelsize=8)
                for spine in ax.spines.values():
                    spine.set_color(self.colors['fg_muted'])
                ax.set_title("Vergleich Aktuell vs. Vormonat",
                             color=self.colors['fg'], fontsize=9)
        self.fig_ki.patch.set_facecolor(self.colors['bg_secondary'])
        self.fig_ki.tight_layout(pad=0.8)
        self.ki_canvas.draw()

    def show_spartipps(self):
        """Zeigt personalisierte Spartipps basierend auf den aktuellen Daten."""
        totals = self.model.get_totals()
        per_main = totals['per_main']
        inc = totals['income']
        exp = totals['expense']
        sq = (totals['balance'] / inc * 100) if inc > 0 else 0

        tipps = ["💡 PERSONALISIERTE SPARTIPPS\n" + "─"*40 + "\n"]

        if sq < 10:
            tipps.append("1. 🎯 50/30/20-Regel anwenden:\n"
                         "   • 50% für Notwendiges (Miete, Essen)\n"
                         "   • 30% für Lifestyle (Freizeit, Abos)\n"
                         "   • 20% zum Sparen\n")

        # Analysiere variable Kosten
        variable_total = sum(v for mc, v in per_main.items()
                             if "Variable" in mc or "Freizeit" in mc)
        if variable_total > inc * 0.35:
            tipps.append(f"2. 📉 Deine variablen Ausgaben ({variable_total:.0f} €) "
                         f"sind {variable_total/inc*100:.0f}% deines Einkommens.\n"
                         "   Ziel: unter 30%. Tipp: Wöchentliches Ausgaben-Budget setzen.\n")

        # Abos-Check
        for (mc, sc, item), refs in self.labels_by_item.items():
            if "Abo" in item.lower() or sc.lower() == "abos":
                amt = ensure_float(refs['amt'].get())
                if amt > 0:
                    tipps.append(f"3. 📱 Abo-Check: '{item}' kostet {amt:.2f} €/Monat "
                                 f"= {amt*12:.0f} €/Jahr. Noch genutzt?\n")
                    break

        # Restaurant vs. Supermarkt
        rest_amt = sum(ensure_float(refs['amt'].get())
                       for (mc, sc, item), refs in self.labels_by_item.items()
                       if item.lower() in ['restaurant', 'lieferando', 'cafe'])
        if rest_amt > 100:
            tipps.append(f"4. 🍽️ Du gibst {rest_amt:.0f} €/Monat für Restaurants aus.\n"
                         "   Kochen statt bestellen kann 200-400 €/Monat sparen.\n")

        # Notgroschen
        notgroschen = next((g for g in self.model.savings_goals
                            if "not" in g.get('name', '').lower()), None)
        if not notgroschen:
            tipps.append("5. 🛡️ Kein Notgroschen-Ziel definiert!\n"
                         "   Empfehlung: 3-6 Monatsgehälter zurücklegen.\n")

        # Budget-Limits empfehlen
        if not self.model.budget_warnings:
            tipps.append("6. ⚙️ Tipp: Setze Budget-Limits für deine Hauptkategorien\n"
                         "   (⚙️ Budget-Limits Button). Das hilft, Ausgaben im Blick zu behalten.\n")

        # Sparquote-Ziel
        if sq < 20:
            needed_savings = (0.20 * inc) - totals['balance']
            tipps.append(f"7. 📈 Um 20% Sparquote zu erreichen, müsstest du\n"
                         f"   {needed_savings:.2f} € mehr sparen bzw. weniger ausgeben.\n")

        if len(tipps) == 1:
            tipps.append("✅ Sehr gut! Keine kritischen Punkte gefunden.\n"
                         "Du wirtschaftest solide. Weiter so! 🌟")

        self._ki_set_text("\n".join(tipps))

    # ══════════════════════════════════════════════════
    # Feature 14: Regelbasierte Automatisierung
    # ══════════════════════════════════════════════════
    def build_rules_tab(self):
        """Regelbasierte Automatisierung: Wenn X → Kategorie Y."""
        hdr = tk.Frame(self.rules_tab, bg=self.colors['bg_tertiary'])
        hdr.pack(fill="x")
        tk.Label(hdr, text="⚙️ Automatisierungsregeln", bg=self.colors['bg_tertiary'],
                 fg=self.colors['fg'], font=("Segoe UI", 14, "bold")).pack(side="left", padx=20, pady=12)
        self.create_button(hdr, "➕ Neue Regel", self._add_rule,
                           self.colors['success']).pack(side="left", padx=10)
        self.create_button(hdr, "📥 Auf CSV anwenden", self._apply_rules_to_csv,
                           self.colors['accent']).pack(side="left", padx=10)

        # Info
        tk.Label(self.rules_tab,
                 text='Regeln werden beim CSV-Import automatisch angewendet. '
                      'Format: "Wenn Beschreibung enthält X → Kategorie Y"',
                 bg=self.colors['bg'], fg=self.colors['fg_muted'],
                 font=("Segoe UI", 9, "italic")).pack(anchor="w", padx=20, pady=5)

        # Regeln-Liste (scrollbar)
        rules_outer = tk.Frame(self.rules_tab, bg=self.colors['bg'])
        rules_outer.pack(fill="both", expand=True, padx=15, pady=10)

        rules_canvas = tk.Canvas(rules_outer, bg=self.colors['bg'], highlightthickness=0)
        rules_scroll = ttk.Scrollbar(rules_outer, orient="vertical", command=rules_canvas.yview)
        self.rules_list_frame = tk.Frame(rules_canvas, bg=self.colors['bg'])
        self.rules_list_frame.bind("<Configure>",
            lambda e: rules_canvas.configure(scrollregion=rules_canvas.bbox("all")))
        rules_canvas.create_window((0, 0), window=self.rules_list_frame, anchor="nw")
        rules_canvas.configure(yscrollcommand=rules_scroll.set)
        rules_canvas.pack(side="left", fill="both", expand=True)
        rules_scroll.pack(side="right", fill="y")

        self._refresh_rules_list()

    def _refresh_rules_list(self):
        """Aktualisiert die Regeln-Liste."""
        if not hasattr(self, 'rules_list_frame'):
            return
        for w in self.rules_list_frame.winfo_children():
            w.destroy()

        rules = self.model.custom_keyword_map  # {keyword: (mc, sc, item)}
        if not rules:
            tk.Label(self.rules_list_frame,
                     text="Noch keine Regeln definiert.\nKlicke auf '➕ Neue Regel'.",
                     bg=self.colors['bg'], fg=self.colors['fg_muted'],
                     font=("Segoe UI", 10), justify="center").pack(pady=40)
            return

        # Header
        hdr = tk.Frame(self.rules_list_frame, bg=self.colors['bg_tertiary'])
        hdr.pack(fill="x", padx=5, pady=(0, 5))
        for col, w, txt in [(0, 28, "Wenn Beschreibung enthält…"),
                            (1, 40, "→ Kategorie"),
                            (2, 8, "")]:
            tk.Label(hdr, text=txt, bg=self.colors['bg_tertiary'], fg=self.colors['fg'],
                     font=("Segoe UI", 9, "bold"), width=w, anchor="w").grid(
                row=0, column=col, padx=8, pady=6)

        for i, (keyword, mapping) in enumerate(sorted(rules.items())):
            mc, sc, item = mapping if isinstance(mapping, (list, tuple)) else (mapping, "", "")
            row_bg = self.colors['bg_secondary'] if i % 2 == 0 else self.colors['bg']
            row = tk.Frame(self.rules_list_frame, bg=row_bg)
            row.pack(fill="x", padx=5, pady=1)

            tk.Label(row, text=keyword, bg=row_bg, fg=self.colors['fg'],
                     font=("Segoe UI", 10), width=28, anchor="w").grid(row=0, column=0, padx=8, pady=5)
            cat_text = f"{mc} › {sc} › {item}" if sc and item else str(mapping)
            tk.Label(row, text=cat_text, bg=row_bg, fg=self.colors['accent'],
                     font=("Segoe UI", 10), width=40, anchor="w").grid(row=0, column=1, padx=8)
            tk.Button(row, text="🗑️", bg=self.colors['danger'], fg="white",
                      font=("Segoe UI", 8), relief="flat", cursor="hand2",
                      command=lambda k=keyword: self._delete_rule(k),
                      padx=6, pady=2).grid(row=0, column=2, padx=8)

    def _add_rule(self):
        """Dialog zum Hinzufügen einer neuen Regel."""
        dialog = tk.Toplevel(self.root)
        dialog.title("Neue Automatisierungsregel")
        dialog.geometry("500x360")
        dialog.configure(bg=self.colors['bg'])
        dialog.grab_set()

        tk.Label(dialog, text="⚙️ Neue Regel erstellen",
                 bg=self.colors['bg'], fg=self.colors['fg'],
                 font=("Segoe UI", 13, "bold")).pack(pady=15)

        frame = tk.Frame(dialog, bg=self.colors['bg'])
        frame.pack(fill="both", expand=True, padx=25)

        tk.Label(frame, text="Wenn die Beschreibung enthält:",
                 bg=self.colors['bg'], fg=self.colors['fg'],
                 font=("Segoe UI", 10)).pack(anchor="w", pady=(5, 2))
        keyword_var = tk.StringVar()
        tk.Entry(frame, textvariable=keyword_var, font=("Segoe UI", 11),
                 bg=self.colors['bg_input'], fg=self.colors['fg'],
                 insertbackground=self.colors['fg'],
                 relief="flat").pack(fill="x", pady=(0, 12))

        tk.Label(frame, text="→ dann dieser Kategorie zuordnen:",
                 bg=self.colors['bg'], fg=self.colors['fg'],
                 font=("Segoe UI", 10)).pack(anchor="w", pady=(0, 2))

        # Kategorie-Dropdown
        all_items = []
        for mc, subs in self.model.structure.items():
            for sc, items in subs.items():
                for item in items:
                    all_items.append(f"{mc} › {sc} › {item}")

        cat_var = tk.StringVar(value=all_items[0] if all_items else "")
        ttk.Combobox(frame, textvariable=cat_var, values=all_items,
                     state="readonly", font=("Segoe UI", 10)).pack(fill="x", pady=(0, 12))

        tk.Label(frame,
                 text="Tipp: Groß-/Kleinschreibung wird ignoriert.",
                 bg=self.colors['bg'], fg=self.colors['fg_muted'],
                 font=("Segoe UI", 9, "italic")).pack(anchor="w")

        def save():
            kw = keyword_var.get().strip().lower()
            if not kw:
                messagebox.showerror("Fehler", "Bitte einen Begriff eingeben.", parent=dialog)
                return
            sel = cat_var.get()
            try:
                parts = sel.split(" › ")
                mc, sc, item = parts[0], parts[1], parts[2]
            except:
                messagebox.showerror("Fehler", "Ungültige Kategorie.", parent=dialog)
                return
            self.model.custom_keyword_map[kw] = (mc, sc, item)
            self.model.save_settings()
            dialog.destroy()
            self._refresh_rules_list()
            messagebox.showinfo("✅", f"Regel gespeichert:\n'{kw}' → {mc} › {sc} › {item}")

        tk.Button(dialog, text="💾 Regel speichern", command=save,
                  bg=self.colors['success'], fg="white",
                  font=("Segoe UI", 10, "bold"), relief="flat",
                  padx=20, pady=8).pack(pady=15)

    def _delete_rule(self, keyword):
        """Löscht eine Regel."""
        if messagebox.askyesno("Regel löschen", f"Regel '{keyword}' wirklich löschen?"):
            self.model.custom_keyword_map.pop(keyword, None)
            self.model.save_settings()
            self._refresh_rules_list()

    def _apply_rules_to_csv(self):
        """Wendet alle Regeln auf eine CSV-Datei an (direkter Import)."""
        messagebox.showinfo(
            "Regeln anwenden",
            "Nutze den '📥 CSV Import' Button in der Toolbar.\n"
            "Dort werden alle deine Regeln automatisch angewendet."
        )


# ------------------------------
# Unit Tests
# ------------------------------
def run_tests():
    print("🧪 Running Unit Tests...")

    assert ensure_float("123.45") == 123.45
    assert ensure_float("123,45") == 123.45
    assert ensure_float("") == 0.0
    assert ensure_float("abc") == 0.0
    print("✅ Test 1: ensure_float passed")

    assert validate_month_format("2025-01") == True
    assert validate_month_format("2025-13") == False
    assert validate_month_format("abc") == False
    print("✅ Test 2: validate_month_format passed")

    assert get_previous_month("2025-03") == "2025-02"
    assert get_previous_month("2025-01") == "2024-12"
    print("✅ Test 3: get_previous_month passed")

    assert get_next_month("2025-03") == "2025-04"
    assert get_next_month("2025-12") == "2026-01"
    print("✅ Test 4: get_next_month passed")

    # Test BudgetModel
    model = BudgetModel()
    cat = model.categorize_transaction("REWE Supermarkt Berlin", -45.50)
    assert cat == ("Variable Kosten", "Essen", "Supermarkt"), f"Got: {cat}"
    print("✅ Test 5: Auto-Kategorisierung REWE passed")

    cat2 = model.categorize_transaction("Netflix Abo", -12.99)
    assert cat2 == ("Variable Kosten", "Freizeit", "Abos"), f"Got: {cat2}"
    print("✅ Test 6: Auto-Kategorisierung Netflix passed")

    # Test Undo/Redo
    um = UndoRedoManager()
    um.push({"a": 1})
    um.push({"a": 2})
    um.push({"a": 3})
    state = um.undo()
    assert state == {"a": 2}, f"Got: {state}"
    state = um.redo()
    assert state == {"a": 3}, f"Got: {state}"
    assert not um.can_redo()
    print("✅ Test 7: Undo/Redo passed")

    # Test BudgetModel Berechnungen
    model2 = BudgetModel()
    model2.values = {
        ("Einnahmen", "Gehalt", "Gehalt Hauptjob"): {"amount": "3000", "note": ""},
        ("Fixkosten", "Wohnen", "Miete"): {"amount": "800", "note": ""},
        ("Variable Kosten", "Essen", "Supermarkt"): {"amount": "300", "note": ""},
    }
    totals = model2.get_totals()
    assert totals['income'] == 3000.0
    assert totals['expense'] == 1100.0
    assert totals['balance'] == 1900.0
    print("✅ Test 8: BudgetModel Berechnungen passed")

    # Test Budget-Warnstufen
    model3 = BudgetModel()
    model3.budget_warnings = {"Fixkosten": 1000.0}
    level, pct = model3.get_budget_warning_level("Fixkosten", 750.0)
    assert level == 'warn', f"Expected warn, got {level}"
    level2, pct2 = model3.get_budget_warning_level("Fixkosten", 1050.0)
    assert level2 == 'over', f"Expected over, got {level2}"
    level3, pct3 = model3.get_budget_warning_level("Fixkosten", 1250.0)
    assert level3 == 'critical', f"Expected critical, got {level3}"
    level4, pct4 = model3.get_budget_warning_level("Fixkosten", 400.0)
    assert level4 == 'ok', f"Expected ok, got {level4}"
    level5, _ = model3.get_budget_warning_level("Variable Kosten", 500.0)
    assert level5 is None
    print("✅ Test 9: Intelligente Budget-Warnstufen passed")

    # Test Multi-Sparziele
    model4 = BudgetModel()
    model4.savings_goals = [
        {'name': 'Urlaub', 'target': 2000.0, 'saved': 800.0, 'monthly': 200.0, 'icon': '✈️'},
        {'name': 'Notgroschen', 'target': 5000.0, 'saved': 5000.0, 'monthly': 0, 'icon': '🛡️'},
    ]
    urlaub = model4.savings_goals[0]
    pct_urlaub = urlaub['saved'] / urlaub['target'] * 100
    assert abs(pct_urlaub - 40.0) < 0.01, f"Got {pct_urlaub}"
    notgroschen = model4.savings_goals[1]
    pct_ng = notgroschen['saved'] / notgroschen['target'] * 100
    assert pct_ng == 100.0
    print("✅ Test 10: Multi-Sparziele passed")

    # Test Drag & Drop Reihenfolge (nur Modell-Ebene)
    model5 = BudgetModel()
    items = model5.structure["Variable Kosten"]["Essen"]
    assert "Supermarkt" in items and "Restaurant" in items
    idx_s = items.index("Supermarkt")
    idx_r = items.index("Restaurant")
    items[idx_s], items[idx_r] = items[idx_r], items[idx_s]
    assert items.index("Restaurant") == idx_s
    print("✅ Test 11: Drag & Drop Reihenfolge passed")

    print("\n✅ All 11 tests passed!")


# ------------------------------
# App Entry
# ------------------------------
def main():
    import sys
    if len(sys.argv) > 1 and sys.argv[1] == "--test":
        run_tests()
        return
    root = tk.Tk()
    app = BudgetApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
