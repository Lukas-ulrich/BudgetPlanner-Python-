#!/bin/bash
# ═══════════════════════════════════════════════════════════════════
# BudgetPlanner Pro – Automatisches Setup für macOS / Linux
# ═══════════════════════════════════════════════════════════════════
# Einfach im Terminal ausführen:
#   chmod +x START_BudgetPlanner.sh
#   ./START_BudgetPlanner.sh
#
# Oder Doppelklick im Finder (macOS: erst Rechtsklick → Öffnen)
# ═══════════════════════════════════════════════════════════════════

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

APP_FILE="BudgetPlanner_v5.py"
VENV_DIR=".venv"

echo ""
echo "╔══════════════════════════════════════════════╗"
echo "║        BudgetPlanner Pro  v5.0              ║"
echo "║        Automatisches Setup & Start          ║"
echo "╚══════════════════════════════════════════════╝"
echo ""

# ── Farben für Terminal-Output ──────────────────────────────────────
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'  # No Color

ok()   { echo -e "  ${GREEN}✓${NC} $1"; }
info() { echo -e "  ${BLUE}ℹ${NC}  $1"; }
warn() { echo -e "  ${YELLOW}⚠${NC}  $1"; }
err()  { echo -e "  ${RED}✗${NC} $1"; }

# ── 1. Python prüfen ───────────────────────────────────────────────
echo "[1/4] Prüfe Python..."

PYTHON=""
for cmd in python3.12 python3.11 python3.10 python3 python; do
    if command -v "$cmd" &>/dev/null; then
        VER=$("$cmd" --version 2>&1 | grep -oE '[0-9]+\.[0-9]+' | head -1)
        MAJOR=$(echo "$VER" | cut -d. -f1)
        MINOR=$(echo "$VER" | cut -d. -f2)
        if [ "$MAJOR" -ge 3 ] && [ "$MINOR" -ge 9 ]; then
            PYTHON="$cmd"
            break
        fi
    fi
done

if [ -z "$PYTHON" ]; then
    warn "Python 3.9+ nicht gefunden. Versuche Installation..."

    if [[ "$OSTYPE" == "darwin"* ]]; then
        # macOS
        if command -v brew &>/dev/null; then
            info "Installiere Python via Homebrew..."
            brew install python@3.12
            PYTHON="python3.12"
        else
            err "Homebrew nicht gefunden."
            echo ""
            echo "  Bitte installiere Python manuell:"
            echo "  1. https://python.org/downloads → macOS Installer herunterladen"
            echo "  2. Installieren"
            echo "  3. Dieses Script erneut ausführen"
            echo ""
            if command -v open &>/dev/null; then
                open "https://python.org/downloads"
            fi
            exit 1
        fi
    elif command -v apt-get &>/dev/null; then
        # Debian/Ubuntu
        sudo apt-get update -qq
        sudo apt-get install -y python3 python3-pip python3-tk python3-venv
        PYTHON="python3"
    elif command -v dnf &>/dev/null; then
        # Fedora/RHEL
        sudo dnf install -y python3 python3-pip python3-tkinter
        PYTHON="python3"
    else
        err "Kein unterstützter Paketmanager gefunden."
        echo "  Bitte Python manuell installieren: https://python.org"
        exit 1
    fi
fi

ok "Python gefunden: $($PYTHON --version)"

# ── 2. Virtual Environment ─────────────────────────────────────────
echo ""
echo "[2/4] Virtuelle Umgebung..."

if [ ! -d "$VENV_DIR" ]; then
    info "Erstelle virtuelle Umgebung (.venv)..."
    "$PYTHON" -m venv "$VENV_DIR"
    ok "Virtuelle Umgebung erstellt"
else
    ok "Virtuelle Umgebung bereits vorhanden"
fi

# Aktiviere venv
if [[ "$OSTYPE" == "msys" ]] || [[ "$OSTYPE" == "win32" ]]; then
    source "$VENV_DIR/Scripts/activate"
else
    source "$VENV_DIR/bin/activate"
fi

# Pip aktualisieren
python -m pip install --upgrade pip --quiet 2>/dev/null

# ── 3. Abhängigkeiten installieren ─────────────────────────────────
echo ""
echo "[3/4] Überprüfe Pakete..."

PACKAGES=("matplotlib" "numpy" "reportlab" "Pillow")
INSTALL_NEEDED=()

for pkg in "${PACKAGES[@]}"; do
    import_name=$(echo "$pkg" | tr '[:upper:]' '[:lower:]' | sed 's/pillow/PIL/')
    python -c "import $import_name" 2>/dev/null && ok "$pkg" || INSTALL_NEEDED+=("$pkg")
done

if [ ${#INSTALL_NEEDED[@]} -gt 0 ]; then
    info "Installiere fehlende Pakete: ${INSTALL_NEEDED[*]}"
    pip install "${INSTALL_NEEDED[@]}" --quiet
    ok "Alle Pakete installiert"
else
    ok "Alle Pakete bereits vorhanden"
fi

# tkinter extra prüfen (Linux)
python -c "import tkinter" 2>/dev/null || {
    warn "tkinter fehlt. Installiere..."
    if command -v apt-get &>/dev/null; then
        sudo apt-get install -y python3-tk 2>/dev/null || true
    elif command -v dnf &>/dev/null; then
        sudo dnf install -y python3-tkinter 2>/dev/null || true
    fi
}

# ── 4. App starten ─────────────────────────────────────────────────
echo ""
echo "[4/4] Starte BudgetPlanner Pro..."
echo ""
echo "  ════════════════════════════════════════════════"
echo "   Die App startet jetzt. Viel Spaß! 💰"
echo "  ════════════════════════════════════════════════"
echo ""

if [ ! -f "$APP_FILE" ]; then
    err "$APP_FILE nicht gefunden!"
    echo "  Bitte dieses Script im gleichen Ordner wie $APP_FILE ausführen."
    exit 1
fi

python "$APP_FILE"
